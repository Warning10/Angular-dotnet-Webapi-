﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Utils;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Crud_Operations_Basics.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly ApplicationDbContext _context;

        public EmployeeRepository(ApplicationDbContext context)
        {
            _context = context;
        }
         public async Task<List<EmployeeModel>> GetAllEmployeesAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<EmployeeModel> GetEmployeesByIdAsync(int employeeId)
        {
            return await _context.Employees.Where(x => x.Id == employeeId).FirstOrDefaultAsync();
        }

        public async Task<int> AddEmployeesAsync(EmployeeDto createEmployeeDto)
        {
			var employeeModel = new EmployeeModel
			{
				Name = createEmployeeDto.Name,
				Email = createEmployeeDto.Email,
				Gender = createEmployeeDto.Gender,
				Phone = createEmployeeDto.Phone,
				Address = createEmployeeDto.Address,
				Designation = createEmployeeDto.Designation,
				Created = DateTime.UtcNow,
				Updated = DateTime.UtcNow
			};
			_context.Employees.Add(employeeModel);
            await _context.SaveChangesAsync();
            return employeeModel.Id;
        }

        public async Task UpdateEmployeesAsync(int employeeId, EmployeeDto updateEmployeeDto)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee != null)
            {
				employee.Name = updateEmployeeDto.Name;
				employee.Email = updateEmployeeDto.Email;
				employee.Gender = updateEmployeeDto.Gender;
				employee.Phone = updateEmployeeDto.Phone;
				employee.Address = updateEmployeeDto.Address;
				employee.Designation = updateEmployeeDto.Designation;
				employee.Updated = DateTime.UtcNow;

				await _context.SaveChangesAsync();
            }
        }
        public async Task UpdateEmployeesPatchAsync(int employeeId, JsonPatchDocument<EmployeeDto> patchDocument)
        {
			var employee = await GetEmployeesByIdAsync(employeeId);
			if (employee == null) throw new KeyNotFoundException("Employee not found");

			var employeeDto = new EmployeeDto
			{
				Name = employee.Name,
				Email = employee.Email,
				Gender = employee.Gender,
				Phone = employee.Phone,
				Address = employee.Address,
				Designation = employee.Designation,
			};

			patchDocument.ApplyTo(employeeDto);

			// Map updated DTO back to the entity
			employee.Name = employeeDto.Name;
			employee.Email = employeeDto.Email;	
			employee.Gender = employeeDto.Gender;
			employee.Phone = employeeDto.Phone;
			employee.Address = employeeDto.Address;
			employee.Designation = employeeDto.Designation;
			employee.Updated = DateTime.UtcNow;

			await _context.SaveChangesAsync();
		}
        

        public async Task<bool> DeleteEmployeesAsync(int employeeId)
        {
            var employee = await _context.Employees.Where(x => x.Id == employeeId).FirstOrDefaultAsync();
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
