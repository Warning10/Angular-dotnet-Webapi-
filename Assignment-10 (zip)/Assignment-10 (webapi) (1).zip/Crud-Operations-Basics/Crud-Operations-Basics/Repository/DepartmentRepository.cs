﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Crud_Operations_Basics.Utils;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.EntityFrameworkCore;

namespace Crud_Operations_Basics.Repository
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly ApplicationDbContext _context;

        public DepartmentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<DepartmentModel>> GetAllDepartmentsAsync()
        {
            return await _context.Departments.ToListAsync();
        }
        public async Task<DepartmentModel> GetDepartmentsByIdAsync(int deptId)
        {
            return await _context.Departments.Where(x => x.DeptId == deptId).FirstOrDefaultAsync();
        }
        public async Task<int> AddDepartmentsAsync(DepartmentDto departmentDto)
        {
            var departmentModel = new DepartmentModel
            {
                DeptName = departmentDto.DeptName,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            };
            _context.Departments.Add(departmentModel);
            await _context.SaveChangesAsync();
            return departmentModel.DeptId;
        }
        public async Task UpdateDepartmentsAsync(int deptId, DepartmentDto departmentDto)
        {
            var department = await _context.Departments.FindAsync(deptId);
            if (department != null)
            {
                department.DeptName = departmentDto.DeptName;
                department.Updated = DateTime.UtcNow;

                await _context.SaveChangesAsync();
            }
        }
        public async Task UpdateDepartmentsPatchAsync(int deptId, JsonPatchDocument<DepartmentDto> patchDocument)
        {
            var department = await GetDepartmentsByIdAsync(deptId);
			if (department == null) throw new KeyNotFoundException("Department not found");

            var departmentDto = new DepartmentDto
            {
                DeptName = department.DeptName,
            };

            patchDocument.ApplyTo(departmentDto);

            department.DeptName = departmentDto.DeptName;
            department.Updated = DateTime.UtcNow;
            await _context.SaveChangesAsync();
        }
        public async Task<bool> DeleteDepartmentsAsync(int deptId)
        {
            var department = await GetDepartmentsByIdAsync(deptId);
            _context.Departments.Remove(department);
            await _context.SaveChangesAsync();
            return true;
        }

    }
}
