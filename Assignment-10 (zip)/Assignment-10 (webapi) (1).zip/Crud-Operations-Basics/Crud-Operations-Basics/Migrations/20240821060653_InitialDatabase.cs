﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Crud_Operations_Basics.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Designation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6792), "Human Resources", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6792) },
                    { 2, new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6794), "Information Technology", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6794) },
                    { 3, new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6796), "Finance", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6796) },
                    { 4, new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6797), "Marketing", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6798) },
                    { 5, new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6799), "Operations", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6799) }
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "Created", "Designation", "Email", "Gender", "Name", "Phone", "Updated" },
                values: new object[,]
                {
                    { 1, "123 Pune Road, Pune, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6588), "HR Manager", "amit.deshmukh@example.com", "Male", "Amit Deshmukh", "9960501340", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6588) },
                    { 2, "456 Mumbai Lane, Mumbai, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6590), "Software Engineer", "sneha.patil@example.com", "Female", "Sneha Patil", "9874563210", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6591) },
                    { 3, "789 Nagpur Street, Nagpur, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6593), "Finance Analyst", "ravi.kale@example.com", "Male", "Ravi Kale", "7894561230", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6593) },
                    { 4, "321 Aurangabad Road, Aurangabad, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6595), "Marketing Executive", "pooja.shinde@example.com", "Female", "Pooja Shinde", "9874563210", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6595) },
                    { 5, "654 Nashik Lane, Nashik, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6597), "Operations Manager", "suresh.gore@example.com", "Male", "Suresh Gore", "7894561450", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6597) },
                    { 6, "987 Solapur Street, Solapur, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6599), "HR Specialist", "anita.joshi@example.com", "Female", "Anita Joshi", "7896540321", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6599) },
                    { 7, "345 Satara Road, Satara, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6601), "IT Consultant", "ajay.jadhav@example.com", "Male", "Ajay Jadhav", "9638527410", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6602) },
                    { 8, "678 Thane Avenue, Thane, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6604), "Senior Finance Analyst", "meera.desai@example.com", "Female", "Meera Desai", "9685741230", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6604) },
                    { 9, "987 Jalgaon Road, Jalgaon, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6606), "Marketing Manager", "kunal.naik@example.com", "Male", "Kunal Naik", "7418529630", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6606) },
                    { 10, "321 Pimpri Chinchwad Road, Pimpri Chinchwad, Maharashtra", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6608), "Operations Executive", "prachi.rane@example.com", "Female", "Prachi Rane", "9876543210", new DateTime(2024, 8, 21, 6, 6, 53, 621, DateTimeKind.Utc).AddTicks(6608) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
