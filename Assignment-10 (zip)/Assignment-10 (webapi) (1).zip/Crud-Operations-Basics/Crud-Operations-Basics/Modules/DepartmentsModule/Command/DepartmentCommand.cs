﻿using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class DepartmentCommand : IRequest<bool>
    {
        public string DeptName { get; set; }
    }
}
