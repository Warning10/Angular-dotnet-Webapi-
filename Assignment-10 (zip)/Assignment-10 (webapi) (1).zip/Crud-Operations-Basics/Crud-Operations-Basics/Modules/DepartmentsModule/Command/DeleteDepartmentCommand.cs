﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Repository;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class DeleteDepartmentCommand : DepartmentCommand
    {
        public int Id { get; set; }
    }
    public class DeleteDepartmentCommandHandler : IRequestHandler<DeleteDepartmentCommand, bool>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;
        public DeleteDepartmentCommandHandler(IGenericRepository<Models.DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
        {
            var existingDepartment = await _genericRepository.GetByIdAsync(request.Id);
            if (existingDepartment == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);

        }

    }

}
