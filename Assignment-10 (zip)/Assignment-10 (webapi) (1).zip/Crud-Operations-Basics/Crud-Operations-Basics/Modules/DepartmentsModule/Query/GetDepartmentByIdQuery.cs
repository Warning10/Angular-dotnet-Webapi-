﻿using Crud_Operations_Basics.Interfaces;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Query
{
    public class GetDepartmentByIdQuery : IRequest<Models.DepartmentModel>
    {
        public int Id { get; set; }
    }

    public class GetDepartmentByIdQueryHandler : IRequestHandler <GetDepartmentByIdQuery, Models.DepartmentModel>
    {
        private readonly IGenericRepository<Models.DepartmentModel> _genericRepository;

        public GetDepartmentByIdQueryHandler(IGenericRepository<Models.DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<Models.DepartmentModel> Handle(GetDepartmentByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}
