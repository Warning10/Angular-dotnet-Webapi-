﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class UpdateEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }
    }

    public class UpdateEmployeeCommandHandler : IRequestHandler<UpdateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;

        public UpdateEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateEmployeeCommand request, CancellationToken cancellationToken)
        {
            var existingEmployee = await _genericRepository.GetByIdAsync(request.Id);
            if (existingEmployee == null)
            {
                return false;
            }

            existingEmployee.Name = request.Name;
            existingEmployee.Email = request.Email;
            existingEmployee.Gender = request.Gender;
            existingEmployee.Phone = request.Phone;
            existingEmployee.Address = request.Address;
            existingEmployee.Designation = request.Designation;
            existingEmployee.Updated = DateTime.UtcNow;

            return await _genericRepository.UpdateAsync(request.Id, existingEmployee);

        }
    }
}
