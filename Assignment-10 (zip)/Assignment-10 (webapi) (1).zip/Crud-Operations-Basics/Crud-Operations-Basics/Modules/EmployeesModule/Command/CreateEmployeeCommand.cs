﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class CreateEmployeeCommand : EmployeeCommand { }

    public class CreateEmployeeCommandHandler : IRequestHandler<CreateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;

        public CreateEmployeeCommandHandler(IGenericRepository<Models.EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(CreateEmployeeCommand request, CancellationToken cancellationToken)
        {
            var employeeModel = new EmployeeModel
            {
                Name = request.Name,
                Email = request.Email,
                Gender = request.Gender,
                Phone = request.Phone,
                Address = request.Address,
                Designation = request.Designation,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            };
            return await _genericRepository.AddAsync(employeeModel);
        }
    }
}
