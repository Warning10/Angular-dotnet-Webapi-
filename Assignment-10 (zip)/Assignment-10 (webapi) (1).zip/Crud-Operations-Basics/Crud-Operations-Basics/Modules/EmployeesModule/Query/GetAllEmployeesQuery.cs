﻿using Crud_Operations_Basics.Interfaces;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Query
{
    public class GetAllEmployeesQuery : IRequest<List<Models.EmployeeModel>> { }

    public class GetAllEmployeesHandler : IRequestHandler< GetAllEmployeesQuery, List<Models.EmployeeModel>>
    {
        private readonly IGenericRepository<Models.EmployeeModel> _genericRepository;

        public GetAllEmployeesHandler(IGenericRepository<Models.EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }
        public async Task<List<Models.EmployeeModel>> Handle(GetAllEmployeesQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllAsync();
        }
    }
}
