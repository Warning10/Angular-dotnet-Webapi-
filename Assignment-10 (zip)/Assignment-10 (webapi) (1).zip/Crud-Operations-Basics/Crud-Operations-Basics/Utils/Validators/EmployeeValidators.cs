﻿using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using FluentValidation;
using Microsoft.AspNetCore.JsonPatch;

namespace Crud_Operations_Basics.Utils.Validators
{
    public class EmployeeValidators : AbstractValidator<EmployeeDto>
    {
        public EmployeeValidators()
        {

            RuleFor(x => x.Name)
            .NotNull()
            .WithMessage("Name name cannot be null.")
            .NotEmpty()
            .WithMessage("Name name cannot be empty.")
            .Length(1, 50)
            .WithMessage("Name must be between 1 and 50 characters.");

            RuleFor(x => x.Email)
                .NotNull()
                .WithMessage("Email cannot be null.")
                .NotEmpty()
                .WithMessage("Email is required.")
                .EmailAddress()
                .WithMessage("Invalid email address format.")
                .Length(1, 100)
                .WithMessage("Email must not exceed 100 characters.");

            RuleFor(x => x.Gender)
                .NotNull()
                .WithMessage("Gender cannot be null.")
                .NotEmpty()
                .WithMessage("Gender is required.")
                .Length(1)
                .WithMessage("Gender must be a single character.");

            RuleFor(x => x.Phone)
                .NotNull()
                .WithMessage("Phone cannot be null.")
                .NotEmpty()
                .WithMessage("Phone is required.")
                .Length(10)
                .WithMessage("Phone must be a 10 character.");

            RuleFor(x => x.Address)
                .NotNull()
                .WithMessage("Address cannot be null.")
                .NotEmpty()
                .WithMessage("Address is required.")
                .Length(1, 255)
                .WithMessage("Address must be between 1 and 255 characters.");

            RuleFor(x => x.Designation)
                .NotNull()
                .WithMessage("Designation cannot be null.")
                .NotEmpty()
                .WithMessage("Designation is required.")
                .Length(1, 100)
                .WithMessage("Designation must be between 1 and 100 characters.");


/*            RuleFor(x => x.Created)
                .NotNull()
                .WithMessage("Creation date cannot be null.")
                .NotEmpty()
                .WithMessage("Creation date is required.");

			RuleFor(x => x.Updated)
				.NotNull()
				.WithMessage("Updated date cannot be null.")
				.NotEmpty()
				.WithMessage("Updated date is required.");*/

		}
    }
}
