﻿using Crud_Operations_Basics.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Crud_Operations_Basics.Utils.Configuration
{
    public class EmployeeConfiguration : IEntityTypeConfiguration<EmployeeModel>
    {
        public void Configure(EntityTypeBuilder<EmployeeModel> builder)
        {
            builder.HasData(
                    new EmployeeModel
                    {
                        Id = 1,
                        Name = "Amit Deshmukh",
                        Email = "amit.deshmukh@example.com",
                        Gender = "Male",
                        Phone = "9960501340",
                        Address = "123 Pune Road, Pune, Maharashtra",
                        Designation = "HR Manager",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new EmployeeModel
                    {
                        Id = 2,
                        Name = "Sneha Patil",
                        Email = "sneha.patil@example.com",
                        Gender = "Female",
                        Phone = "9874563210",
                        Address = "456 Mumbai Lane, Mumbai, Maharashtra",
                        Designation = "Software Engineer",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 3,
                        Name = "Ravi Kale",
                        Email = "ravi.kale@example.com",
                        Gender = "Male",
                        Phone = "7894561230",
                        Address = "789 Nagpur Street, Nagpur, Maharashtra",
                        Designation = "Finance Analyst",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {   
                        Id = 4,
                        Name = "Pooja Shinde",
                        Email = "pooja.shinde@example.com",
                        Gender = "Female",
                        Phone = "9874563210",
                        Address = "321 Aurangabad Road, Aurangabad, Maharashtra",
                        Designation = "Marketing Executive",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 5,
                        Name = "Suresh Gore",
                        Email = "suresh.gore@example.com",
                        Gender = "Male",
                        Phone = "7894561450",
                        Address = "654 Nashik Lane, Nashik, Maharashtra",
                        Designation = "Operations Manager",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 6,                    
                        Name = "Anita Joshi",
                        Email = "anita.joshi@example.com",
                        Gender = "Female",
                        Phone = "7896540321",
                        Address = "987 Solapur Street, Solapur, Maharashtra",
                        Designation = "HR Specialist",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 7,
                        Name = "Ajay Jadhav",
                        Email = "ajay.jadhav@example.com",
                        Gender = "Male",
                        Phone = "9638527410",
                        Address = "345 Satara Road, Satara, Maharashtra",
                        Designation = "IT Consultant",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 8,
                        Name = "Meera Desai",
                        Email = "meera.desai@example.com",
                        Gender = "Female",
                        Phone = "9685741230",
                        Address = "678 Thane Avenue, Thane, Maharashtra",
                        Designation = "Senior Finance Analyst",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 9,
                        Name = "Kunal Naik",
                        Email = "kunal.naik@example.com",
                        Gender = "Male",
                        Phone = "7418529630",
                        Address = "987 Jalgaon Road, Jalgaon, Maharashtra",
                        Designation = "Marketing Manager",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					},
                    new EmployeeModel
                    {
                        Id = 10,
                        Name = "Prachi Rane",
                        Email = "prachi.rane@example.com",
                        Gender = "Female",
                        Phone = "9876543210",
                        Address = "321 Pimpri Chinchwad Road, Pimpri Chinchwad, Maharashtra",
                        Designation = "Operations Executive",
                        Created = DateTime.UtcNow,
						Updated = DateTime.UtcNow
					}
                );
        }
    }
}
