﻿using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Modules.DepartmentsModule.Query;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentGenericCqrsController : ControllerBase
    {
        private readonly ISender _mediatR;

        public DepartmentGenericCqrsController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<List<Models.DepartmentModel>> GetAllDepartments()
        {
            var result = await _mediatR.Send(new GetAllDepartmentsQuery());
            return result;
        }

        [HttpGet("byid/{id}")]
        public async Task<Models.DepartmentModel> GetDepartmentById([FromRoute]int id)
        {
            var result = await _mediatR.Send(new GetDepartmentByIdQuery(){ Id = id });
            return result;
        }

        [HttpPost("create")]
        public async Task<object> CreateDepartment([FromBody] CreateDepartmentCommand createDepartmentCommand)
        {
            return await _mediatR.Send(createDepartmentCommand);

        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateDepartment([FromBody] DepartmentCommand departmentCommand, [FromRoute] int id)
        {
            var response = await _mediatR.Send(new UpdateDepartmentCommand() 
            {
                Id = id,
                DeptName = departmentCommand.DeptName
            }
            
            );
            return response;
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteDepartment([FromRoute]int id)
        {
            return await _mediatR.Send(new DeleteDepartmentCommand() { Id = id });
        }


    }



}
