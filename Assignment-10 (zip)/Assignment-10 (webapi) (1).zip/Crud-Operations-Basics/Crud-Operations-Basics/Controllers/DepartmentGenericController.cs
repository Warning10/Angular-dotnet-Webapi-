﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentGenericController : ControllerBase
    {
        private readonly IGenericRepository<DepartmentModel> _departmentGenericRepository;
        public DepartmentGenericController(IGenericRepository<DepartmentModel> departmentGenericRepository)
        {
            _departmentGenericRepository = departmentGenericRepository;
        }
        [HttpGet("all")]
        public async Task<IActionResult> GetAllDepartments()
        {
            var result = await _departmentGenericRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetDepartmentById([FromRoute] int id)
        {

            var employee = await _departmentGenericRepository.GetByIdAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            return Ok(employee);
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddNewDepartment([FromBody] DepartmentModel departmentModel)
        {
            var id = await _departmentGenericRepository.AddAsync(departmentModel);
            return Ok(id);

        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateDepartment([FromBody] DepartmentModel departmentModel, [FromRoute] int id)
        {
            departmentModel.DeptId = id; // Ensure that the Id from the route is used
            await _departmentGenericRepository.UpdateAsync(id, departmentModel);
            return Ok();
        }

        [HttpPatch("patch/update/{id}")]
        public async Task<IActionResult> UpdateDepartmentPatch([FromBody] JsonPatchDocument employeeModel, [FromRoute] int id)
        {
            await _departmentGenericRepository.UpdatePatchAsync(id, employeeModel);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteDepartment([FromRoute] int id)
        {
            return Ok(await _departmentGenericRepository.DeleteAsync(id));
        }
    }
}
