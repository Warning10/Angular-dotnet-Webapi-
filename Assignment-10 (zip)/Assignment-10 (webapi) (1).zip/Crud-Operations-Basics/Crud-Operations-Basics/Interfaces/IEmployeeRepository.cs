﻿using Crud_Operations_Basics.Models;
using Crud_Operations_Basics.Models.Dto;
using Microsoft.AspNetCore.JsonPatch;

namespace Crud_Operations_Basics.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<List<EmployeeModel>> GetAllEmployeesAsync();
        Task<EmployeeModel> GetEmployeesByIdAsync(int employeeId);
        Task<int> AddEmployeesAsync(EmployeeDto createEmployeeDto);
        Task UpdateEmployeesAsync(int employeeId, EmployeeDto updateEmployeeDto);
        Task UpdateEmployeesPatchAsync(int employeeId, JsonPatchDocument<EmployeeDto> patchDocument);
        Task<bool> DeleteEmployeesAsync(int employeeId);

    }
}