﻿using Microsoft.AspNetCore.JsonPatch;

namespace Crud_Operations_Basics.Interfaces
{
    public interface IGenericRepository<T> where T : class 
    {
        Task<List<T>> GetAllAsync();
        Task<T> GetByIdAsync(int id);
        Task<bool> AddAsync(T entity);
        Task<bool> UpdateAsync(int Id, T entity);
        Task UpdatePatchAsync(int Id, JsonPatchDocument entity);
        Task<bool> DeleteAsync(int Id);

    }
}
