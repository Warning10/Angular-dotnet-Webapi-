import { Component } from "@angular/core";

@Component({
    selector: 'department',
    templateUrl: './department.component.html',
    styleUrl: './department.component.css',
})
export class DepartmentComponent { }