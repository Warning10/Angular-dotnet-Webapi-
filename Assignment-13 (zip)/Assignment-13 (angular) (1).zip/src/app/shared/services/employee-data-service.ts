import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { IEmployee } from "../interface/employee.model";

@Injectable({
    providedIn: 'root'
  })
  export class EmployeeDataService{
    private apiUrl = "https://localhost:7162";

    constructor(private http: HttpClient) { }

    getAllEmployee(): Observable<IEmployee[]> {
        return this.http.get<IEmployee[]>(`${this.apiUrl}/api/Employee/all`);
      }

    createEmployee(employee: IEmployee): Observable<IEmployee> {
        debugger;
        return this.http.post<IEmployee>(`${this.apiUrl}/api/Employee/create`, employee);
      }

    
      getEmployeeById(employeeId: number): Observable<IEmployee> {
    return this.http.get<IEmployee>(`${this.apiUrl}/api/Employee/byid/${employeeId}`);
  }

  updateEmployee(employeeId: number, employee: IEmployee): Observable<IEmployee> {
    return this.http.put<IEmployee>(`${this.apiUrl}/api/Employee/update/${employeeId}`, employee);
  }

    deleteEmployee(employeeId: number): Observable<IEmployee> {
        return this.http.delete<IEmployee>(`${this.apiUrl}/api/Employee/delete/${employeeId}`);
    }
  }