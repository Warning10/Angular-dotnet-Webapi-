import { NgModule } from "@angular/core";
import { NavBarComponent } from "./layout/nav-bar/nav-bar.component";
import { FooterComponent } from "./layout/footer/footer.component";
import { EmployeeDataService } from "./services/employee-data-service";
import { DeleteModalComponent } from "./modal/delete-modal/delete-modal.component";
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
    declarations: [
        NavBarComponent,
        FooterComponent,
        DeleteModalComponent,
        NotFoundComponent  

    ],
    imports: [
      
    ],
    exports: [
        NavBarComponent,
        FooterComponent,
        DeleteModalComponent
    ],
    providers: [
        EmployeeDataService,
        DeleteModalComponent,
        NotFoundComponent
    ]
  })
  export class SharedModule { }