import { NgModule } from "@angular/core";
import { EmployeeListComponent } from "./employee/employee-list/employee-list.component";
import { ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { EmployeeFormComponent } from "./employee/employee-form/employee-form.component";
import { ToastrModule } from "ngx-toastr";
import { AppRoutingModule } from "../app-routing.module";
import { SharedModule } from "../shared/shared.module";

@NgModule({
    declarations: [
        EmployeeListComponent,
        EmployeeFormComponent
    ],
    imports: [
        ReactiveFormsModule,
        BrowserModule,
        AppRoutingModule,
        SharedModule,
        ToastrModule.forRoot()
    ],
    exports: [
        EmployeeListComponent,
        EmployeeFormComponent
    ],
    providers: [

    ]
  })
  export class ModulesModule { }