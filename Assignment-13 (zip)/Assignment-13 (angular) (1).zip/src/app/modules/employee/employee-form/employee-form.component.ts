import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { EmployeeDataService } from "../../../shared/services/employee-data-service";
import { IEmployee } from "../../../shared/interface/employee.model";
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-employee-form',
    templateUrl: './employee-form.component.html',
    styleUrls: ['./employee-form.component.scss']
})
export class EmployeeFormComponent implements OnInit {
    employeeForm: FormGroup;
    employeeId: number | null = null;
    designations: string[] = ['Manager', 'Developer', 'Designer', 'Tester']; // List of designations

    constructor(
        private formBuilder: FormBuilder,
        private employeeService: EmployeeDataService,
        private toastr: ToastrService,
        private route: ActivatedRoute,
        private router: Router
    ) {
        this.employeeForm = this.formBuilder.group({
            name: ['', [Validators.required]],
            email: ['', [Validators.required, Validators.email]],
            gender: ['', [Validators.required]],
            address: ['', [Validators.required]],
            designation: ['', [Validators.required]],
            deptId: ['', [Validators.required]],
            dateOfBirth: ['', [Validators.required]],      
            dateOfJoining: ['', [Validators.required]],
            isActive: ['', [Validators.required]],
        });
    }

    ngOnInit(): void {
        this.route.paramMap.subscribe(params => {
            const id = params.get('id');
            if (id) {
                this.employeeId = +id;
                this.loadEmployee();
            }
        });
    }

    loadEmployee(): void {
        if (this.employeeId !== null) {
            this.employeeService.getEmployeeById(this.employeeId).subscribe(employee => {
                this.employeeForm.patchValue({
                    ...employee,
                    dateOfBirth: this.formatDate(employee.dateOfBirth),
                    dateOfJoining: this.formatDate(employee.dateOfJoining),
                });
            }, error => {
                console.error('Error loading employee', error);
                this.toastr.error('Failed to load employee data', 'Error');
            });
        }
    }

    formatDate(dateString: string): string {
        // Format date as yyyy-MM-dd
        const date = new Date(dateString);
        return date.toISOString().split('T')[0];
    }

    save(): void {
      if (this.employeeForm.invalid) return;
  
      const employee: IEmployee = {
          ...this.employeeForm.value,
          deptId: parseInt(this.employeeForm.value.deptId, 10),
          isActive: this.employeeForm.value.isActive === "true"
      };
  
      if (this.employeeId !== null) {
          // Edit existing employee
          this.employeeService.updateEmployee(this.employeeId, employee).subscribe({
              next: () => {
                  this.toastr.success('Employee updated successfully', 'Success');
                  this.router.navigate(['/employees']); // Navigate back to employee list
              },
              error: (error) => {
                  this.handleError(error);
              },
              complete: () => {
                  console.log('Update employee request completed.');
              }
          });
      } else {
          // Create new employee
          this.employeeService.createEmployee(employee).subscribe({
              next: () => {
                  this.toastr.success('Employee created successfully', 'Success');
                  this.employeeForm.reset(); // Optional: Reset form after successful creation
                  this.router.navigate(['/employees']); // Navigate back to employee list
              },
              error: (error) => {
                  this.handleError(error);
              },
              complete: () => {
                  console.log('Create employee request completed.');
              }
          });
      }
  }
  
  handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
        // Check if error is an object and has a message
        if (typeof error.error === 'object') {
            errorMessage = error.error.message || errorMessage;
        } else {
            // If the error is a string, display it directly
            errorMessage = error.error;
        }
    } else if (error.message) {
        // Fallback to generic error message if nothing else is available
        errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
    console.error('Request failed', error);
}
  
}
