﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class CreateEmployeeCommand : EmployeeCommand { }

    public class CreateEmployeeCommandHandler : IRequestHandler<CreateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<EmployeeModel> _genericRepository;

		public CreateEmployeeCommandHandler(IGenericRepository<EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(CreateEmployeeCommand request, CancellationToken cancellationToken)
        {
			ValidationResult validationResult = await new EmployeeCommandValidator().ValidateAsync(request, cancellationToken);
			if (!validationResult.IsValid)
			{
				throw new ValidationException(validationResult.Errors);
			}
			var employeeModel = new EmployeeModel
            {
                Name = request.Name,
                Email = request.Email,
                Gender = request.Gender,
                Address = request.Address,
                Designation = request.Designation,
                DeptId = request.DeptId,
                DateOfBirth = request.DateOfBirth,
                DateOfJoining = request.DateOfJoining,
                IsActive = request.IsActive,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            };
            return await _genericRepository.AddAsync(employeeModel);
        }
    }
}
