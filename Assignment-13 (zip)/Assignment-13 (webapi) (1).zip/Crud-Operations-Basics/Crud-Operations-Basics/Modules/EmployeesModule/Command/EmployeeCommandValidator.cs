﻿using FluentValidation;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class EmployeeCommandValidator : AbstractValidator<EmployeeCommand>
    {

        public EmployeeCommandValidator()
        {

            RuleFor(x => x.Name)
                    .NotNull()
                    .WithMessage("Name cannot be null.")
                    .NotEmpty()
                    .WithMessage("Name cannot be empty.")
                    .Length(1, 50)
                    .WithMessage("Name must be between 1 and 50 characters.")
                    .Matches(@"^[a-zA-Z]+(?: [a-zA-Z]+)?$")
                    .WithMessage("Name can contain only alphabets and at most one space between two words.");



			RuleFor(x => x.Email)
                .NotNull()
                .WithMessage("Email cannot be null.")
                .NotEmpty()
                .WithMessage("Email is required.")
                .EmailAddress()
                .WithMessage("Invalid email address format.")
                .Length(1, 100)
                .WithMessage("Email must not exceed 100 characters.");

            RuleFor(x => x.Gender)
                .NotNull()
                .WithMessage("Gender cannot be null.")
                .NotEmpty()
                .WithMessage("Gender is required.")
                .Must(gender => gender == "Male" || gender == "Female")
                .WithMessage("Gender must be either 'Male' or 'Female'.");

            RuleFor(x => x.Address)
                .NotNull()
                .WithMessage("Address cannot be null.")
                .NotEmpty()
                .WithMessage("Address is required.")
                .Length(1, 255)
                .WithMessage("Address must be between 1 and 255 characters.");

            RuleFor(x => x.Designation)
                .NotNull()
                .WithMessage("Designation cannot be null.")
                .NotEmpty()
                .WithMessage("Designation is required.")
                .Length(1, 100)
                .WithMessage("Designation must be between 1 and 100 characters.");

            RuleFor(x => x.DeptId)
                .GreaterThan(0)
                .WithMessage("Department ID must be greater than zero.");

			RuleFor(x => x.DateOfBirth)
	            .NotNull()
	            .WithMessage("Date of birth cannot be null.")
	            .NotEmpty()
	            .WithMessage("Date of birth is required.")
	            .Must(date => date < DateTime.UtcNow)
	            .WithMessage("Date of birth must be in the past.")
	            .Must(date => date <= DateTime.UtcNow.AddYears(-18))
	            .WithMessage("User must be at least 18 years old.");


			RuleFor(x => x.DateOfJoining)
				.NotNull()
				.WithMessage("Date of joining cannot be null.")
				.NotEmpty()
				.WithMessage("Date of joining is required.")
				.Must(date => date <= DateTime.UtcNow)
				.WithMessage("Date of joining must be in the past or today.");

			RuleFor(x => x)
				.Must(x => x.DateOfBirth < x.DateOfJoining)
				.WithMessage("Date of birth must be prior to the date of joining.");

			RuleFor(x => x.IsActive)
                .NotNull()
                .WithMessage("Active status is required.");

        }

    }
}
