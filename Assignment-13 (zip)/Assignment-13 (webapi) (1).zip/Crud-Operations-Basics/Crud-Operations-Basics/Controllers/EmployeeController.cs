﻿using Crud_Operations_Basics.Modules.EmployeesModule.Command;
using Crud_Operations_Basics.Modules.EmployeesModule.Query;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
	[ApiController]
	public class EmployeeController : ControllerBase
	{
		private readonly ISender _mediatR;

		public EmployeeController(ISender mediatR)
		{
			_mediatR = mediatR;
		}

		[HttpGet("all")]
		public async Task<IActionResult> GetAllEmployees()
		{
			try
			{

				var result = await _mediatR.Send(new GetAllEmployeesQuery());

				if (result == null)
				{
					return NotFound("No employees found.");
				}

				return Ok(result);
			}
			catch (Exception ex)
			{
                return BadRequest(ex.Message);

            }
        }


		[HttpGet("byid/{id}")]
		public async Task<IActionResult> GetEmployeeById([FromRoute] int id)
		{
			try
			{
				var result = await _mediatR.Send(new GetEmployeeByIdQuery { Id = id });

				if (result == null)
				{
					return NotFound(new { Message = $"Employee with ID {id} not found." });
				}

				return Ok(result);
			}
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


		[HttpPost("create")]
		public async Task<object> CreateEmployee([FromBody] CreateEmployeeCommand createEmployeeCommand)
		{
			try
			{
				var isSuccess = await _mediatR.Send(createEmployeeCommand);
				if (!isSuccess)
				{
					return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the employee.");
				}
				else
				{
					return Ok(new { Message = "Employee created successfully." });
				}
			}
			catch (ValidationException ex)
			{
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
			{
                return BadRequest(ex.Message);
            }
        }

		[HttpPut("update/{id}")]
		public async Task<object> UpdateEmployee([FromBody] EmployeeCommand employeeCommand, [FromRoute] int id)
		{
			try
			{
				var updateEmployeeCommand = new UpdateEmployeeCommand
				{
					Id = id,
					Name = employeeCommand.Name,
					Email = employeeCommand.Email,
					Gender = employeeCommand.Gender,
					Address = employeeCommand.Address,
					Designation = employeeCommand.Designation,
					DeptId = employeeCommand.DeptId,
					DateOfBirth = employeeCommand.DateOfBirth,
					DateOfJoining = employeeCommand.DateOfJoining,
					IsActive = employeeCommand.IsActive,
				};


                bool isUpdated = await _mediatR.Send(updateEmployeeCommand);
				if (!isUpdated)
				{
					return NotFound(new { Message = $"Employee with ID {id} not found." });
				}
				else
				{
					return Ok(new { Message = "Employee updated successfully." });
				}
			}
			catch (ValidationException ex)
			{
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
			{
				return BadRequest(ex.Message);
			}
		}
		[HttpDelete("delete/{id}")]
		public async Task<object> DeleteEmployee([FromRoute] int id)
		{

			try
			{
				var result = await _mediatR.Send(new DeleteEmployeeCommand() { Id = id });
				if (result)
				{
					return Ok();
				}
				else
				{
					return NotFound(new { Message = $"Employee with ID {id} not found." });
				}
			}
			catch (ValidationException ex)
			{
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
			{
                return BadRequest(ex.Message);
            }
        }

	}
}
