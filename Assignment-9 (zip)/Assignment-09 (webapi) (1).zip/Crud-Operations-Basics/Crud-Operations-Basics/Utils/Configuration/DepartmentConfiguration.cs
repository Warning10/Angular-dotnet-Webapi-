﻿using Crud_Operations_Basics.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Crud_Operations_Basics.Utils.Configuration
{
    public class DepartmentConfiguration : IEntityTypeConfiguration<DepartmentModel>
    {

        public void Configure(EntityTypeBuilder<DepartmentModel> builder)
        {
            builder.HasData(
                new DepartmentModel()
                {
                    DeptId = 1,
                    DeptName = "Human Resources",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = 2,
                    DeptName = "Information Technology",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = 3,
                    DeptName = "Finance",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = 4,
                    DeptName = "Marketing",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = 5,
                    DeptName = "Operations",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                }
                );
        }
    }
}