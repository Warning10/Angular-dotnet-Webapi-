﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Utils;
using Microsoft.EntityFrameworkCore;

namespace Crud_Operations_Basics.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ApplicationDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        #region Save
        /// <summary>
        /// Method to Save Changes to the Database.
        /// </summary>
        public void SaveAsync()
        {
            _context.SaveChanges();
        }
        #endregion

        #region Get All
        /// <summary>
        /// Retrieves all entities of type <typeparamref name="T"/> from the database.
        /// Asynchronously fetches all records from the database set represented by <see cref="_dbSet"/>
        /// and returns them as a list.
        /// </summary>
        public async Task<List<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }
        #endregion

        #region Get By Id
        /// <summary>
        /// Retrieves an entity of type <typeparamref name="T"/> by its unique identifier.
        /// Asynchronously searches for an entity in the database set represented by <see cref="_dbSet"/> using the provided ID.
        /// </summary>
        public async Task<T> GetByIdAsync(int id)
        {
            return await _dbSet.FindAsync(id);
        }
        #endregion

        #region Add Entity
        /// <summary>
        /// Adds a new entity of type <typeparamref name="T"/> to the database.
        /// Asynchronously adds the provided entity to the database set represented by <see cref="_dbSet"/> 
        /// and saves the changes to the database.
        /// </summary>
        public async Task<bool> AddAsync(T entity)
        {
            try
            {
                _dbSet.Add(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Delete Entity
        /// <summary>
        /// Deletes an existing entity of type <typeparamref name="T"/> from the database.
        /// Asynchronously searches for an entity in the database set represented by <see cref="_dbSet"/> 
        /// using the provided ID. If found, removes the entity from the set and saves the changes to the database.
        /// </summary>
        public async Task<bool> DeleteAsync(int Id)
        {
            var entity = await _dbSet.FindAsync(Id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
        #endregion
    }
}
