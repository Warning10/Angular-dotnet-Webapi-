﻿using Crud_Operations_Basics.Modules.DepartmentsModule.Command;
using Crud_Operations_Basics.Modules.DepartmentsModule.Query;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Crud_Operations_Basics.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly ISender _mediatR;

        public DepartmentController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        #region Get All Departments
        /// <summary>
        /// Retrieves a list of all departments. Returns a 404 status if no departments are found, or a 200 status with the department data if successful. Returns a 400 status with an error message if an exception occurs.
        /// </summary>
        [HttpGet("all")]
        public async Task<IActionResult> GetAllDepartments()
        {
            try
            {
                var departments = await _mediatR.Send(new GetAllDepartmentsQuery());

                if (departments == null || !departments.Any())
                {
                    return NotFound("No departments found.");
                }

                return Ok(departments);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Get Department By ID
        /// <summary>
        /// Retrieves a specific department by ID. Returns a 404 status with a message if the department is not found, a 200 status with the department data if successful, or a 400 status with an error message if an exception occurs.
        /// </summary>
        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetDepartmentById([FromRoute] int id)
        {
            try
            {


                var department = await _mediatR.Send(new GetDepartmentByIdQuery { Id = id });

                if (department == null)
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }

                return Ok(department);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Create Department
        /// <summary>
        /// Creates a new department. Returns a 200 status with a success message if creation is successful, a 400 status with an error message if creation fails, or a 400 status with a validation or error message if exceptions occur.
        /// </summary>
        [HttpPost("create")]
        public async Task<object> CreateDepartment([FromBody] CreateDepartmentCommand createDepartmentCommand)
        {
            try
            {
                var success = await _mediatR.Send(createDepartmentCommand);

                if (success)
                {

                    return Ok(new { Message = "Department created successfully." });

                }
                else
                {
                    return BadRequest("Failed to create department.");
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Update Department
        /// <summary>
        /// Updates an existing department's details by ID. Returns a 404 status with a message if the department is not found, a 200 status with a success message if the update is successful, or a 400 status with validation or error messages if exceptions occur.
        /// </summary>
        [HttpPut("update/{id}")]
        public async Task<object> UpdateDepartment([FromBody] DepartmentCommand departmentCommand, [FromRoute] int id)
        {
            try
            {
                var updateDepartmentCommand = new UpdateDepartmentCommand
                {
                    Id = id,
                    DeptName = departmentCommand.DeptName
                };

                bool isUpdated = await _mediatR.Send(updateDepartmentCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Department updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Delete Department
        /// <summary>
        /// Deletes a department by ID. Returns a 200 status if the deletion is successful, a 404 status with a message if the department is not found, or a 400 status with validation or error messages if exceptions occur.
        /// </summary>
        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteDepartment([FromRoute] int id)
        {
            try
            {
                var result = await _mediatR.Send(new DeleteDepartmentCommand() { Id = id });
                if (result)
                {
                    return Ok("Department Deleted Successfully");
                }
                else
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
