﻿using Microsoft.AspNetCore.JsonPatch;

namespace Crud_Operations_Basics.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        Task<List<T>> GetAllAsync();
        Task<T> GetByIdAsync(int id);
        Task<bool> AddAsync(T entity);
        void SaveAsync();
        Task<bool> DeleteAsync(int Id);
    }
}
