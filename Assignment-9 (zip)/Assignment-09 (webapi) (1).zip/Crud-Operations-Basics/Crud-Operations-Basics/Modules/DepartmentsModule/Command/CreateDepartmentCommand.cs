﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class CreateDepartmentCommand : DepartmentCommand { }

    public class CreateDepartmentCommandHandler : IRequestHandler<CreateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public CreateDepartmentCommandHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the creation of a new department. Validates the request, creates a `DepartmentModel` instance with the provided details, and saves it to the repository. Throws a `ValidationException` if validation fails. Returns `true` if the department was successfully created, otherwise `false`.
        /// </summary>
        public async Task<bool> Handle(CreateDepartmentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new DepartmentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            var departmentModel = new DepartmentModel
            {
                DeptName = request.DeptName,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow,
            };
            return await _genericRepository.AddAsync(departmentModel);
        }
    }
}
