﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class DeleteDepartmentCommand : DepartmentCommand
    {
        public int Id { get; set; }

    }
    public class DeleteDepartmentCommandHandler : IRequestHandler<DeleteDepartmentCommand, bool>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public DeleteDepartmentCommandHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the deletion of a department by ID. Validates the request, checks if the department exists, and deletes it if found. Throws a `ValidationException` if validation fails. Returns `true` if the department was successfully deleted, otherwise `false`.
        /// </summary>
        public async Task<bool> Handle(DeleteDepartmentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new DepartmentCommandIdValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            var existingDepartment = await _genericRepository.GetByIdAsync(request.Id);
            if (existingDepartment == null)
            {
                return false;
            }
            return await _genericRepository.DeleteAsync(request.Id);
        }
    }
}
