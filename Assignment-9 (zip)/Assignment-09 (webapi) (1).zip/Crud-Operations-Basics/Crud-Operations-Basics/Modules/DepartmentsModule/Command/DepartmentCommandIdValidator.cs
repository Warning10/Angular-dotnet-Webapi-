﻿using FluentValidation;

namespace Crud_Operations_Basics.Modules.DepartmentsModule.Command
{
    public class DepartmentCommandIdValidator : AbstractValidator<DeleteDepartmentCommand>
    {
        public DepartmentCommandIdValidator()
        {
            RuleFor(x => x.Id)
                .GreaterThan(0)
                .WithMessage("ID must be a positive integer.");
        }
    }
}
