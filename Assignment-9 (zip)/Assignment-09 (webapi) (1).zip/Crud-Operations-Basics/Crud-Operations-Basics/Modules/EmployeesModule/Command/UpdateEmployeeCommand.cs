﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using FluentValidation;
using FluentValidation.Results;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Command
{
    public class UpdateEmployeeCommand : EmployeeCommand
    {
        public int Id { get; set; }
    }

    public class UpdateEmployeeCommandHandler : IRequestHandler<UpdateEmployeeCommand, bool>
    {
        private readonly IGenericRepository<EmployeeModel> _genericRepository;

        public UpdateEmployeeCommandHandler(IGenericRepository<EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the update of an existing employee's details. Validates the request, creates an `EmployeeModel` with updated information, and updates it in the repository. Throws a `ValidationException` if validation fails. Returns `true` if the update is successful, otherwise `false`.
        /// </summary>
        public async Task<bool> Handle(UpdateEmployeeCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new EmployeeCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var existingEmployee = await _genericRepository.GetByIdAsync(request.Id);
            if (existingEmployee == null)
            {
                return false;
            }

            existingEmployee.FirstName = request.FirstName;
            existingEmployee.LastName = request.LastName;
            existingEmployee.Email = request.Email;
            existingEmployee.Gender = request.Gender;
            existingEmployee.Address = request.Address;
            existingEmployee.Designation = request.Designation;
            existingEmployee.DeptId = request.DeptId;
            existingEmployee.DateOfBirth = request.DateOfBirth;
            existingEmployee.DateOfJoining = request.DateOfJoining;
            existingEmployee.IsActive = request.IsActive;
            existingEmployee.Updated = DateTime.UtcNow;

            _genericRepository.SaveAsync();

            return true;
        }
    }
}
