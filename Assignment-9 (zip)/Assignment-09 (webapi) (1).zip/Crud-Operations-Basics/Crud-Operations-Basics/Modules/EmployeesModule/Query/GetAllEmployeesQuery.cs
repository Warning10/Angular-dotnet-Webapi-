﻿using Crud_Operations_Basics.Interfaces;
using Crud_Operations_Basics.Models;
using MediatR;

namespace Crud_Operations_Basics.Modules.EmployeesModule.Query
{
    public class GetAllEmployeesQuery : IRequest<List<EmployeeModel>> { }

    public class GetAllEmployeesHandler : IRequestHandler<GetAllEmployeesQuery, List<EmployeeModel>>
    {
        private readonly IGenericRepository<EmployeeModel> _genericRepository;

        /// <summary>
        /// Retrieves all employee records from the repository.
        /// </summary>
        public GetAllEmployeesHandler(IGenericRepository<EmployeeModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }
        public async Task<List<EmployeeModel>> Handle(GetAllEmployeesQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllAsync();
        }
    }
}
