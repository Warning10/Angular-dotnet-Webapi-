﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.TeacherModule.Query
{
    public class GetTeacherQuery : IRequest<List<TeacherModel>> { }

    public class GetTeacherQueryHandler : IRequestHandler<GetTeacherQuery, List<TeacherModel>>
    {
        private readonly IGenericRepository<TeacherModel> _genericRepository;

        public GetTeacherQueryHandler(IGenericRepository<TeacherModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Retrieves a list of all teachers from the repository.
        /// </summary>
        public async Task<List<TeacherModel>> Handle(GetTeacherQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllAsync();
        }
    }
}
