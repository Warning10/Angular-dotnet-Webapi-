﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher;
using Student_Teacher.Models;
using Student_Teacher.Modules.DepartmentModule.Command;

namespace Department_Teacher.Modules.DepartmentModule.Command
{
    public class CreateDepartmentCommand : DepartmentCommand { }

    public class CreateDepartmentCommandHandler : IRequestHandler<CreateDepartmentCommand, bool>
    {
        private readonly IGenericRepository<DepartmentModel> _genericRepository;

        public CreateDepartmentCommandHandler(IGenericRepository<DepartmentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the creation of a new department based on the provided command details.
        /// </summary>
        public async Task<bool> Handle(CreateDepartmentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new DepartmentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            var departmentModel = new DepartmentModel
            {
                DeptName = request.DeptName,
                Created = DateTime.Now,
                Updated = DateTime.Now,
            };
            return await _genericRepository.AddAsync(departmentModel);
        }
    }
}

