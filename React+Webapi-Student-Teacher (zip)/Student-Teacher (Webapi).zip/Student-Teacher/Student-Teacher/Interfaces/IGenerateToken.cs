﻿using Student_Teacher.Models;
using System.Security.Claims;

namespace Student_Teacher.Interfaces
{
    public interface IGenerateToken
    {
        public Task<TokenModel> GenerateTokens(string username);
        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
