﻿namespace Student_Teacher
{
    public interface IGenericRepository<T> where T : class
    {
        Task<List<T>> GetAllAsync();
        Task<T> GetByIdAsync(Guid id);
        Task<bool> AddAsync(T entity);
        void SaveData();
        Task<bool> DeleteAsync(Guid Id);
    }
}
