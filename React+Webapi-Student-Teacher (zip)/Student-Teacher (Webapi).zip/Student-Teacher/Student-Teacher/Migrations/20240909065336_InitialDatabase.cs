﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshTokenExpiryTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Students_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Teachers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teachers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Teachers_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7258), "Computer", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7258) },
                    { new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7262), "Mechanical", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7262) },
                    { new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7260), "Information Technology", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7260) },
                    { new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7263), "Civil", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7263) },
                    { new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7265), "Production", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7265) }
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("3694227a-5e6c-404b-b2a0-c2d1c2ef2c86"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6928), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6927), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6929) },
                    { new Guid("6353972f-b5af-4a9e-bfbb-8f9dc4d46f1c"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6937), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6936), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6937) },
                    { new Guid("6cda7083-3169-4d43-86df-3d4e397a6662"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6944), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6944), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6945) },
                    { new Guid("8080d416-e704-422b-a109-03d241dd407d"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6940), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6939), "Diana", "Female", "8th", "Brown", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6940) },
                    { new Guid("fdcba216-acea-4945-a468-ace385008d61"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6933), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6933), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(6934) }
                });

            migrationBuilder.InsertData(
                table: "Teachers",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("4baab6d6-bb55-44f7-9bf2-c1f1a1fa6273"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7154), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7155) },
                    { new Guid("5c7e8e10-6982-423b-8db1-1076ed60c640"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7145), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7146) },
                    { new Guid("8be0f16f-069f-4598-8067-f6513c898e8b"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7133), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7133) },
                    { new Guid("dfca615e-5764-45eb-925e-d04ebd4bd09b"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7148), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7149) },
                    { new Guid("e473fe59-49a9-441b-a5b6-c41d70b70a39"), new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7151), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 9, 9, 6, 53, 35, 778, DateTimeKind.Utc).AddTicks(7152) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Students_DeptId",
                table: "Students",
                column: "DeptId");

            migrationBuilder.CreateIndex(
                name: "IX_Teachers_DeptId",
                table: "Teachers",
                column: "DeptId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Teachers");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
