﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Student_Teacher.Models;

namespace Student_Teacher.Utils.Configuration
{
    public class TeacherConfiguration : IEntityTypeConfiguration<TeacherModel>
    {
        public void Configure(EntityTypeBuilder<TeacherModel> builder)
        {
            builder.HasData(
                    new TeacherModel
                    {
                        Id = Guid.NewGuid(),
                        FirstName = "Amit",
                        LastName = "Deshmukh",
                        Email = "amit.deshmukh@example.com",
                        Gender = "Male",
                        DeptId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                        HireDate = new DateTime(2010, 8, 15),
                        Position = "Math Teacher",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new TeacherModel
                    {
                        Id = Guid.NewGuid(),
                        FirstName = "Snehal",
                        LastName = "Patil",
                        Email = "snehal.patil@example.com",
                        Gender = "Female",
                        DeptId = Guid.Parse("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"),
                        HireDate = new DateTime(2015, 1, 20),
                        Position = "Science Teacher",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new TeacherModel
                    {
                        Id = Guid.NewGuid(),
                        FirstName = "Rajesh",
                        LastName = "Kulkarni",
                        Email = "rajesh.kulkarni@example.com",
                        Gender = "Male",
                        DeptId = Guid.Parse("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"),
                        HireDate = new DateTime(2018, 6, 10),
                        Position = "History Teacher",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new TeacherModel
                    {
                        Id = Guid.NewGuid(),
                        FirstName = "Pooja",
                        LastName = "Jadhav",
                        Email = "pooja.jadhav@example.com",
                        Gender = "Female",
                        DeptId = Guid.Parse("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"),
                        HireDate = new DateTime(2020, 3, 5),
                        Position = "English Teacher",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    },
                    new TeacherModel
                    {
                        Id = Guid.NewGuid(),
                        FirstName = "Vikram",
                        LastName = "Shinde",
                        Email = "vikram.shinde@example.com",
                        Gender = "Male",
                        DeptId = Guid.Parse("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"),
                        HireDate = new DateTime(2022, 11, 1),
                        Position = "Physical Education Teacher",
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    }
                );
        }
    }
}
