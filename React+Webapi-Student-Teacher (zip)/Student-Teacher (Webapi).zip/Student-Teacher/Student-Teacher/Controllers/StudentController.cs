﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Modules.StudentModule.Command;
using Student_Teacher.Modules.StudentModule.Query;

namespace Student_Teacher.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ISender _mediatR;

        public StudentController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        #region GetAllStudents
        /// <summary>
        /// Retrieves a list of all students from the system.
        /// </summary>
        [HttpGet("all")]
        public async Task<IActionResult> GetAllStudents()
        {
            try
            {

                var result = await _mediatR.Send(new GetStudentQuery());

                if (result == null)
                {
                    return NotFound("No students found.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }
        #endregion

        #region GetStudentById
        /// <summary>
        /// Retrieves a student's details based on the provided student ID.
        /// </summary>
        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetStudentById([FromRoute] Guid id)
        {
            try
            {
                var result = await _mediatR.Send(new GetStudentByIdQuery { Id = id });

                if (result == null)
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region CreateStudent
        /// <summary>
        /// Creates a new student in the system based on the provided student details.
        /// </summary>
        [HttpPost("create")]
        public async Task<object> CreateStudent([FromBody] CreateStudentCommand createStudentCommand)
        {
            try
            {
                var isSuccess = await _mediatR.Send(createStudentCommand);
                if (!isSuccess)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the student.");
                }
                else
                {
                    return Ok(new { Message = "Student created successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region UpdateStudent
        /// <summary>
        /// Updates the details of an existing student based on the provided student ID and updated information.
        /// </summary>
        [HttpPut("update/{id}")]
        public async Task<object> UpdateStudent([FromBody] StudentCommand studentCommand, [FromRoute] Guid id)
        {
            try
            {
                var updateStudentCommand = new UpdateStudentCommand
                {
                    Id = id,
                    FirstName = studentCommand.FirstName,
                    LastName = studentCommand.LastName,
                    Email = studentCommand.Email,
                    Gender = studentCommand.Gender,
                    DeptId = studentCommand.DeptId,
                    DateOfBirth = studentCommand.DateOfBirth,
                    EnrollmentDate = studentCommand.EnrollmentDate,
                    Grade = studentCommand.Grade,
                };


                bool isUpdated = await _mediatR.Send(updateStudentCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Student updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region DeleteStudent
        /// <summary>
        /// Deletes a student from the system based on the provided student ID.
        /// </summary>
        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteStudent([FromRoute] Guid id)
        {

            try
            {
                var result = await _mediatR.Send(new DeleteStudentCommand() { Id = id });
                if (result)
                {
                    return Ok(new { Message = $"Student with ID {id} deleted successfully" });
                }
                else
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
