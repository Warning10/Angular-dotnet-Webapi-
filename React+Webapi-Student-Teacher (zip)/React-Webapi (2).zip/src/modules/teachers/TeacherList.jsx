import { useEffect, useState } from "react";
import {
  getTeachers,
  deleteTeacher,
} from "../../shared/services/TeacherService";
import { Link, useNavigate } from "react-router-dom";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";
import toast from "react-hot-toast";

const TeacherList = () => {
  const [teachers, setTeachers] = useState([]);
  const [deptLookup, setDeptLookup] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchTeachers();
    fetchDepartments();
  }, []);

  const fetchTeachers = async () => {
    try {
      const response = await getTeachers();
      setTeachers(response.data);
    } catch (error) {
      console.error("Error fetching teachers:", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      setDeptLookup(createDeptLookup(response.data));
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteTeacher(id);
      toast.success("Teacher deleted successfully");
      fetchTeachers();
    } catch (error) {
      toast.error("Error deleting teacher:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Teachers List</h2>
      <div className="d-flex justify-content-end mb-3">
        <Link to="/teachers/create" className="btn btn-primary">
          Add Teacher
        </Link>
      </div>
      <div className="table-responsive">
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Position</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {teachers.map((teacher) => (
              <tr key={teacher.id}>
                <td>
                  {teacher.firstName} {teacher.lastName}
                </td>
                <td>{teacher.email}</td>
                <td>{teacher.position}</td>
                <td>{deptLookup[teacher.deptId] || "N/A"}</td>
                <td>
                  <Link
                    to={`/teachers/view/${teacher.id}`}
                    className="btn btn-info btn-sm me-2"
                  >
                    View
                  </Link>
                  <Link
                    to={`/teachers/edit/${teacher.id}`}
                    className="btn btn-warning btn-sm me-2"
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() => handleDelete(teacher.id)}
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TeacherList;
