import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getTeacherById } from "../../shared/services/TeacherService";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";
import "../../assets/css/List.css";

const TeacherDetail = () => {
  const { id } = useParams();
  const [teacher, setTeacher] = useState(null);
  const [deptLookup, setDeptLookup] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchTeacher(id);
    fetchDepartments();
  }, [id]);

  const fetchTeacher = async (teacherId) => {
    const response = await getTeacherById(teacherId);
    setTeacher(response.data);
  };

  const fetchDepartments = async () => {
    const response = await getAllDepartments();
    setDeptLookup(createDeptLookup(response.data));
  };

  if (!teacher) return <div>Loading...</div>;

  return (
    <div className="container mt-4">
      <h2>Teacher Details</h2>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">
            {teacher.firstName} {teacher.lastName}
          </h5>
          <p className="card-text">
            <strong>Email:</strong> {teacher.email}
          </p>
          <p className="card-text">
            <strong>Gender:</strong> {teacher.gender || "N/A"}
          </p>
          <p className="card-text">
            <strong>Department:</strong> {deptLookup[teacher.deptId] || "N/A"}
          </p>
          <p className="card-text">
            <strong>Hire Date:</strong> {teacher.hireDate.split("T")[0]}
          </p>
          <p className="card-text">
            <strong>Position:</strong> {teacher.position || "N/A"}
          </p>
          <button
            className="btn btn-secondary"
            onClick={() => navigate("/teachers")}
          >
            Back to List
          </button>
          <button
            className="btn btn-primary ms-2"
            onClick={() => navigate(`/teachers/edit/${teacher.id}`)}
          >
            Edit Teacher
          </button>
        </div>
      </div>
    </div>
  );
};

export default TeacherDetail;
