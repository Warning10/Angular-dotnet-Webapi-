import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getStudentById } from "../../shared/services/StudentService";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";

const StudentDetail = () => {
  const { id } = useParams();
  const [student, setStudent] = useState(null);
  const [deptLookup, setDeptLookup] = useState({});
  const navigate = useNavigate(); // Use useNavigate hook

  useEffect(() => {
    fetchStudent(id);
    fetchDepartments();
  }, [id]);

  const fetchStudent = async (studentId) => {
    try {
      const response = await getStudentById(studentId);
      setStudent(response.data);
    } catch (error) {
      console.error("Error fetching student:", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      const departmentsData = response.data;
      setDeptLookup(createDeptLookup(departmentsData));
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  if (!student) {
    return <p>Loading student details...</p>;
  }

  return (
    <div className="container mt-4">
      <h2>Student Details</h2>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">
            {student.firstName} {student.lastName}
          </h5>
          <p className="card-text">
            <strong>Email:</strong> {student.email}
          </p>
          <p className="card-text">
            <strong>Gender:</strong> {student.gender || "N/A"}
          </p>
          <p className="card-text">
            <strong>Department:</strong> {deptLookup[student.deptId] || "N/A"}
          </p>
          <p className="card-text">
            <strong>Date of Birth:</strong> {student.dateOfBirth.split("T")[0]}
          </p>
          <p className="card-text">
            <strong>Enrollment Date:</strong>{" "}
            {student.enrollmentDate.split("T")[0]}
          </p>
          <p className="card-text">
            <strong>Grade:</strong> {student.grade || "N/A"}
          </p>
          <button
            className="btn btn-secondary"
            onClick={() => navigate("/students")}
          >
            Back to List
          </button>
          <button
            className="btn btn-primary ms-2"
            onClick={() => navigate(`/students/edit/${student.id}`)}
          >
            Edit Student
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudentDetail;
