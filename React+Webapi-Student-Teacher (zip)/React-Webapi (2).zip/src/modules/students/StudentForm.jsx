import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  createStudent,
  getStudentById,
  updateStudent,
} from "../../shared/services/StudentService";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import toast from "react-hot-toast";

const StudentForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [departments, setDepartments] = useState([]);
  const [initialValues, setInitialValues] = useState({
    firstName: "",
    lastName: "",
    email: "",
    gender: "",
    deptId: "",
    dateOfBirth: "",
    enrollmentDate: "",
    grade: "",
  });

  useEffect(() => {
    fetchDepartments();
    if (id) {
      fetchStudent(id);
    }
  }, [id]);

  const fetchStudent = async (studentId) => {
    try {
      const response = await getStudentById(studentId);
      const studentData = response.data;
      setInitialValues(studentData);
      formik.setValues(studentData); // Initialize Formik with fetched data
    } catch (error) {
      console.error("Error fetching student:", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      setDepartments(response.data);
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: Yup.object({
      firstName: Yup.string().required("First name is required"),
      lastName: Yup.string().required("Last name is required"),
      email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
      gender: Yup.string().required("Gender is required"),
      deptId: Yup.string().required("Department is required"),
      dateOfBirth: Yup.date().required("Date of Birth is required"),
      enrollmentDate: Yup.date().required("Enrollment Date is required"),
      grade: Yup.string().required("Grade is required"),
    }),
    onSubmit: async (values) => {
      try {
        if (id) {
          await updateStudent(id, values);
          toast.success("Data updated succesfully");
        } else {
          await createStudent(values);
          toast.success("Data added succesfully");
        }
        navigate("/students");
      } catch (error) {
        console.error("Error saving student:", error);
      }
    },
    enableReinitialize: true, 
  });

  const handleReset = () => {
    formik.setValues(initialValues); 
  };

  return (
    <div className="container mt-4">
      <h2>{id ? "Edit" : "Add"} Student</h2>
      <form onSubmit={formik.handleSubmit}>
        <div className="mb-3">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formik.values.firstName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.firstName && formik.errors.firstName ? (
            <div className="text-danger">{formik.errors.firstName}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formik.values.lastName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.lastName && formik.errors.lastName ? (
            <div className="text-danger">{formik.errors.lastName}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formik.values.email}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.email && formik.errors.email ? (
            <div className="text-danger">{formik.errors.email}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="gender">Gender</label>
          <select
            id="gender"
            name="gender"
            value={formik.values.gender}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          {formik.touched.gender && formik.errors.gender ? (
            <div className="text-danger">{formik.errors.gender}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="deptId">Department</label>
          <select
            id="deptId"
            name="deptId"
            value={formik.values.deptId}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          >
            <option value="">Select Department</option>
            {departments.map((dept) => (
              <option key={dept.deptId} value={dept.deptId}>
                {dept.deptName}
              </option>
            ))}
          </select>
          {formik.touched.deptId && formik.errors.deptId ? (
            <div className="text-danger">{formik.errors.deptId}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="dateOfBirth">Date of Birth</label>
          <input
            type="date"
            id="dateOfBirth"
            name="dateOfBirth"
            value={formik.values.dateOfBirth.split("T")[0]} // Format date for input
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.dateOfBirth && formik.errors.dateOfBirth ? (
            <div className="text-danger">{formik.errors.dateOfBirth}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="enrollmentDate">Enrollment Date</label>
          <input
            type="date"
            id="enrollmentDate"
            name="enrollmentDate"
            value={formik.values.enrollmentDate.split("T")[0]} // Format date for input
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.enrollmentDate && formik.errors.enrollmentDate ? (
            <div className="text-danger">{formik.errors.enrollmentDate}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="grade">Grade</label>
          <input
            type="text"
            id="grade"
            name="grade"
            value={formik.values.grade}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            className="form-control"
            required
          />
          {formik.touched.grade && formik.errors.grade ? (
            <div className="text-danger">{formik.errors.grade}</div>
          ) : null}
        </div>

        <button type="submit" className="btn btn-primary">
          Save
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="btn btn-secondary ms-2"
        >
          Reset
        </button>
        <button
          type="button"
          onClick={() => navigate("/students")}
          className="btn btn-secondary ms-2"
        >
          Back
        </button>
      </form>
    </div>
  );
};

export default StudentForm;
