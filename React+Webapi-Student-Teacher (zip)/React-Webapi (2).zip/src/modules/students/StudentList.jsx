import { useEffect, useState } from "react";
import {
  deleteStudent,
  getStudents,
} from "../../shared/services/StudentService";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { Link } from "react-router-dom";
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";
import toast from "react-hot-toast";
import "../../assets/css/List.css";
import DeleteModal from "../../shared/modal/DeleteModal";

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [deptLookup, setDeptLookup] = useState({});
  const [studentIdToDelete, setStudentIdToDelete] = useState(null);
  const [confirmationMessage, setConfirmationMessage] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchStudents();
    fetchDepartments();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await getStudents();
      setStudents(response.data);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      const departmentsData = response.data;
      setDeptLookup(createDeptLookup(departmentsData));
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  const handleDelete = async () => {
    try {
      await deleteStudent(studentIdToDelete);
      toast.success("Student deleted");
      setIsModalOpen(false);
      fetchStudents();
    } catch (error) {
      toast.error("Error deleting student");
    }
  };

  const handleDeleteClick = (id, firstName) => {
    setStudentIdToDelete(id);
    setConfirmationMessage(
      `Are you sure you want to delete Student with Name: ${firstName}?`
    );
    setIsModalOpen(true);
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Students List</h2>
      <div className="d-flex justify-content-end mb-3">
        <Link to="/students/create" className="btn btn-primary">
          Add Student
        </Link>
      </div>
      <div className="table-responsive">
        <table className="table table-striped table-bordered">
          <thead className="thead-dark">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.id}>
                <td>
                  {student.firstName} {student.lastName}
                </td>
                <td>{student.email}</td>
                <td>{deptLookup[student.deptId] || "N/A"}</td>
                <td>
                  <Link
                    to={`/students/view/${student.id}`}
                    className="btn btn-info btn-sm me-2"
                  >
                    View
                  </Link>
                  <Link
                    to={`/students/edit/${student.id}`}
                    className="btn btn-warning btn-sm me-2"
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() =>
                      handleDeleteClick(student.id, student.firstName)
                    }
                    className="btn btn-danger btn-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isModalOpen && (
        <DeleteModal
          message={confirmationMessage}
          onConfirm={handleDelete}
          onCancel={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
};

export default StudentList;
