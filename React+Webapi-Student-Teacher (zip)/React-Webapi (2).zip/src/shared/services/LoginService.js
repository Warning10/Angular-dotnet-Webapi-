import axios from "axios";

const apiUrl = "https://localhost:7066/api/Authenticate";
const axiosInstance = axios.create({
  baseURL: apiUrl,
});

const LoginService = {
  // Function to authenticate user
  getUserCredentials: (data) => {
    return axiosInstance.post("/login", data);
  },

  // Function to generate refresh token
  generateRefreshToken: (data) => {
    return axiosInstance.post("/refreshToken", data);
  },

  // Set authentication token
  setAuthToken: (token) => {
    if (token) {
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    } else {
      delete axios.defaults.headers.common["Authorization"];
    }
  },
};

export default LoginService;
