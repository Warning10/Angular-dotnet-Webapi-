import { axiosInstance } from "../../utils/jwtutils";

const API_URL = "https://localhost:7066/api/Department";

export const getAllDepartments = () => axiosInstance.get(`${API_URL}/all`);

// Fetch a department by ID
export const getDepartmentById = (id) =>
  axiosInstance.get(`${API_URL}/byid/${id}`);
