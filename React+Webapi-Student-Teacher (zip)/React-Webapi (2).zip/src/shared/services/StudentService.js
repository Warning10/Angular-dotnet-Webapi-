import { axiosInstance } from "../../utils/jwtutils";

export const getStudents = () => axiosInstance.get(`Student/all`);
export const getStudentById = (id) => axiosInstance.get(`Student/byid/${id}`);
export const createStudent = (studentData) =>
  axiosInstance.post(`Student/create`, studentData);
export const updateStudent = (id, studentData) =>
  axiosInstance.put(`Student/update/${id}`, studentData);
export const deleteStudent = (id) =>
  axiosInstance.delete(`Student/delete/${id}`);
