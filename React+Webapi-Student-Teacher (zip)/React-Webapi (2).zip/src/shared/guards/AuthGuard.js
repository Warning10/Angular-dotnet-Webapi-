import { isExpired } from "react-jwt";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import LoginService from "../services/LoginService";

const AuthGuard = ({ element: Component }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    checkAuthentication();
  }, [navigate]);

  const checkAuthentication = async () => {
    const accessToken = localStorage.getItem("accessToken");
    const refreshToken = localStorage.getItem("refreshToken");

    if (accessToken && !isExpired(accessToken)) {
      setIsAuthenticated(true);
    } else if (accessToken && refreshToken && isExpired(accessToken)) {
      try {
        const response = await LoginService.generateRefreshToken({
          accessToken,
          refreshToken,
        });
        localStorage.setItem("accessToken", response.data.accessToken);
        localStorage.setItem("refreshToken", response.data.refreshToken);
        setIsAuthenticated(true);
      } catch {
        toast.error("Session expired, please login again");
        localStorage.clear();
        setIsAuthenticated(false);
        navigate("/");
      }
    } else {
      setIsAuthenticated(false);
      localStorage.clear();
      toast.error("Unauthorized Access. Please login!");
      navigate("/");
    }
  };

  return isAuthenticated ? <Component /> : null;
};

export default AuthGuard;
