import "../../assets/css/Delete-modal.css";

const DeleteModal = ({ message, onConfirm, onCancel }) => {
  return (
    <div className="modalclass">
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title mb-3">Confirm Action</h5>
            <button type="button" className="close" onClick={onCancel}>
              &times;
            </button>
          </div>
          <div className="modal-body">
            <p>{message}</p>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onCancel}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={onConfirm}
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteModal;
