import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from "./shared/layout/Header";
import StudentList from "./modules/students/StudentList";
import StudentForm from "./modules/students/StudentForm";
import StudentDetail from "./modules/students/StudentDetail";
import TeacherList from "./modules/teachers/TeacherList";
import TeacherForm from "./modules/teachers/TeacherForm";
import TeacherDetail from "./modules/teachers/TeacherDetail";
import Footer from "./shared/layout/Footer";
import Login from "./authentication/Login";
import AuthGuard from "./shared/guards/AuthGuard";

const App = () => {
  return (
    <Router>
      <div className="d-flex flex-column min-vh-100">
        <Header />
        <main className="flex-grow-1">
          <div className="container mt-4">
            <Routes>
              <Route path="" element={<Login />} />
              <Route path="/login" element={<Login />} />
              {/* Student Routes */}
              <Route path="/students" element={<AuthGuard element={StudentList}/>} />
              <Route path="/students/create" element={<StudentForm />} />
              <Route path="/students/edit/:id" element={<StudentForm />} />
              <Route path="/students/view/:id" element={<StudentDetail />} />
              {/* Teacher Routes */}
              <Route path="/teachers" element={<TeacherList />} />
              <Route path="/teachers/create" element={<TeacherForm />} />
              <Route path="/teachers/edit/:id" element={<TeacherForm />} />
              <Route path="/teachers/view/:id" element={<TeacherDetail />} />
            </Routes>
          </div>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
