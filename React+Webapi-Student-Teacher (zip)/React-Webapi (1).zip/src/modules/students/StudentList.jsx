import { useEffect, useState } from "react";
import {
  deleteStudent,
  getStudents,
} from "../../shared/services/StudentService";
import { getAllDepartments } from "../../shared/services/DepartmentService"; // Import the department service
import { Link } from "react-router-dom"; // Import useNavigate
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [deptLookup, setDeptLookup] = useState({});

  useEffect(() => {
    fetchStudents();
    fetchDepartments();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await getStudents();
      setStudents(response.data);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      const departmentsData = response.data;
      setDeptLookup(createDeptLookup(departmentsData)); // Use the constant function
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteStudent(id);
      fetchStudents();
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Students List</h2>
      <Link to="/students/create" className="btn btn-primary mb-2">
        Add Student
      </Link>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <td>
                {student.firstName} {student.lastName}
              </td>
              <td>{student.email}</td>
              <td>{deptLookup[student.deptId] || "N/A"}</td>
              <td>
                <Link
                  to={`/students/view/${student.id}`} // Add View Button
                  className="btn btn-info btn-sm ms-2"
                >
                  View
                </Link>
                <Link
                  to={`/students/edit/${student.id}`}
                  className="btn btn-warning btn-sm ms-2"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDelete(student.id)}
                  className="btn btn-danger btn-sm ms-2"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentList;
