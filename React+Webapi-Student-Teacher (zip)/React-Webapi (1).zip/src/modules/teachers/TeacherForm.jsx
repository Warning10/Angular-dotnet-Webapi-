import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  getTeacherById,
  createTeacher,
  updateTeacher,
} from "../../shared/services/TeacherService";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { useFormik } from "formik";
import * as Yup from "yup";

const TeacherForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [departments, setDepartments] = useState([]);
  const [initialValues, setInitialValues] = useState({
    firstName: "",
    lastName: "",
    email: "",
    gender: "",
    deptId: "",
    hireDate: "",
    position: "",
  });

  useEffect(() => {
    if (id) {
      fetchTeacher(id);
    }
    fetchDepartments();
  }, [id]);

  const fetchTeacher = async (teacherId) => {
    const response = await getTeacherById(teacherId);
    const teacherData = response.data;
    setInitialValues({
      firstName: teacherData.firstName,
      lastName: teacherData.lastName,
      email: teacherData.email,
      gender: teacherData.gender,
      deptId: teacherData.deptId,
      hireDate: teacherData.hireDate.split("T")[0],
      position: teacherData.position,
    });
  };

  const fetchDepartments = async () => {
    const response = await getAllDepartments();
    setDepartments(response.data);
  };

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: initialValues,
    validationSchema: Yup.object({
      firstName: Yup.string().required("First name is required"),
      lastName: Yup.string().required("Last name is required"),
      email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
      gender: Yup.string().required("Gender is required"),
      deptId: Yup.string().required("Department is required"),
      hireDate: Yup.date().required("Hire date is required"),
      position: Yup.string().required("Position is required"),
    }),
    onSubmit: async (values) => {
      if (id) {
        await updateTeacher(id, values);
      } else {
        await createTeacher(values);
      }
      navigate("/teachers");
    },
  });

  return (
    <div className="container mt-4">
      <h2>{id ? "Edit" : "Add"} Teacher</h2>
      <form onSubmit={formik.handleSubmit}>
        <div className="mb-3">
          <label htmlFor="firstName">First Name</label>
          <input
            id="firstName"
            name="firstName"
            type="text"
            className={`form-control ${
              formik.touched.firstName && formik.errors.firstName
                ? "is-invalid"
                : ""
            }`}
            value={formik.values.firstName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.firstName && formik.errors.firstName ? (
            <div className="invalid-feedback">{formik.errors.firstName}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="lastName">Last Name</label>
          <input
            id="lastName"
            name="lastName"
            type="text"
            className={`form-control ${
              formik.touched.lastName && formik.errors.lastName
                ? "is-invalid"
                : ""
            }`}
            value={formik.values.lastName}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.lastName && formik.errors.lastName ? (
            <div className="invalid-feedback">{formik.errors.lastName}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            className={`form-control ${
              formik.touched.email && formik.errors.email ? "is-invalid" : ""
            }`}
            value={formik.values.email}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.email && formik.errors.email ? (
            <div className="invalid-feedback">{formik.errors.email}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="gender">Gender</label>
          <select
            id="gender"
            name="gender"
            className={`form-control ${
              formik.touched.gender && formik.errors.gender ? "is-invalid" : ""
            }`}
            value={formik.values.gender}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          {formik.touched.gender && formik.errors.gender ? (
            <div className="invalid-feedback">{formik.errors.gender}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="deptId">Department</label>
          <select
            id="deptId"
            name="deptId"
            className={`form-control ${
              formik.touched.deptId && formik.errors.deptId ? "is-invalid" : ""
            }`}
            value={formik.values.deptId}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          >
            <option value="">Select Department</option>
            {departments.map((dept) => (
              <option key={dept.deptId} value={dept.deptId}>
                {dept.deptName}
              </option>
            ))}
          </select>
          {formik.touched.deptId && formik.errors.deptId ? (
            <div className="invalid-feedback">{formik.errors.deptId}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="hireDate">Hire Date</label>
          <input
            id="hireDate"
            name="hireDate"
            type="date"
            className={`form-control ${
              formik.touched.hireDate && formik.errors.hireDate
                ? "is-invalid"
                : ""
            }`}
            value={formik.values.hireDate}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.hireDate && formik.errors.hireDate ? (
            <div className="invalid-feedback">{formik.errors.hireDate}</div>
          ) : null}
        </div>

        <div className="mb-3">
          <label htmlFor="position">Position</label>
          <input
            id="position"
            name="position"
            type="text"
            className={`form-control ${
              formik.touched.position && formik.errors.position
                ? "is-invalid"
                : ""
            }`}
            value={formik.values.position}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.position && formik.errors.position ? (
            <div className="invalid-feedback">{formik.errors.position}</div>
          ) : null}
        </div>

        <button type="submit" className="btn btn-primary">
          Save
        </button>
        <button
          type="button"
          onClick={() => formik.resetForm()}
          className="btn btn-secondary ms-2"
        >
          Reset
        </button>
        <button
          type="button"
          onClick={() => navigate("/teachers")}
          className="btn btn-secondary ms-2"
        >
          Back
        </button>
      </form>
    </div>
  );
};

export default TeacherForm;
