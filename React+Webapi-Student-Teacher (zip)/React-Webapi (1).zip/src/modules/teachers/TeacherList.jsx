import { useEffect, useState } from "react";
import {
  getTeachers,
  deleteTeacher,
} from "../../shared/services/TeacherService";
import { Link, useNavigate } from "react-router-dom";
import { getAllDepartments } from "../../shared/services/DepartmentService";
import { createDeptLookup } from "../../shared/constants/DepartmentConstants";

const TeacherList = () => {
  const [teachers, setTeachers] = useState([]);
  const [deptLookup, setDeptLookup] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchTeachers();
    fetchDepartments();
  }, []);

  const fetchTeachers = async () => {
    const response = await getTeachers();
    setTeachers(response.data);
  };

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      setDeptLookup(createDeptLookup(response.data));
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };

  const handleDelete = async (id) => {
    await deleteTeacher(id);
    fetchTeachers();
  };

  return (
    <div className="container mt-4">
      <h2>Teachers List</h2>
      <Link to="/teachers/create" className="btn btn-primary mb-2">
        Add Teacher
      </Link>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Position</th>
            <th>Department</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {teachers.map((teacher) => (
            <tr key={teacher.id}>
              <td>
                {teacher.firstName} {teacher.lastName}
              </td>
              <td>{teacher.email}</td>
              <td>{teacher.position}</td>
              <td>{deptLookup[teacher.deptId] || "N/A"}</td>
              <td>
                <Link
                  to={`/teachers/edit/${teacher.id}`}
                  className="btn btn-warning btn-sm"
                >
                  Edit
                </Link>
                <button
                  onClick={() => navigate(`/teachers/view/${teacher.id}`)}
                  className="btn btn-info btn-sm ms-2"
                >
                  View
                </button>
                <button
                  onClick={() => handleDelete(teacher.id)}
                  className="btn btn-danger btn-sm ms-2"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TeacherList;
