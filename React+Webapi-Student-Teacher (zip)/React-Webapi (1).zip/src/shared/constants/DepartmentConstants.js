export const createDeptLookup = (departmentsData) => {
  return departmentsData.reduce((acc, dept) => {
    acc[dept.deptId] = dept.deptName;
    return acc;
  }, {});
};
