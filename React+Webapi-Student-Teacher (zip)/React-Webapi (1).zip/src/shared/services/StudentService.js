import axios from "axios";

const API_URL = "https://localhost:7066/api/Student";

export const getStudents = () => axios.get(`${API_URL}/all`);
export const getStudentById = (id) => axios.get(`${API_URL}/byid/${id}`);
export const createStudent = (studentData) =>
  axios.post(`${API_URL}/create`, studentData);
export const updateStudent = (id, studentData) =>
  axios.put(`${API_URL}/update/${id}`, studentData);
export const deleteStudent = (id) => axios.delete(`${API_URL}/delete/${id}`);
