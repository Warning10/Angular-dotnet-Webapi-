import axios from "axios";

const API_URL = "https://localhost:7066/api/Teacher"; // Replace with your API base URL

export const getTeachers = () => axios.get(`${API_URL}/all`);
export const getTeacherById = (id) => axios.get(`${API_URL}/byid/${id}`);
export const createTeacher = (teacherData) =>
  axios.post(`${API_URL}/create`, teacherData);
export const updateTeacher = (id, teacherData) =>
  axios.put(`${API_URL}/update/${id}`, teacherData);
export const deleteTeacher = (id) => axios.delete(`${API_URL}/delete/${id}`);
