import axios from "axios";

const API_BASE_URL = "https://localhost:7066/api/Authenticate"; // Replace with your API base URL

export const login = async (userName, password) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/login`, {
      userName,
      password,
    });

    // Assuming the response contains accessToken and refreshToken
    return response.data;
  } catch (error) {
    console.error("Login failed:", error);
    throw error;
  }
};

export const setAuthToken = (token) => {
  if (token) {
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    delete axios.defaults.headers.common["Authorization"];
  }
};

export const reLoginUser = ({ accessToken, refreshToken }) => {
  return axios.post(`${API_BASE_URL}/refreshToken`, { accessToken, refreshToken });
};
