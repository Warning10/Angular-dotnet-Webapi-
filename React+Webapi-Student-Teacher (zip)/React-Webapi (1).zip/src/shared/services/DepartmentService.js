import axios from "axios";

const API_URL = "https://localhost:7066/api/Department";

export const getAllDepartments = () => axios.get(`${API_URL}/all`);

// Fetch a department by ID
export const getDepartmentById = (id) => axios.get(`${API_URL}/byid/${id}`);
