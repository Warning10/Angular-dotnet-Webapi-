export interface Department {
    deptId: string;
    deptName: string;

}
