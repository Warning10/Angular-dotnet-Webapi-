import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department } from '../interface/department-interface';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  private apiUrl = 'https://localhost:7066/api/Department/all'; // Replace with your API URL

  constructor(private http: HttpClient) { }

  getAllDepartments(): Observable<Department[]> {
    return this.http.get<Department[]>(this.apiUrl);
  }
}
