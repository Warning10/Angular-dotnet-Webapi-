import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavBarComponent } from './layout/nav-bar/nav-bar.component';
import { SideBarComponent } from './layout/side-bar/side-bar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { AppRoutingModule } from '../app-routing.module';
import { DeleteModalComponent } from './modal/delete-modal/delete-modal.component';



@NgModule({
  declarations: [
    NavBarComponent,
    SideBarComponent,
    FooterComponent,
    DeleteModalComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
  ],
  exports : [
    NavBarComponent,
    SideBarComponent,
    FooterComponent,
    DeleteModalComponent
  ]
})
export class SharedModule { }
