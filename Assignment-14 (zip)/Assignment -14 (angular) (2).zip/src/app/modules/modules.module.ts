import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentListComponent } from './student/student-list/student-list.component';
import { StudentFormComponent } from './student/student-form/student-form.component';
import { TeacherListComponent } from './teacher/teacher-list/teacher-list.component';
import { TeacherFormComponent } from './teacher/teacher-form/teacher-form.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { DeleteModalComponent } from '../shared/modal/delete-modal/delete-modal.component';
import { SharedModule } from '../shared/shared.module';

const routes: Routes = [
  { path: 'student-list', component: StudentListComponent },
  { path: 'teacher-list', component: TeacherListComponent },
  { path: 'add-student', component: StudentFormComponent },
  { path: 'add-teacher', component: TeacherFormComponent },
  { path: 'edit-student/:id', component: StudentFormComponent },
  { path: 'edit-teacher/:id', component: TeacherFormComponent },

];


@NgModule({
  declarations: [
    StudentListComponent,
    StudentFormComponent,
    TeacherListComponent,
    TeacherFormComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule, // Add BrowserAnimationsModule
    ToastrModule.forRoot(),
    RouterModule.forChild(routes),
    AppRoutingModule,
    SharedModule
  ],
  exports: [
  ]
})
export class ModulesModule { }
