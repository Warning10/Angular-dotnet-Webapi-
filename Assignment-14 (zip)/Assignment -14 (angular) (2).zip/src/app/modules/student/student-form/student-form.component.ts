import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentService } from '../../../shared/service/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../../../shared/interface/student-interface';
import { Department } from '../../../shared/interface/department-interface';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrl: './student-form.component.scss'
})
export class StudentFormComponent {
studentForm: FormGroup;
isEditMode: boolean = false;
studentId: string | null = null;
departments: Department[] = []; 
grades: string[] = ['A', 'B', 'C', 'D', 'F']; // Hardcoded grades



constructor(
  private fb: FormBuilder,
  private studentService : StudentService,
  private router: Router,
  private route: ActivatedRoute,
  private toastr: ToastrService

){
  this.studentForm=this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', Validators.required],
      deptId: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      enrollmentDate: ['', Validators.required],
      grade: ['', Validators.required],
  });
}

ngOnInit(): void {
  this.route.paramMap.subscribe(params => {
    this.studentId = params.get('id');
    if (this.studentId) {
      this.isEditMode = true;
      this.loadStudentData(this.studentId);
    }
  });
  this.loadDepartments();
}

loadStudentData(id: string): void {
  this.studentService.getStudent(id).subscribe({
    next: (student: Student) => {
      this.studentForm.patchValue({
        ...student,
        dateOfBirth: this.formatDate(student.dateOfBirth),
        enrollmentDate: this.formatDate(student.enrollmentDate),
      });
      // Optional: Toastr notification for debugging (can be removed if not needed)
      this.toastr.info('Student data loaded successfully');
    },
    error: (error: any) => {
      this.toastr.error('Error fetching student data');
      console.error('Error fetching student data:', error); // Optional debugging line
    },
    complete: () => {
      console.log('Load student data complete'); // Optional debugging line
    }
  });
}

loadDepartments(): void {
  this.studentService.getDepartments().subscribe({
    next: (departments: Department[]) => {
      this.departments = departments;
    },
    error: (error: any) => {
      this.toastr.error('Error fetching departments');
      console.error('Error fetching departments:', error); // Optional debugging line
    },
    complete: () => {
      console.log('Load departments complete'); // Optional debugging line
    }
  });
}

formatDate(dateString: string): string {
  // Format date as yyyy-MM-dd
  const date = new Date(dateString);
  return date.toISOString().split('T')[0];
}


onSubmit(): void {
  if (this.studentForm.valid) {
    const studentData = this.studentForm.value;
    if (this.isEditMode && this.studentId) {
      this.studentService.updateStudent(this.studentId, studentData).subscribe({
        next: () => {
          this.toastr.success('Student updated successfully');
          this.router.navigate(['/student-list']);
        },
        error: (error: any) => {
          this.handleError(error);

        },
        complete: () => {
          console.log('Update student complete'); // Optional debugging line
        }
      });
    } else {
      this.studentService.addStudent(studentData).subscribe({
        next: () => {
          this.toastr.success('Student added successfully');
          this.router.navigate(['/student-list']);
        },
        error: (error: any) => {
          this.handleError(error);

        },
        complete: () => {
          console.log('Add student complete'); // Optional debugging line
        }
      });
    }
  }
}
handleError(error: any): void {
  let errorMessage = 'An unexpected error occurred';

  if (error.error) {
      // Check if error is an object and has a message
      if (typeof error.error === 'object') {
          errorMessage = error.error.message || errorMessage;
      } else {
          // If the error is a string, display it directly
          errorMessage = error.error;
      }
  } else if (error.message) {
      // Fallback to generic error message if nothing else is available
      errorMessage = error.message;
  }

  this.toastr.error(errorMessage, 'Error');
  console.error('Request failed', error);
}

goBack(): void {
  // Navigate to the student list page
  this.router.navigate(['/student-list']);
}
}