export interface Student {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    gender: string;
    deptId: string;
    department: string;
    dateOfBirth: string; 
    enrollmentDate: string; 
    grade: string;
    created: string; 
    updated: string; 
}
