import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentListComponent } from './modules/student/student-list/student-list.component';
import { StudentFormComponent } from './modules/student/student-form/student-form.component';

const routes: Routes = [
  { path: '', component: StudentListComponent},
  // { path: '**', component: StudentListComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
