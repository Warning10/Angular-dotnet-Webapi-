import { Component } from '@angular/core';
import { Student } from '../../../shared/interface/studentInterface';
import { StudentService } from '../../../shared/service/student.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.scss'
})
export class StudentListComponent {

  students: Student[]=[];
  errorMessage: string | null = null;

  constructor(private studentService: StudentService, private router: Router, private toastr: ToastrService){}

  ngOnInit(): void {
    this.loadStudents();
  }

  loadStudents(): void {
    this.studentService.getAllStudents().subscribe({
      next: (data: Student[]) => {
        this.students = data;
        // Optionally notify that data was fetched successfully
        this.toastr.info('Students data loaded successfully');
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching student data.';
        this.toastr.error('Error fetching students');
        console.error('Error Fetching students:', error); // Optional debugging line
      },
      complete: () => {
        console.log('Load students complete'); // Optional debugging line
      }
    });
  }

  editStudent(id: string): void {
    this.router.navigate(['/edit-student', id]);
  }

  deleteStudent(id: string): void {
    if (confirm('Are you sure you want to delete this student?')) {
      this.studentService.deleteStudent(id).subscribe({
        next: () => {
          this.students = this.students.filter(student => student.id !== id);
          this.toastr.success('Student deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the student.';
          this.toastr.error('Error deleting student');
          console.error('Error deleting student:', error); // Optional debugging line
        },
        complete: () => {
          console.log('Delete student complete'); // Optional debugging line
        }
      });
    }
  }
}