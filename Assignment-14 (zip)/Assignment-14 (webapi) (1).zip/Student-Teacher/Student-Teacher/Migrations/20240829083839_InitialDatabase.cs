﻿using Microsoft.EntityFrameworkCore.Migrations;


#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "StudentModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StudentModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TeacherModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5063), "Computer", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5064) },
                    { new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5067), "Mechanical", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5067) },
                    { new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5065), "Information Technology", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5066) },
                    { new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5068), "Civil", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5069) },
                    { new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5070), "Production", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(5071) }
                });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("2bc838f7-a460-4942-9a46-3e3629eecc1e"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4680), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4680), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4680) },
                    { new Guid("3f9ad5b0-9037-4ad6-8f34-918aaa75a798"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4668), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4668), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4669) },
                    { new Guid("47558fc8-ba43-4453-8f48-7830f477b0d7"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4676), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4675), "Diana", "Female", "8th", "Brown", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4676) },
                    { new Guid("72f15b0a-1d0b-473c-9796-f88fc19057d7"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4672), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4671), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4672) },
                    { new Guid("9ecec432-20ba-439d-9363-e8d168a73237"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4651), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4649), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4652) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("52ec6361-1663-4adf-9899-0239fca5d1e1"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4948), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4949) },
                    { new Guid("c2e78cd5-549f-423c-8d53-114550c171bf"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4952), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4953) },
                    { new Guid("d10e7d30-23de-45bc-baef-56950f42686d"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4955), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4956) },
                    { new Guid("d91d3a12-390d-49ba-82fb-c6f46a6c4f0e"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4958), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4959) },
                    { new Guid("eea50e48-c477-42d6-94c0-0bc989b6021f"), new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4965), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 8, 29, 8, 38, 38, 998, DateTimeKind.Utc).AddTicks(4965) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentModel_DeptId",
                table: "StudentModel",
                column: "DeptId");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherModel_DeptId",
                table: "TeacherModel",
                column: "DeptId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentModel");

            migrationBuilder.DropTable(
                name: "TeacherModel");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
