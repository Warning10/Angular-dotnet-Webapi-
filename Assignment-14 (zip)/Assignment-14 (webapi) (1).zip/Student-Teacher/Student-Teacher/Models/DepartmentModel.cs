﻿using System.ComponentModel.DataAnnotations;

namespace Student_Teacher.Models
{
    public class DepartmentModel
    {
        [Key]
        public Guid DeptId { get; set; }

        public string DeptName { get; set; }

        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }

    }
}
