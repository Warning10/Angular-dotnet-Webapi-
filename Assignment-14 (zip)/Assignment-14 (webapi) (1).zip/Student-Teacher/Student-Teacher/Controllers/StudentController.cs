﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Modules.StudentModule.Command;
using Student_Teacher.Modules.StudentModule.Query;

namespace Student_Teacher.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ISender _mediatR;

        public StudentController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllStudents()
        {
            try
            {

                var result = await _mediatR.Send(new GetStudentQuery());

                if (result == null)
                {
                    return NotFound("No students found.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetStudentById([FromRoute] Guid id)
        {
            try
            {
                var result = await _mediatR.Send(new GetStudentByIdQuery { Id = id });

                if (result == null)
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("create")]
        public async Task<object> CreateStudent([FromBody] CreateStudentCommand createStudentCommand)
        {
            try
            {
                var isSuccess = await _mediatR.Send(createStudentCommand);
                if (!isSuccess)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the student.");
                }
                else
                {
                    return Ok(new { Message = "Student created successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateStudent([FromBody] StudentCommand studentCommand, [FromRoute] Guid id)
        {
            try
            {
                var updateStudentCommand = new UpdateStudentCommand
                {
                    Id = id,
                    FirstName = studentCommand.FirstName,
                    LastName = studentCommand.LastName,
                    Email = studentCommand.Email,
                    Gender = studentCommand.Gender,
                    DeptId = studentCommand.DeptId,
                    DateOfBirth = studentCommand.DateOfBirth,
                    EnrollmentDate = studentCommand.EnrollmentDate,
                    Grade = studentCommand.Grade,
                };


                bool isUpdated = await _mediatR.Send(updateStudentCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Student updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteStudent([FromRoute] Guid id)
        {

            try
            {
                var result = await _mediatR.Send(new DeleteStudentCommand() { Id = id });
                if (result)
                {
                    return Ok(new { Message = $"Student with ID {id} deleted successfully" });
                }
                else
                {
                    return NotFound(new { Message = $"Student with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
