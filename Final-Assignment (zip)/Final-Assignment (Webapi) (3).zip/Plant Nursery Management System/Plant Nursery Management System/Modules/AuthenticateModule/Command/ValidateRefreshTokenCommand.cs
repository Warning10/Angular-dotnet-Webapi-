﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;
using Student_Teacher.Modules.AuthenticateModule.Command;
using System.Security.Claims;

namespace Plant_Nursery_Management_System.Modules.AuthenticateModule.Command
{
    public class ValidateRefreshTokenCommand : TokensDataCommand { }
    public class ValidateRefreshTokenCommandHandler : IRequestHandler<ValidateRefreshTokenCommand, TokenModel>
    {
        private readonly IGenericRepository<UserModel> _genericRepository;
        private readonly IValidateUserRepository _validateUserRepository;
        private readonly IGenerateToken _generateToken;

        public ValidateRefreshTokenCommandHandler(IGenericRepository<UserModel> genericRepository, IValidateUserRepository validateUserRepository, IGenerateToken generateToken)
        {
            _genericRepository = genericRepository;
            _validateUserRepository = validateUserRepository;
            _generateToken = generateToken;
        }

        /// <summary>
        /// Handles the validation and refresh of tokens. Validates the provided refresh token and generates new tokens if valid.
        /// </summary>
        public async Task<TokenModel> Handle(ValidateRefreshTokenCommand request, CancellationToken cancellationToken)
        {
            var principal = _generateToken.GetPrincipalFromExpiredToken(request.AccessToken);
            var email = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            var users = await _validateUserRepository.GetByUserEmail(email);
            if (users == null || users.RefreshToken != request.RefreshToken || users.RefreshTokenExpiryTime < DateTime.Now)
            {
                throw new InvalidOperationException("Token Expired");
            }

            var tokens = await _generateToken.GenerateTokens(users.Email);
            if (tokens == null)
            {
                throw new InvalidOperationException("Invalid Operation");
            }
            users.RefreshToken = tokens.RefreshToken;
            users.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(10);
            _genericRepository.SaveData();
            return tokens;
        }
    }
}
