﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.PlantModule.Query
{
    public class GetPlantByIdQuery : IRequest<PlantModel>
    {
        public Guid Id { get; set; }
    }

    public class GetPlantByIdQueryHandler : IRequestHandler<GetPlantByIdQuery, PlantModel>
    {
        private readonly IGenericRepository<PlantModel> _genericRepository;

        public GetPlantByIdQueryHandler(IGenericRepository<PlantModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the retrieval of a plant record by its unique identifier.
        /// </summary>
        public async Task<PlantModel> Handle(GetPlantByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdData(request.Id);
        }
    }
}
