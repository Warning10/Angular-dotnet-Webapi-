﻿using MediatR;

namespace Plant_Nursery_Management_System.Modules.PlantModule.Command
{
    public class PlantCommand : IRequest<bool>
    {
        public string PlantName { get; set; }
    }
}
