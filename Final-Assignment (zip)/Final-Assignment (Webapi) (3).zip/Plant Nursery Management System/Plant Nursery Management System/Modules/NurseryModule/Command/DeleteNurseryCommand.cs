﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Command
{
    public class DeleteNurseryCommand : NurseryCommand
    {
        public Guid Id { get; set; }
    }

    public class DeleteNurseryCommandHandler : IRequestHandler<DeleteNurseryCommand, bool>
    {
        private readonly IGenericRepository<NurseryModel> _genericRepository;

        public DeleteNurseryCommandHandler(IGenericRepository<NurseryModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the deletion of a nursery by its unique identifier.
        /// </summary>
        public async Task<bool> Handle(DeleteNurseryCommand request, CancellationToken cancellationToken)
        {
            var existingStudent = await _genericRepository.GetByIdData(request.Id);
            if (existingStudent == null)
            {
                return false;
            }
            return await _genericRepository.DeleteData(request.Id);
        }
    }
}
