﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Command
{
    public class CreateNurseryCommand : NurseryCommand { }
    public class CreateNurseryCommandHandler : IRequestHandler<CreateNurseryCommand, bool>
    {
        private readonly IGenericRepository<NurseryModel> _genericRepository;

        public CreateNurseryCommandHandler(IGenericRepository<NurseryModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the creation of a new nursery by validating the provided command and saving it to the repository.
        /// </summary>
        public async Task<bool> Handle(CreateNurseryCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new NurseryCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var nurseryModel = new NurseryModel
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                EmailAddress = request.EmailAddress,
                MobileNumber = request.MobileNumber,
                Address = request.Address,
                PlantId = request.PlantId,
                StartDate = request.StartDate,
                EndDate = request.EndDate,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow,
            };
            return await _genericRepository.AddData(nurseryModel);
        }
    }
}
