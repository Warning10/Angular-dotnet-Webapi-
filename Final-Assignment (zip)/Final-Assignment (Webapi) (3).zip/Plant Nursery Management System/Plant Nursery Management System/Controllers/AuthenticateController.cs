﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Plant_Nursery_Management_System.Modules.AuthenticateModule.Command;

namespace Plant_Nursery_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly ISender _mediatR;

        public AuthenticateController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        #region Login Endpoint

        /// <summary>
        /// Handles user login requests. Validates user credentials and returns the authentication result.
        /// </summary>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] ValidateUserCommand validateUserCommand)
        {
            try
            {
                var result = await _mediatR.Send(validateUserCommand);

                if (result == null)
                {
                    return NotFound(new { Message = "User Not Found" });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Refresh Token Endpoint

        /// <summary>
        /// Generates a new refresh token for a user based on the provided refresh token command.
        /// </summary>
        [HttpPost("refreshToken")]
        public async Task<IActionResult> GenerateRefreshToken([FromBody] ValidateRefreshTokenCommand validateRefreshTokenCommand)
        {
            try
            {
                var result = await _mediatR.Send(validateRefreshTokenCommand);

                if (result == null)
                {
                    return NotFound(new { Message = "User Not Found" });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
