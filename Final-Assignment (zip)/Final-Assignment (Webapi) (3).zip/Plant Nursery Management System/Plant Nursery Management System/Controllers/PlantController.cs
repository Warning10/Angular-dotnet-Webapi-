﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Plant_Nursery_Management_System.Modules.PlantModule.Query;

namespace Plant_Nursery_Management_System.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PlantController : ControllerBase
    {
        private readonly ISender _mediatR;

        public PlantController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        #region Get All Plants

        /// <summary>
        /// Retrieves a list of all plants.
        /// </summary>
        [HttpGet("all")]
        public async Task<IActionResult> GetAllPlants()
        {
            try
            {
                var result = await _mediatR.Send(new GetPlantDataQuery());

                if (result == null)
                {
                    return NotFound("No Plants found.");
                }

                return Ok(result);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
