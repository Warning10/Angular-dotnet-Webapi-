﻿using Microsoft.EntityFrameworkCore;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Utils;

namespace Plant_Nursery_Management_System.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ApplicationDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        #region Save Data

        /// <summary>
        /// Saves all changes made in the context to the underlying database.
        /// </summary>
        public void SaveData()
        {
            _context.SaveChanges();
        }
        #endregion

        #region Data Retrieval

        /// <summary>
        /// Retrieves all entities of type <typeparamref name="T"/> from the database.
        /// </summary>
        public async Task<List<T>> GetAllData()
        {
            return await _dbSet.ToListAsync();
        }
        #endregion

        #region Data Retrieval

        /// <summary>
        /// Retrieves an entity of type <typeparamref name="T"/> by its unique identifier from the database.
        /// </summary>
        public async Task<T> GetByIdData(Guid id)
        {
            return await _dbSet.FindAsync(id);
        }
        #endregion

        #region Data Insertion

        /// <summary>
        /// Adds a new entity of type <typeparamref name="T"/> to the database and saves the changes.
        /// </summary>
        public async Task<bool> AddData(T entity)
        {
            try
            {
                _dbSet.Add(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Data Deletion

        /// <summary>
        /// Deletes an entity of type <typeparamref name="T"/> by its unique identifier from the database and saves the changes.
        /// </summary>
        public async Task<bool> DeleteData(Guid id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
        #endregion
    }
}
