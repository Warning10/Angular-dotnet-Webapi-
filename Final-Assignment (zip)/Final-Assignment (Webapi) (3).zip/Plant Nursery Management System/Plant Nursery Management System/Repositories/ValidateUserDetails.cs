﻿using Microsoft.EntityFrameworkCore;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;
using Plant_Nursery_Management_System.Utils;

namespace Plant_Nursery_Management_System.Repositories
{
    public class ValidateUserDetails : IValidateUserRepository
    {
        private readonly ApplicationDbContext _context;

        public ValidateUserDetails(ApplicationDbContext context)
        {
            _context = context;
        }

        #region User Retrieval

        /// <summary>
        /// Retrieves a user of type <see cref="UserModel"/> by their email address from the database.
        /// </summary>
        public async Task<UserModel> GetByUserEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                throw new ArgumentException("Username cannot be null or empty", nameof(email));
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            return user;
        }
        #endregion
    }
}
