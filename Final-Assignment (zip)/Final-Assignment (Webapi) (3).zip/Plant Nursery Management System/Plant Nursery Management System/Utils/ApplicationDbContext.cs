﻿using Microsoft.EntityFrameworkCore;
using Plant_Nursery_Management_System.Models;
using Plant_Nursery_Management_System.Utils.Configurations;

namespace Plant_Nursery_Management_System.Utils
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.ApplyConfiguration(new NurseryConfiguration());
            modelBuilder.ApplyConfiguration(new PlantConfiguration());

        }

        public DbSet<NurseryModel> Nursery { get; set; }
        public DbSet<PlantModel> Plants { get; set; }
        public DbSet<UserModel> Users { get; set; }
    }
}
