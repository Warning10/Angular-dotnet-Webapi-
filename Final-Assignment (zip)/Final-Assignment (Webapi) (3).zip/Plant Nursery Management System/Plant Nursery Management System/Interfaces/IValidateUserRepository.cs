﻿using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Interfaces
{
    public interface IValidateUserRepository
    {
        Task<UserModel> GetByUserEmail(string email);
    }
}
