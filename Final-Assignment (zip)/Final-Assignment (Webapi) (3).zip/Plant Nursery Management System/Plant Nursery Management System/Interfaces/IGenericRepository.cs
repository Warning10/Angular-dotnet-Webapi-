﻿namespace Plant_Nursery_Management_System.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        void SaveData();
        Task<List<T>> GetAllData();
        Task<T> GetByIdData(Guid id);
        Task<bool> AddData(T entity);
        Task<bool> DeleteData(Guid id);
    }
}
