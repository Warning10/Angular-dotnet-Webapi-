﻿using Plant_Nursery_Management_System.Models;
using System.Security.Claims;

namespace Plant_Nursery_Management_System.Interfaces
{
    public interface IGenerateToken
    {
        public Task<TokenModel> GenerateTokens(string email);
        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
