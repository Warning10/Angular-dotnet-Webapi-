import { Component } from '@angular/core';

@Component({
  selector: 'app-plants',
  templateUrl: './plants.component.html',
  styleUrls: ['./plants.component.scss'],
})
export class PlantsComponent {
  plants = [
    {
      name: 'Rose',
      description:
        'Roses are known for their beautiful flowers, which are often fragrant.',
      imageUrl: '../../../assets/images/rose.jpg',
      wikiUrl: 'https://en.wikipedia.org/wiki/Rose',
    },
    {
      name: 'Tulip',
      description:
        'Tulips are spring-blooming perennials that grow from bulbs.',
      imageUrl: '../../../assets/images/tulip.jpg',
      wikiUrl: 'https://en.wikipedia.org/wiki/Tulip',
    },
    {
      name: 'Cactus',
      description:
        'Cacti are succulent plants that thrive in arid environments.',
      imageUrl: '../../../assets/images/cactus.jpg',
      wikiUrl: 'https://en.wikipedia.org/wiki/Cactus',
    },
  ];
}
