import { Component } from '@angular/core';
import { NurseryService } from '../../../shared/services/nursery.service';
import { Nursery } from '../../../shared/interfaces/nursery.interface';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nursery-list',
  templateUrl: './nursery-list.component.html',
  styleUrl: './nursery-list.component.scss',
})
export class NurseryListComponent {
  public nursery: Nursery[] = [];
  public errorMessage: string | null = null;
  public plantNames: { [key: string]: string } = {};
  public isModalVisible = false;
  public itemToDelete: { id: string; name: string } | null = null;

  constructor(
    private nurseryService: NurseryService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadNursery();
    this.loadPlants();
  }

  // Prepares and shows the delete confirmation modal for a specific item.
  public showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  // Hides the delete confirmation modal and clears the item to delete.
  public handleCancelDelete() {
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  // Confirms and processes the deletion of a nursery, then updates the list and hides the modal.
  public handleConfirmDelete(id: string | null) {
    if (id) {
      this.nurseryService.deleteNursery(id).subscribe({
        next: () => {
          this.nursery = this.nursery.filter((nursery) => nursery.id !== id);
          this.toastr.success('Nursery deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the nursery.';
          this.toastr.error('Error deleting nursery');
        },
        complete: () => {
          console.log('Delete nursery complete');
        },
      });
    }
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  // Navigates to the edit nursery page with the specified ID.
  public editNursery(id: string): void {
    this.router.navigate(['/layout/edit-nursery', id]);
  }

  // Retrieves the plant name for a given ID or returns a default message.
  public getPlantName(plantId: string | null): string {
    return plantId
      ? this.plantNames[plantId] || 'Unknown Plant'
      : 'No Plant ID';
  }

  // Loads and updates nursery data, handling success and error states.
  private loadNursery(): void {
    this.nurseryService.getallNursery().subscribe({
      next: (data: Nursery[]) => {
        this.nursery = data;
        this.toastr.info('Nursery data loaded successfully');
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching nursery data.';
        this.toastr.error('Error fetching nursery');
      },
      complete: () => {
        console.log('Load nursery complete');
      },
    });
  }

  // Loads plant data and maps plant IDs to names for easier access.
  private loadPlants() {
    this.nurseryService.getPlants().subscribe((plants) => {
      this.plantNames = plants.reduce((map, plant) => {
        map[plant.plantId] = plant.plantName;
        return map;
      }, {} as { [key: string]: string });
    });
  }
}
