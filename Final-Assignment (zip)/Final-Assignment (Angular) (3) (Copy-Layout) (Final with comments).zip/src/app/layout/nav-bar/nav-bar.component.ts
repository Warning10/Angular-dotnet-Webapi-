import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss',
})
export class NavBarComponent {
  public isLoggedIn: boolean = false;

  constructor(private router: Router, private toastr: ToastrService) {}

  // Checks if a user is logged in by verifying the presence of an access token.
  public isLoginIn(): boolean {
    const token = localStorage.getItem('AccessToken');
    if (token) {
      return true;
    } else {
      return false;
    }
  }

  // Sets login status and navigates to the login page.
  public login(): void {
    this.isLoggedIn = true;
    this.router.navigate(['/login']);
  }

  // Clears local storage, shows a logout success message, and navigates to the login page.
  public logout(): void {
    localStorage.clear();
    this.toastr.success('You have been logged out successfully.', 'Logout');
    this.router.navigate(['/login']);
    this.isLoggedIn = false;
  }
}
