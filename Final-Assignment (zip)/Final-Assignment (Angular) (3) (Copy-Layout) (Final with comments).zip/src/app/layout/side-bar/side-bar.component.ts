import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrl: './side-bar.component.scss',
})
export class SideBarComponent {
  constructor(private router: Router) {}

  // Navigates to the nursery list page.
  public goDashboard(): void {
    this.router.navigate(['/layout/nursery-list']);
  }

  // Navigates to the home page.
  public goHome(): void {
    this.router.navigate(['/layout']);
  }

  // Navigates to the plants page.
  public goPlants(): void {
    this.router.navigate(['/layout/plants']);
  }
}
