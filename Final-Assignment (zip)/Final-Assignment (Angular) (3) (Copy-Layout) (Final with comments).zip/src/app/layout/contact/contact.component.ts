import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ValidatorsConstant } from '../../shared/constants/validators.constants';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
})
export class ContactComponent {
  public contactForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      name: ['', ValidatorsConstant.NameValidators],
      email: ['', ValidatorsConstant.EmailValidators],
      message: ['', ValidatorsConstant.MessageValidators],
    });
  }

  // Handles form submission, displays messages, and resets the form.
  public onSubmit() {
    if (this.contactForm.valid) {
      console.log('Form Submitted', this.contactForm.value);

      alert('Thank you for contacting us! Your message has been sent.');

      this.contactForm.reset();
    } else {
      alert('Please fill out the form correctly.');
    }
  }
}
