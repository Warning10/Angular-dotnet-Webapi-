import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from '../../shared/services/user.service';
import { Login } from '../../shared/interfaces/login.interface';
import { ValidatorsConstant } from '../../shared/constants/validators.constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  public loginForm!: FormGroup;

  constructor(
    private userService: UserService,
    private router: Router,
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    localStorage.clear();

    this.loginForm = this.formBuilder.group({
      email: ['', ValidatorsConstant.EmailValidators],
      password: ['', ValidatorsConstant.PasswordValidators],
    });
  }

  // Prevents default action when the space bar is pressed.
  public blockSpace(event: KeyboardEvent): void {
    if (event.key === ' ' || event.keyCode === 32) {
      event.preventDefault();
    }
  }

  // Handles login form submission and manages authentication and navigation.
  public onLogin(): void {
    if (this.loginForm.invalid) {
      this.toastr.error(
        'Please fill out the form correctly.',
        'Validation Error'
      );
      return;
    }

    const loginData: Login = this.loginForm.value;

    this.userService.login(loginData).subscribe({
      next: (result) => {
        localStorage.setItem('Email', this.loginForm.value.email);
        localStorage.setItem('AccessToken', result.accessToken);
        localStorage.setItem('RefreshToken', result.refreshToken);
        this.router.navigate(['/layout/nursery-list']);
        this.toastr.success('Login successful!', 'Success');
      },
      error: (err) => {
        this.handleError(err);
      },
    });
  }

  // Displays an error message based on the provided error object.
  private handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
      if (typeof error.error === 'object') {
        errorMessage = error.error.message || errorMessage;
      } else {
        errorMessage = error.error;
      }
    } else if (error.message) {
      errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
  }
}
