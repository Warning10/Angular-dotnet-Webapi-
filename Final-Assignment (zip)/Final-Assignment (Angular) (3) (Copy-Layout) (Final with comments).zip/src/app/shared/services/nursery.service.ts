import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Nursery } from '../interfaces/nursery.interface';
import { Plant } from '../interfaces/plant.interface';
import { PlantService } from './plant.service';
import { RouteConstants } from '../constants/route.constants';

@Injectable({
  providedIn: 'root',
})
export class NurseryService {
  constructor(private http: HttpClient, private plantService: PlantService) {}

  getallNursery(): Observable<Nursery[]> {
    return this.http.get<Nursery[]>(`${RouteConstants.NurseryApiUrl}/all`);
  }

  public getNursery(id: string): Observable<Nursery> {
    return this.http.get<Nursery>(`${RouteConstants.NurseryApiUrl}/byid/${id}`);
  }

  public getPlants(): Observable<Plant[]> {
    return this.plantService.getPlants();
  }

  public addNursery(nursery: Nursery): Observable<Nursery> {
    return this.http.post<Nursery>(
      `${RouteConstants.NurseryApiUrl}/create`,
      nursery
    );
  }

  public updateNursery(
    id: string,
    nursery: Partial<Nursery>
  ): Observable<Nursery> {
    debugger;
    return this.http.put<Nursery>(
      `${RouteConstants.NurseryApiUrl}/update/${id}`,
      nursery
    );
  }

  public deleteNursery(id: string): Observable<void> {
    return this.http.delete<void>(
      `${RouteConstants.NurseryApiUrl}/delete/${id}`
    );
  }
}
