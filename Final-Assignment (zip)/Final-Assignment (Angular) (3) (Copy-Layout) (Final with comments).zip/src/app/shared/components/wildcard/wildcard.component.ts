import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wildcard',
  templateUrl: './wildcard.component.html',
  styleUrls: ['./wildcard.component.scss'],
})
export class WildcardComponent {
  public buttonText: string = 'Go to Homepage';
  constructor(private router: Router) {}

  ngOnInit(): void {
    this.updateButtonText();
  }

  // Navigates to the home page if an email is stored; otherwise, goes to the login page.
  public goHome() {
    const email = localStorage.getItem('Email');
    if (email) {
      this.router.navigate(['/layout']);
    } else {
      this.router.navigate(['/login']);
    }
  }

  // Updates button text based on whether an email is stored in local storage.
  public updateButtonText() {
    const email = localStorage.getItem('Email');
    if (email) {
      this.buttonText = 'Go to Homepage';
    } else {
      this.buttonText = 'Login to Continue';
    }
  }
}
