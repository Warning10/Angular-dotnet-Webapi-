import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrl: './delete-modal.component.scss',
})
export class DeleteModalComponent {
  @Input() isVisible = false;
  @Input() itemName = '';
  @Input() itemId: string | null = null;
  @Output() confirm = new EventEmitter<string | null>();
  @Output() cancel = new EventEmitter<void>();

  // Emits a confirmation event and hides the modal.
  public onConfirm() {
    this.confirm.emit(this.itemId);
    this.isVisible = false;
  }

  // Emits a cancellation event and hides the modal.
  public onCancel() {
    this.cancel.emit();
    this.isVisible = false;
  }
}
