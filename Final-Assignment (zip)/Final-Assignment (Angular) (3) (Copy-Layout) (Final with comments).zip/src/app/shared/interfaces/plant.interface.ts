export interface Plant {
  plantId: string;
  plantName: string;
  createdDate?: string;
  updatedDate?: string;
}
