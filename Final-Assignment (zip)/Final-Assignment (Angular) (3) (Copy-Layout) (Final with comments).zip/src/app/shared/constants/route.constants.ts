export class RouteConstants {
  public static readonly NurseryApiUrl = 'https://localhost:7197/api/Nursery';
  public static readonly UserApiUrl = 'https://localhost:7197/api/Authenticate';
  public static readonly PlantApiUrl = 'https://localhost:7197/api/Plant/all';
}
