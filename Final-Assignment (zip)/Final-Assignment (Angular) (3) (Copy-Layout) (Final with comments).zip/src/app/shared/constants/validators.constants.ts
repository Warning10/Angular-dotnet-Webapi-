import { Validators } from '@angular/forms';

export class ValidatorsConstant {
  public static readonly NamePattern = /^[A-Za-z]+( [A-Za-z]+)*$/;

  public static readonly MobileNumberPattern = /^\d{10}$/;

  public static readonly EmailPatern =
    /^[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*@([a-zA-Z]+[0-9]*(-[a-z0-9]+)*)*(\.[a-zA-Z]{2,}){1,2}$/;

  public static readonly AddressPattern =
    /^(?!\s)(?!.*\s$)(?!^\d+$)[a-zA-Z0-9\s\.,\-\/#'()]+$/;

  public static readonly MessagePattern =
    /^(?!\s)(?!.*\s$)(?!^\d+$)[a-zA-Z0-9\s\.,\-\/#'()]+$/;

  public static readonly PasswordPattern =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  public static readonly NameValidators = [
    Validators.required,
    Validators.minLength(2),
    Validators.maxLength(20),
    Validators.pattern(this.NamePattern),
  ];

  public static readonly MobileNumberValidators = [
    Validators.required,
    Validators.pattern(this.MobileNumberPattern),
  ];

  public static readonly EmailValidators = [
    Validators.required,
    Validators.email,
    Validators.maxLength(50),
    Validators.pattern(this.EmailPatern),
  ];

  public static readonly AddressValidators = [
    Validators.required,
    Validators.minLength(10),
    Validators.maxLength(70),
    Validators.pattern(this.AddressPattern),
  ];

  public static readonly PasswordValidators = [
    Validators.required,
    Validators.minLength(6),
    Validators.pattern(this.PasswordPattern),
  ];

  public static readonly MessageValidators = [
    Validators.required,
    Validators.minLength(10),
    Validators.maxLength(70),
    Validators.pattern(this.MessagePattern),
  ];
}
