export class ApiConstants {
  public static readonly DefaultRoute = '';
  public static readonly WildCardRoute = '**';
  public static readonly HomeRoute = 'home';
  public static readonly NurseryListRoute = 'nursery-list';
  public static readonly NurseryFormRoute = 'add-nursery';
  public static readonly NurseryEditRoute = 'edit-nursery/:id';
  public static readonly LoginRoute = 'login';
}
