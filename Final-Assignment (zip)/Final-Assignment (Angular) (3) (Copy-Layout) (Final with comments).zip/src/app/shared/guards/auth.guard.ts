import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  GuardResult,
  MaybeAsync,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { UserService } from '../services/user.service';
import { of } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(
    private jwtHelper: JwtHelperService,
    private router: Router,
    private userService: UserService,
    private toastr: ToastrService
  ) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): MaybeAsync<GuardResult> {
    const AccessToken = localStorage.getItem('AccessToken');
    const RefreshToken = localStorage.getItem('RefreshToken');

    if (AccessToken && !this.jwtHelper.isTokenExpired(AccessToken)) {
      return of(true);
    } else {
      if (AccessToken && this.jwtHelper.isTokenExpired(AccessToken)) {
        this.userService
          .getRefreshToken({ AccessToken, RefreshToken })
          .subscribe({
            next: (response: any) => {
              localStorage.setItem('AccessToken', response.accessToken);
              localStorage.setItem('RefreshToken', response.refreshToken);
              this.router.navigateByUrl(state.url);
              this.toastr.success('Refresh Token Call Success');
              return of(true);
            },
            error: (error) => {
              this.toastr.error('Refresh Token Expired, Please Login Again');
              this.router.navigate(['/login']);
              localStorage.clear();
              return of(false);
            },
          });
        return of(false);
      }
      this.toastr.error('No valid Access Token Found, Redirecting to Login.');
      this.router.navigate(['/login']);
      return of(false);
    }
  }
}
