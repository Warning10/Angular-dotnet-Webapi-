import { Component } from '@angular/core';
import { NurseryService } from '../../../shared/services/nursery.service';

@Component({
  selector: 'app-nursery-list',
  templateUrl: './nursery-list.component.html',
  styleUrl: './nursery-list.component.scss'
})
export class NurseryListComponent {
  public nursery: any[] = [];
  constructor(private nurseryService: NurseryService) { }

  ngOnInit(): void {
    this.loadData(); // Call the method to load data
  }

  private loadData(): void {
    this.nurseryService.getNursery().subscribe(
      (response) => {
        this.nursery = response;
      },
      (error) => {
        console.error('Error fetching data', error);
      }
    );
  }


}
