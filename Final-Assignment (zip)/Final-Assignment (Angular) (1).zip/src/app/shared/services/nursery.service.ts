import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Nursery } from '../interfaces/nursery.interface';

@Injectable({
  providedIn: 'root'
})
export class NurseryService {

  private apiUrl = 'https://localhost:7197/api/Nursery'; 
  constructor(private http: HttpClient) { }

  getNursery(): Observable<Nursery[]> {
    return this.http.get<Nursery[]>(`${this.apiUrl}/all`);
  }
}
