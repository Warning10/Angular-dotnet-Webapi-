﻿using MediatR;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Command
{
    public class NurseryCommand : IRequest<bool>
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        public string MobileNumber { get; set; }

        public string Address { get; set; }

        public Guid PlantId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}
