﻿using Microsoft.EntityFrameworkCore;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Utils;

namespace Plant_Nursery_Management_System.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ApplicationDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        public void SaveData()
        {
            _context.SaveChanges();
        }

        public async Task<List<T>> GetAllData()
        {
            return await _dbSet.ToListAsync();

        }

        public async Task<T> GetByIdData(Guid id)
        {
            return await _dbSet.FindAsync(id);

        }

        public async Task<bool> AddData(T entity)
        {
            try
            {
                _dbSet.Add(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<bool> DeleteData(Guid id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
    }
}
