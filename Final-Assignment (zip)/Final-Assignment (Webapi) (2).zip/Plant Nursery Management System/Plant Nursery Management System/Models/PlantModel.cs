﻿using System.ComponentModel.DataAnnotations;

namespace Plant_Nursery_Management_System.Models
{
    public class PlantModel
    {
        [Key]
        public Guid PlantId { get; set; }
        public string PlantName { get; set; }

        public DateTime CreatedDate { get; set; } 

        public DateTime UpdatedDate { get; set; } 
    }
}
