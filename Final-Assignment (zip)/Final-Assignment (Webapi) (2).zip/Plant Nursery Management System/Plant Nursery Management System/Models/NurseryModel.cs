﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Plant_Nursery_Management_System.Models
{
    public class NurseryModel
    {
        [Key]
        public Guid Id { get; set; } 

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        public string MobileNumber { get; set; }

        public string Address { get; set; }

        public Guid PlantId { get; set; }

        // Navigation property
        [ForeignKey("PlantId")]
        public PlantModel Plant { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public DateTime Created { get; set; } 

        public DateTime Updated { get; set; }
    }
}
