﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Plant_Nursery_Management_System.Modules.NurseryModule.Command;
using Plant_Nursery_Management_System.Modules.NurseryModule.Query;

namespace Plant_Nursery_Management_System.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class NurseryController : ControllerBase
    {
        private readonly ISender _mediatR;

        public NurseryController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllNursery()
        {
            try
            {

                var result = await _mediatR.Send(new GetNurseryDataQuery());

                if (result == null)
                {
                    return NotFound("No Nursery found.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetNurseryById([FromRoute] Guid id)
        {
            try
            {
                var result = await _mediatR.Send(new GetNurseryByIdQuery { Id = id });

                if (result == null)
                {
                    return NotFound(new { Message = $"Nursery with ID {id} not found." });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("create")]
        public async Task<object> CreateNursery([FromBody] CreateNurseryCommand createNurseryCommand)
        {
            try
            {
                var isSuccess = await _mediatR.Send(createNurseryCommand);
                if (!isSuccess)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the Nursery.");
                }
                else
                {
                    return Ok(new { Message = "Nursery created successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateNursery([FromBody] NurseryCommand nurseryCommand, [FromRoute] Guid id)
        {
            try
            {
                var updateNurseryCommand = new UpdateNurseryCommand
                {
                    Id = id,
                    FirstName = nurseryCommand.FirstName,
                    LastName = nurseryCommand.LastName,
                    EmailAddress = nurseryCommand.EmailAddress,
                    MobileNumber = nurseryCommand.MobileNumber,
                    Address = nurseryCommand.Address,
                    PlantId = nurseryCommand.PlantId,
                    StartDate = nurseryCommand.StartDate,
                    EndDate = nurseryCommand.EndDate,
                };


                bool isUpdated = await _mediatR.Send(updateNurseryCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Nursery with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Nursery updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteNursery([FromRoute] Guid id)
        {

            try
            {
                var result = await _mediatR.Send(new DeleteNurseryCommand() { Id = id });
                if (result)
                {
                    return Ok(new { Message = $"Nursery with ID {id} deleted successfully" });
                }
                else
                {
                    return NotFound(new { Message = $"Nursery with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }

}
