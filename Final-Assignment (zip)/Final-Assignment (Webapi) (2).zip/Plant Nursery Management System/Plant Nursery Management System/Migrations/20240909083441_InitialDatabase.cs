﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Plant_Nursery_Management_System.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Plants",
                columns: table => new
                {
                    PlantId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PlantName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Plants", x => x.PlantId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshTokenExpiryTime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Nursery",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PlantId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Nursery", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Nursery_Plants_PlantId",
                        column: x => x.PlantId,
                        principalTable: "Plants",
                        principalColumn: "PlantId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Plants",
                columns: new[] { "PlantId", "CreatedDate", "PlantName", "UpdatedDate" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3663), "Jasmine", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3664) },
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a2"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3665), "Bamboo", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3665) },
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a3"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3667), "Aloe Vera", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3667) },
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a4"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3668), "Peace Lily", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3669) },
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a5"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3670), "Tulsi", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3670) },
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a6"), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3671), "Jade", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3672) }
                });

            migrationBuilder.InsertData(
                table: "Nursery",
                columns: new[] { "Id", "Address", "Created", "EmailAddress", "EndDate", "FirstName", "LastName", "MobileNumber", "PlantId", "StartDate", "Updated" },
                values: new object[,]
                {
                    { new Guid("041cb19f-b3d0-4373-b060-dbef2935d387"), "2C, Beach Road, Chennai, Tamil Nadu", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3454), "priya.reddy@example.com", new DateTime(2024, 6, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Priya", "Reddy", "654-321-0987", new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a4"), new DateTime(2024, 5, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3454) },
                    { new Guid("0b8679f3-5749-4b27-bfff-7c708dbeb9b5"), "4A, North Avenue, Delhi, Delhi", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3447), "neha.gupta@example.com", new DateTime(2024, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Neha", "Gupta", "876-543-2109", new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a2"), new DateTime(2024, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3447) },
                    { new Guid("454bb04a-6a7f-4976-8a92-145965daf159"), "7D, Tech Park, Hyderabad, Telangana", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3457), "vijay.singh@example.com", new DateTime(2024, 7, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "Vijay", "Singh", "543-210-9876", new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a5"), new DateTime(2024, 6, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3458) },
                    { new Guid("809b7e27-513b-4217-b42b-c4264ad84519"), "1/2, Green Garden, Mumbai, Maharashtra", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3441), "aarav.sharma@example.com", new DateTime(2024, 2, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Aarav", "Sharma", "987-654-3210", new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 1, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3442) },
                    { new Guid("8397488b-c23b-4944-8906-87db111933d3"), "5B, Lakeview Apartments, Bangalore, Karnataka", new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3450), "dev.patel@example.com", new DateTime(2024, 5, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Dev", "Patel", "765-432-1098", new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a3"), new DateTime(2024, 4, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 9, 9, 8, 34, 41, 91, DateTimeKind.Utc).AddTicks(3451) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Nursery_PlantId",
                table: "Nursery",
                column: "PlantId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Nursery");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Plants");
        }
    }
}
