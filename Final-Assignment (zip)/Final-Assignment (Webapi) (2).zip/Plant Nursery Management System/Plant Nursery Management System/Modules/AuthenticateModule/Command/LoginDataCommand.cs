﻿using MediatR;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.AuthenticateModule.Command
{
    public class LoginDataCommand : IRequest<TokenModel>
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
