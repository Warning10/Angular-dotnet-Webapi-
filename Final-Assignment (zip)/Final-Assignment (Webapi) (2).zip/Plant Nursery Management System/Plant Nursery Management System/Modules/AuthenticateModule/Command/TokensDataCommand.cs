﻿using MediatR;
using Plant_Nursery_Management_System.Models;

namespace Student_Teacher.Modules.AuthenticateModule.Command
{
    public class TokensDataCommand : IRequest<TokenModel>
    {
        public string AccessToken { get; set; }

        public string RefreshToken { get; set; }
    }
}
