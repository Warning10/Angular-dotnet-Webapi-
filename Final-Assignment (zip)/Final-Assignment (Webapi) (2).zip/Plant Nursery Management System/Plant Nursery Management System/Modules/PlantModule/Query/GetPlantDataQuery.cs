﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.PlantModule.Query
{
    public class GetPlantDataQuery : IRequest<List<PlantModel>>
    {
    }

    public class GetPlantDataQueryHandler : IRequestHandler<GetPlantDataQuery, List<PlantModel>>
    {
        private readonly IGenericRepository<PlantModel> _genericRepository;

        public GetPlantDataQueryHandler(IGenericRepository<PlantModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<List<PlantModel>> Handle(GetPlantDataQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllData();
        }
    }
}
