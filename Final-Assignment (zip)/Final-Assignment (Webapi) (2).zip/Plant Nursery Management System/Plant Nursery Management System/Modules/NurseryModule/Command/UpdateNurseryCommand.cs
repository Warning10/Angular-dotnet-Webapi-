﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Command
{
    public class UpdateNurseryCommand : NurseryCommand
    {
        public Guid Id { get; set; }

    }

    public class UpdateNurseryCommandHandler : IRequestHandler<UpdateNurseryCommand, bool>
    {
        private readonly IGenericRepository<NurseryModel> _genericRepository;

        public UpdateNurseryCommandHandler(IGenericRepository<NurseryModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(UpdateNurseryCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new NurseryCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var result = await _genericRepository.GetByIdData(request.Id);
            if (result == null)
            {
                return false;
            }

            result.Id = request.Id;
            result.FirstName = request.FirstName;
            result.LastName = request.LastName;
            result.EmailAddress = request.EmailAddress;
            result.MobileNumber = request.MobileNumber;
            result.Address = request.Address;
            result.PlantId = request.PlantId;
            result.StartDate = request.StartDate;
            result.EndDate = request.EndDate;
            result.Updated = DateTime.UtcNow;

            _genericRepository.SaveData();

            return true;
        }
    }
}
