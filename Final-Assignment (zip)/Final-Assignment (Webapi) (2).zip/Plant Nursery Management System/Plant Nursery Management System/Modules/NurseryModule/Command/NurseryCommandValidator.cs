﻿using FluentValidation;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Command
{
    public class NurseryCommandValidator : AbstractValidator<NurseryCommand>
    {
        public NurseryCommandValidator()
        {
            RuleFor(x => x.FirstName)
                .NotNull()
                .WithMessage("First Name cannot be null.")
                .NotEmpty()
                .WithMessage("First Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("First Name must be between 1 and 50 characters.");

            RuleFor(x => x.LastName)
                .NotNull()
                .WithMessage("Last Name cannot be null.")
                .NotEmpty()
                .WithMessage("Last Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("Last Name must be between 1 and 50 characters.");

            RuleFor(x => x.EmailAddress)
                .NotNull()
                .WithMessage("Email Address cannot be null.")
                .NotEmpty()
                .WithMessage("Email Address cannot be empty.")
                .EmailAddress()
                .WithMessage("Invalid email address format.")
                .Length(1, 100)
                .WithMessage("Email Address must be between 1 and 100 characters.");

            RuleFor(x => x.MobileNumber)
                .NotNull()
                .WithMessage("Mobile Number cannot be null.")
                .NotEmpty()
                .WithMessage("Mobile Number cannot be empty.")
                .Matches(@"^\d{10}$")
                .WithMessage("Mobile Number must be exactly 10 digits.");

            RuleFor(x => x.Address)
                .NotNull()
                .WithMessage("Address cannot be null.")
                .NotEmpty()
                .WithMessage("Address cannot be empty.")
                .Length(1, 250)
                .WithMessage("Address must be between 1 and 250 characters.");

            RuleFor(x => x.PlantId)
                .NotEmpty()
                .WithMessage("Plant Id is required.");

            RuleFor(x => x.StartDate)
                .LessThanOrEqualTo(x => x.EndDate)
                .WithMessage("Start Date must be less than or equal to End Date.");

            RuleFor(x => x.EndDate)
                .GreaterThanOrEqualTo(x => x.StartDate)
                .WithMessage("End Date must be greater than or equal to Start Date.");
        }
    }
}
