﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Query
{
    public class GetNurseryDataQuery : IRequest<List<NurseryModel>> { }

    public class GetNurseryDataQueryHandler : IRequestHandler<GetNurseryDataQuery, List<NurseryModel>>
    {
        private readonly IGenericRepository<NurseryModel> _genericRepository;
        public GetNurseryDataQueryHandler(IGenericRepository<NurseryModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<List<NurseryModel>> Handle(GetNurseryDataQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllData();

        }


    }
}
