﻿using MediatR;
using Plant_Nursery_Management_System.Interfaces;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Modules.NurseryModule.Query
{
    public class GetNurseryByIdQuery : IRequest<NurseryModel>
    {
        public Guid Id { get; set; }
    }

    public class GetNurseryByIdQueryHandler : IRequestHandler<GetNurseryByIdQuery, NurseryModel>
    {
        private readonly IGenericRepository<NurseryModel> _genericRepository;

        public GetNurseryByIdQueryHandler(IGenericRepository<NurseryModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<NurseryModel> Handle(GetNurseryByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdData(request.Id);

        }
    }
}
