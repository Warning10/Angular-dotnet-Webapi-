﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Utils.Configurations
{
    public class NurseryConfiguration : IEntityTypeConfiguration<NurseryModel>
    {
        public void Configure(EntityTypeBuilder<NurseryModel> builder)
        {
            builder.HasData(
            new NurseryModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Aarav",
                LastName = "Sharma",
                EmailAddress = "aarav.sharma@example.com",
                MobileNumber = "987-654-3210",
                Address = "1/2, Green Garden, Mumbai, Maharashtra",
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                StartDate = new DateTime(2024, 1, 15),
                EndDate = new DateTime(2024, 2, 15),
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new NurseryModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Neha",
                LastName = "Gupta",
                EmailAddress = "neha.gupta@example.com",
                MobileNumber = "876-543-2109",
                Address = "4A, North Avenue, Delhi, Delhi",
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a2"),
                StartDate = new DateTime(2024, 3, 1),
                EndDate = new DateTime(2024, 4, 1),
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new NurseryModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Dev",
                LastName = "Patel",
                EmailAddress = "dev.patel@example.com",
                MobileNumber = "765-432-1098",
                Address = "5B, Lakeview Apartments, Bangalore, Karnataka",
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a3"),
                StartDate = new DateTime(2024, 4, 10),
                EndDate = new DateTime(2024, 5, 10),
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new NurseryModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Priya",
                LastName = "Reddy",
                EmailAddress = "priya.reddy@example.com",
                MobileNumber = "654-321-0987",
                Address = "2C, Beach Road, Chennai, Tamil Nadu",
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a4"),
                StartDate = new DateTime(2024, 5, 20),
                EndDate = new DateTime(2024, 6, 20),
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            },
            new NurseryModel
            {
                Id = Guid.NewGuid(),
                FirstName = "Vijay",
                LastName = "Singh",
                EmailAddress = "vijay.singh@example.com",
                MobileNumber = "543-210-9876",
                Address = "7D, Tech Park, Hyderabad, Telangana",
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a5"),
                StartDate = new DateTime(2024, 6, 30),
                EndDate = new DateTime(2024, 7, 30),
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }
            );
        }
    }
}
