﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Plant_Nursery_Management_System.Models;

namespace Plant_Nursery_Management_System.Utils.Configurations
{
    public class PlantConfiguration : IEntityTypeConfiguration<PlantModel>
    {
        public void Configure(EntityTypeBuilder<PlantModel> builder)
        {
            builder.HasData(
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                PlantName = "Jasmine",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            },
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a2"),
                PlantName = "Bamboo",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            },
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a3"),
                PlantName = "Aloe Vera",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            },
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a4"),
                PlantName = "Peace Lily",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            },
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a5"),
                PlantName = "Tulsi",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            },
            new PlantModel
            {
                PlantId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a6"),
                PlantName = "Jade",
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            }
            );
        }
    }
}
