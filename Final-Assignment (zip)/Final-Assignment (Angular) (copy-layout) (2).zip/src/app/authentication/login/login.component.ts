import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/services/user.service';
import { Login } from '../../shared/interfaces/login.interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  public loginForm!: FormGroup;

  constructor(
    private userService: UserService,
    private router: Router,
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    localStorage.clear();

    this.loginForm = this.formBuilder.group({
      email: [
        '',
        [
          Validators.required,
          Validators.email,
          Validators.minLength(6),
          Validators.maxLength(50),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.pattern(
            '^[a-zA-Z0-9!@#$%^&*()_+={}\\[\\]|;:\'",.<>/?-]+$'
          ),
        ],
      ],
    });
  }

  // Handles user login, validates form, performs authentication, and navigates to home on success.
  public onLogin(): void {
    if (this.loginForm.invalid) {
      this.toastr.error(
        'Please fill out the form correctly.',
        'Validation Error'
      );
      return;
    }

    const loginData: Login = this.loginForm.value;

    this.userService.login(loginData).subscribe({
      next: (result) => {
        localStorage.setItem('Email', this.loginForm.value.email);
        localStorage.setItem('AccessToken', result.accessToken);
        localStorage.setItem('RefreshToken', result.refreshToken);
        this.router.navigate(['/layout/nursery-list']);
        this.toastr.success('Login successful!', 'Success');
      },
      error: (err) => {
        this.handleError(err);
      },
    });
  }

  // Processes and displays error messages using toastr based on the error object.
  private handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
      if (typeof error.error === 'object') {
        errorMessage = error.error.message || errorMessage;
      } else {
        errorMessage = error.error;
      }
    } else if (error.message) {
      errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
  }
}
