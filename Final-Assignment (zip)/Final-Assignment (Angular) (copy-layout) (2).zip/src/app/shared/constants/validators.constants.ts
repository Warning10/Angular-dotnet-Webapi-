import { AbstractControl, ValidatorFn, Validators } from '@angular/forms';

export class ValidatorsConstant {
  public static EmailPatern =
    /^[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  public static readonly NameValidators = [
    Validators.required,
    Validators.minLength(2),
    Validators.maxLength(20),
    Validators.pattern(/^[A-Za-z]+( [A-Za-z]+)*$/),
  ];

  public static readonly MobileNumberValidators = [
    Validators.required,
    Validators.pattern(/^\d{10}$/),
  ];

  public static readonly EmailValidators = [
    Validators.required,
    Validators.pattern(this.EmailPatern),
  ];

  public static readonly AddressValidators = [
    Validators.required,
    Validators.minLength(10), // Minimum length of 10 characters
    Validators.maxLength(50), // Maximum length of 100 characters
    ValidatorsConstant.addressPatternValidator(), // Custom regex pattern validator
  ];

  public static addressPatternValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value = control.value || '';

      // This pattern ensures:
      // 1. No leading or trailing spaces.
      // 2. Only single spaces between words.
      const isValid = /^[a-zA-Z0-9.,\-\/#' ]+(?: [a-zA-Z0-9.,\-\/#' ]+)*$/.test(
        value
      );

      return isValid ? null : { addressInvalid: true };
    };
  }
}
