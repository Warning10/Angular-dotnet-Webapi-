import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private loggedIn = false; // By default, the user is not logged in

  constructor() {}

  // Call this when logging in
  login() {
    this.loggedIn = true;
  }

  // Call this when logging out
  logout() {
    this.loggedIn = false;
  }

  // To check the login status
  public isLoggedIn(): boolean {
    const token = localStorage.getItem('AccessToken');
    if (token) {
      return true;
    } else {
      return false;
    }
  }
}
