import { HttpHeaders } from '@angular/common/http';

export class RouteConstants {
  public static readonly NurseryApiUrl = 'https://localhost:7197/api/Nursery';
  public static readonly UserApiUrl = 'https://localhost:7197/api/Authenticate';
  public static readonly PlantApiUrl = 'https://localhost:7197/api/Plant/all';

  public static getHeader() {
    let headers = new HttpHeaders().set(
      'Authorization',
      `bearer ${localStorage.getItem('AccessToken')}`
    );
    return headers;
  }
}
