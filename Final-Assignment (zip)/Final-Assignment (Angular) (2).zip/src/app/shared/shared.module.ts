import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavBarComponent } from './layout/nav-bar/nav-bar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { SideBarComponent } from './layout/side-bar/side-bar.component';
import { DeleteModalComponent } from './modal/delete-modal/delete-modal.component';

@NgModule({
  declarations: [
    NavBarComponent,
    FooterComponent,
    SideBarComponent,
    DeleteModalComponent,
  ],
  imports: [CommonModule],
  exports: [
    NavBarComponent,
    FooterComponent,
    SideBarComponent,
    DeleteModalComponent,
  ],
})
export class SharedModule {}
