import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss',
})
export class NavBarComponent {
  isLoggedIn: boolean = false;

  constructor(private router: Router, private toastr: ToastrService) {}

  public isLoginIn(): boolean {
    const token = localStorage.getItem('AccessToken');
    if (token) {
      return true;
    } else {
      return false;
    }
  }

  login(): void {
    this.isLoggedIn = true;
    this.router.navigate(['/login']); // Example, replace with actual login logic
  }
  public logout(): void {
    localStorage.clear();
    this.toastr.success('You have been logged out successfully.', 'Logout');
    this.router.navigate(['/login']);
    this.isLoggedIn = false;
  }
}
