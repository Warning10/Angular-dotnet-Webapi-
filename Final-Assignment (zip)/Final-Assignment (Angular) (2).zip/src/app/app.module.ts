import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { NurseryModule } from './modules/nursery/nursery.module';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { JwtModule } from '@auth0/angular-jwt';
import { ApiConstants } from './shared/constants/api.constants';
import { LoginComponent } from './modules/authentication/login/login.component';
import { NurseryListComponent } from './modules/nursery/nursery-list/nursery-list.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { HomeModule } from './modules/home/home.module';
import { HomeComponent } from './modules/home/home.component';

export function tokenGetter() {
  return localStorage.getItem('AccessToken');
}
const routes: Routes = [
  { path: ApiConstants.DefaultRoute, component: HomeComponent },
  { path: ApiConstants.LoginRoute, component: LoginComponent },
  {
    path: ApiConstants.NurseryListRoute,
    component: NurseryListComponent,
    canActivate: [AuthGuard],
  },
  //{ path: ApiConstants.WildCardRoute, component: NotFoundComponent },
];
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    SharedModule,
    NurseryModule,
    HomeModule,
    AuthenticationModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ['http://localhost:4200'],
        disallowedRoutes: [],
      },
    }),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
