import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wildcard',
  templateUrl: './wildcard.component.html',
  styleUrls: ['./wildcard.component.scss'],
})
export class WildcardComponent {
  buttonText: string = 'Go to Homepage';
  constructor(private router: Router) {}

  ngOnInit(): void {
    this.updateButtonText();
  }

  goHome() {
    const email = localStorage.getItem('Email');
    if (email) {
      // Navigate to home if email is present
      this.router.navigate(['/layout']);
    } else {
      // Navigate to login if email is not present
      this.router.navigate(['/login']);
    }
  }

  updateButtonText() {
    const email = localStorage.getItem('Email');
    if (email) {
      this.buttonText = 'Go to Homepage';
    } else {
      this.buttonText = 'Login to Continue';
    }
  }
}
