import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeleteModalComponent } from './components/delete-modal/delete-modal.component';
import { WildcardComponent } from './components/wildcard/wildcard.component';

@NgModule({
  declarations: [DeleteModalComponent, WildcardComponent],
  imports: [CommonModule],
  exports: [DeleteModalComponent, WildcardComponent],
})
export class SharedModule {}
