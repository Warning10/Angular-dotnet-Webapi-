import { Validators } from '@angular/forms';


export class ValidatorsConstant {
  public static readonly NameValidators = [
    Validators.required, // Field is required
    Validators.minLength(2), // Minimum length of 2 characters
    Validators.maxLength(20), // Maximum length of 50 characters
    Validators.pattern(/^[A-Za-z]+( [A-Za-z]+)*$/), // Only letters and single spaces between words
  ];

  public static readonly MobileNumberValidators = [
    Validators.required,
    Validators.pattern(/^\d{10}$/),
  ];

  public static readonly EmailValidators = [
    Validators.required, // Field is required
    Validators.pattern(
      /^[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/
    ),
  ];
}
