export interface Nursery {
  id: string;
  firstName: string;
  lastName: string;
  emailAddress: string;
  mobileNumber: string;
  address: string;
  plantId: string;
  plant: null;
  startDate: string;
  endDate: string;
  created: string;
  updated: string;
}
