import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NurseryListComponent } from './nursery-list/nursery-list.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { SharedModule } from '../../shared/shared.module';
import { NurseryFormComponent } from './nursery-form/nursery-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApiConstants } from '../../shared/constants/api.constants';
import { AuthGuard } from '../../shared/guards/auth.guard';

const routes: Routes = [
  {
    path: ApiConstants.NurseryListRoute,
    component: NurseryListComponent,
    canActivate: [AuthGuard],
  },
  {
    path: ApiConstants.NurseryFormRoute,
    component: NurseryFormComponent,
    canActivate: [AuthGuard],
  },
  {
    path: ApiConstants.NurseryEditRoute,
    component: NurseryFormComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  declarations: [NurseryListComponent, NurseryFormComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    ToastrModule.forRoot({
      timeOut: 2000,
      positionClass: 'toast-top-center',
      preventDuplicates: true,
    }),
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
  ],
})
export class NurseryModule {}
