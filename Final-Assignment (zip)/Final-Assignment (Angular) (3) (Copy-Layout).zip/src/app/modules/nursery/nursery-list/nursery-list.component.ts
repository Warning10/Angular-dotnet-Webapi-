import { Component } from '@angular/core';
import { NurseryService } from '../../../shared/services/nursery.service';
import { Nursery } from '../../../shared/interfaces/nursery.interface';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nursery-list',
  templateUrl: './nursery-list.component.html',
  styleUrl: './nursery-list.component.scss',
})
export class NurseryListComponent {
  public isApiActive: boolean = false;
  public nursery: Nursery[] = [];
  public errorMessage: string | null = null;
  public plantNames: { [key: string]: string } = {};
  public isModalVisible = false;
  public itemToDelete: { id: string; name: string } | null = null;

  constructor(
    private nurseryService: NurseryService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadNursery();
    this.loadPlants();
  }

  // Sets up the item to be deleted and shows the confirmation modal.
  public showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  // Clears the item to be deleted and hides the confirmation modal.
  public handleCancelDelete() {
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  public handleConfirmDelete(id: string | null) {
    if (id) {
      this.nurseryService.deleteNursery(id).subscribe({
        next: () => {
          this.nursery = this.nursery.filter((nursery) => nursery.id !== id);
          this.toastr.success('Nursery deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the nursery.';
          this.toastr.error('Error deleting nursery');
        },
        complete: () => {
          console.log('Delete nursery complete');
        },
      });
    }
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  private loadNursery(): void {
    this.nurseryService.getallNursery().subscribe({
      next: (data: Nursery[]) => {
        setTimeout(() => {
          this.nursery = data;
          this.isApiActive = true;
          this.toastr.info('Nursery data loaded successfully');
        }, 1000);
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching nursery data.';
        this.toastr.error('Error fetching nursery');
      },
      complete: () => {
        console.log('Load nursery complete');
      },
    });
  }

  public editNursery(id: string): void {
    this.router.navigate(['/layout/edit-nursery', id]);
  }

  private loadPlants() {
    this.nurseryService.getPlants().subscribe((plants) => {
      this.plantNames = plants.reduce((map, plant) => {
        map[plant.plantId] = plant.plantName;
        return map;
      }, {} as { [key: string]: string });
    });
  }

  public getPlantName(plantId: string | null): string {
    return plantId
      ? this.plantNames[plantId] || 'Unknown Plant'
      : 'No Plant ID';
  }
}
