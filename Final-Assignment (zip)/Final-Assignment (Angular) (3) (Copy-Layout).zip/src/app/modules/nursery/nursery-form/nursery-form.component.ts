import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Plant } from '../../../shared/interfaces/plant.interface';
import { NurseryService } from '../../../shared/services/nursery.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Nursery } from '../../../shared/interfaces/nursery.interface';
import { ValidatorsConstant } from '../../../shared/constants/validators.constants';

@Component({
  selector: 'app-nursery-form',
  templateUrl: './nursery-form.component.html',
  styleUrl: './nursery-form.component.scss',
})
export class NurseryFormComponent {
  public nurseryForm: FormGroup;
  public isEditMode: boolean = false;
  private nurseryId: string | null = null;
  public plants: Plant[] = [];
  minDate: string = new Date().toISOString().split('T')[0];

  constructor(
    private fb: FormBuilder,
    private nurseryService: NurseryService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService
  ) {
    this.nurseryForm = this.fb.group({
      firstName: ['', ValidatorsConstant.NameValidators],
      lastName: ['', ValidatorsConstant.NameValidators],
      emailAddress: ['', ValidatorsConstant.EmailValidators],
      mobileNumber: ['', ValidatorsConstant.MobileNumberValidators],
      address: ['', [Validators.required, Validators.pattern(/\S+/)]],
      plantId: ['', [Validators.required, Validators.pattern(/\S+/)]],
      startDate: [
        '',
        [Validators.required, Validators.pattern(/\d{4}-\d{2}-\d{2}/)],
      ],
      endDate: [
        '',
        [Validators.required, Validators.pattern(/\d{4}-\d{2}-\d{2}/)],
      ],
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.nurseryId = params.get('id');
      if (this.nurseryId) {
        this.isEditMode = true;
        this.loadNurseryData(this.nurseryId);
      }
    });
    this.loadPlants();
  }

  public loadNurseryData(id: string): void {
    this.nurseryService.getNursery(id).subscribe({
      next: (nursery: Nursery) => {
        this.nurseryForm.patchValue({
          ...nursery,
          startDate: this.formatDate(nursery.startDate),
          endDate: this.formatDate(nursery.endDate),
        });
      },
      error: (error: any) => {
        this.toastr.error('Error fetching nursery data');
      },
      complete: () => {
        console.log('Load nursery data complete');
      },
    });
  }

  public loadPlants(): void {
    this.nurseryService.getPlants().subscribe({
      next: (plants: Plant[]) => {
        this.plants = plants;
      },
      error: (error: any) => {
        this.toastr.error('Error fetching plants');
      },
      complete: () => {
        console.log('Load plants complete');
      },
    });
  }

  private formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  }

  public onSubmit(): void {
    if (this.nurseryForm.valid) {
      const nurseryData = this.nurseryForm.value;
      if (this.isEditMode && this.nurseryId) {
        this.nurseryService
          .updateNursery(this.nurseryId, nurseryData)
          .subscribe({
            next: () => {
              this.toastr.success('Nursery updated successfully');
              this.router.navigate(['/layout/nursery-list']);
            },
            error: (error: any) => {
              this.handleError(error);
            },
            complete: () => {
              console.log('Update nursery complete');
            },
          });
      } else {
        this.nurseryService.addNursery(nurseryData).subscribe({
          next: () => {
            this.toastr.success('Nursery added successfully');
            this.router.navigate(['/layout/nursery-list']);
          },
          error: (error: any) => {
            this.handleError(error);
          },
          complete: () => {
            console.log('Add Nursery complete');
          },
        });
      }
    }
  }

  private handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
      if (typeof error.error === 'object') {
        errorMessage = error.error.message || errorMessage;
      } else {
        errorMessage = error.error;
      }
    } else if (error.message) {
      errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
  }

  public goBack(): void {
    this.router.navigate(['/layout/nursery-list']);
  }

  resetForm() {
    this.nurseryForm.reset(); // This will clear all the form fields
  }
}
