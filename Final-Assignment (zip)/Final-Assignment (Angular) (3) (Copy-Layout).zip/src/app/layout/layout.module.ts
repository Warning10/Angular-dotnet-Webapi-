import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { FooterComponent } from './footer/footer.component';
import { LayoutComponent } from './layout.component';
import { AuthGuard } from '../shared/guards/auth.guard';
import { HomeComponent } from './home/home.component';

const nurseryModule = () =>
  import('../modules/nursery/nursery.module').then((x) => x.NurseryModule);
const routes: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  {
    path: '',
    children: [{ path: '', loadChildren: nurseryModule }],
    canActivate: [AuthGuard],
  },
];

@NgModule({
  declarations: [
    LayoutComponent,
    NavBarComponent,
    SideBarComponent,
    FooterComponent,
    HomeComponent,
  ],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [],
})
export class LayoutModule {}
