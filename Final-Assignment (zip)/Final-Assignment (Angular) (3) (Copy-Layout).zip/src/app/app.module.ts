import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { JwtModule } from '@auth0/angular-jwt';
import { ApiConstants } from './shared/constants/api.constants';
import { WildcardComponent } from './shared/components/wildcard/wildcard.component';
import { LoginComponent } from './authentication/login/login.component';
import { AuthenticationModule } from './authentication/authentication.module';
import { LayoutComponent } from './layout/layout.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

export function tokenGetter() {
  return localStorage.getItem('AccessToken');
}

const layoutModule = () =>
  import('./layout/layout.module').then((x) => x.LayoutModule);

const routes: Routes = [
  { path: ApiConstants.DefaultRoute, component: LoginComponent },
  {
    path: 'layout',
    component: LayoutComponent,
    children: [{ path: '', loadChildren: layoutModule }],
    canActivate: [AuthGuard],
  },
  { path: ApiConstants.WildCardRoute, component: WildcardComponent },
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    SharedModule,
    AuthenticationModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ['http://localhost:4200'],
        disallowedRoutes: [],
      },
    }),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
