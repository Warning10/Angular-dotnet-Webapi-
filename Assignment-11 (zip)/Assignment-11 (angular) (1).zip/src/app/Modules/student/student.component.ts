import { Component } from "@angular/core";

@Component({
    selector: 'student',
    template: "<h1>Hello Atharva from template student component</h1>",
    styles: [' h1 {color: red; text-align: center;}']
})
export class StudentComponent {}