import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentComponent } from './Modules/student/student.component';
import { DepartmentComponent } from './Modules/department/department.component';
import { FacultyComponent } from './Modules/faculty/faculty.component';
import { EmployeeComponent } from './Modules/employee/employee.component';
import { CardComponent } from './shared/card/card.component';
import { FormsModule } from '@angular/forms';
import { ProductComponent } from './Modules/product/product.component';
import { PriceFormatPipe } from './shared/pipes/price-format.pipe';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    DepartmentComponent,
    FacultyComponent,
    EmployeeComponent,
    CardComponent,
    ProductComponent,
    PriceFormatPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
