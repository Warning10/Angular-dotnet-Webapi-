import { Component, OnInit } from '@angular/core';
import * as bootstrap from 'bootstrap';
import { IEmployee } from '../../../shared/interface/employee.model';
import { EmployeeDataService } from '../../../shared/services/employee-data-service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {
  employees: IEmployee[] = [];
  selectedEmployeeId: number | null = null;
  selectedEmployeeName: string | null = null;

  constructor(
    private employeeService: EmployeeDataService,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getAllEmployee().subscribe({
      next: (data: IEmployee[]) => {
        this.employees = data;
      },
      error: (err) => {
        console.log('Error loading employees', err);
      }
    });
  }

  openDeleteModal(id: number | undefined, name: string): void {
    if (id !== undefined) {
      this.selectedEmployeeId = id;
      this.selectedEmployeeName = name;
      const modalElement = document.getElementById('deleteModal');
      if (modalElement) {
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
      }
    } else {
      this.toastr.error('Employee ID is undefined');
    }
  }
  

  handleDeleteConfirm(id: number): void {
    if (id !== null) {
      this.employeeService.deleteEmployee(id).subscribe({
        next: () => {
          this.employees = this.employees.filter(emp => emp.id !== id);
          this.toastr.success('Employee deleted successfully');
          this.handleDeleteCancel(); // Close modal after deletion
        },
        error: (err) => {
          this.toastr.error('Error deleting employee', err);
        }
      });
    }
  }

  handleDeleteCancel(): void {
    this.selectedEmployeeId = null;
    this.selectedEmployeeName = null;
    const modalElement = document.getElementById('deleteModal');
    if (modalElement) {
      const modal = bootstrap.Modal.getInstance(modalElement);
      if (modal) {
        modal.hide();
      }
    }
  }
}
