import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.scss']
})
export class DeleteModalComponent {
  @Input() employeeId: number | null = null;
  @Input() employeeName: string | null = null;
  @Output() confirmDelete = new EventEmitter<number>();
  @Output() cancelDelete = new EventEmitter<void>();

  onConfirm(): void {
    if (this.employeeId !== null) {
      this.confirmDelete.emit(this.employeeId);
    }
  }

  onCancel(): void {
    this.cancelDelete.emit();
  }
}
