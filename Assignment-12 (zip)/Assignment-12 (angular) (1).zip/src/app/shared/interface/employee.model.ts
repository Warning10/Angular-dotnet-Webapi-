export interface IEmployee {
    id?: number;
    name: string;
    email: string;
    gender: string;
    address: string;
    designation: string;
    deptId: number;
    dateOfBirth: string;
    dateOfJoining: string;
    isActive: boolean;
    created?: string;
    updated?: string;
}