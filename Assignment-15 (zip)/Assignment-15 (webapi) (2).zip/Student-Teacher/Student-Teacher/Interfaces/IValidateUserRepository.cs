﻿using Student_Teacher.Models;

namespace Student_Teacher.Interfaces
{
    public interface IValidateUserRepository
    {
        Task<UserModel> GetByUserName(string username);
    }
}
