﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DeptName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.DeptId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RefreshTokenExpiryTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "StudentModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StudentModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherModel",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DeptId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Updated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TeacherModel_Departments_DeptId",
                        column: x => x.DeptId,
                        principalTable: "Departments",
                        principalColumn: "DeptId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Departments",
                columns: new[] { "DeptId", "Created", "DeptName", "Updated" },
                values: new object[,]
                {
                    { new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1061), "Computer", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1061) },
                    { new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1066), "Mechanical", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1067) },
                    { new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1064), "Information Technology", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1064) },
                    { new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1068), "Civil", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1069) },
                    { new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1070), "Production", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1071) }
                });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("12a945c2-3edf-40cd-931b-6c304b322574"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(682), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(681), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(683) },
                    { new Guid("a899b11d-40b0-4e7b-a4b6-462325832a0e"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(707), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(706), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(707) },
                    { new Guid("bf167caf-8848-472f-b5fd-2f5c3bc94a5c"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(677), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(675), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(677) },
                    { new Guid("c0ffb62a-7230-4165-87e0-47a86aeef1f2"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(690), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(690), "Diana", "Female", "8th", "Brown", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(691) },
                    { new Guid("d0a50848-bbe3-484a-8014-a26269fcde11"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(686), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(686), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(687) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("22b9c2bd-1896-4e56-9a15-5bcbba952994"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(953), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(953) },
                    { new Guid("539b295e-fdeb-461c-82f0-0e1bcc665934"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(956), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(957) },
                    { new Guid("c44cec8d-0ea8-4d75-8573-79e01749646b"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(945), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(946) },
                    { new Guid("f0b33ae9-672a-44af-a66a-60fcecd65d68"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(941), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(941) },
                    { new Guid("fe09f52b-ab4f-44f9-9b1c-4b3659825eea"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(949), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(949) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentModel_DeptId",
                table: "StudentModel",
                column: "DeptId");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherModel_DeptId",
                table: "TeacherModel",
                column: "DeptId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentModel");

            migrationBuilder.DropTable(
                name: "TeacherModel");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Departments");
        }
    }
}
