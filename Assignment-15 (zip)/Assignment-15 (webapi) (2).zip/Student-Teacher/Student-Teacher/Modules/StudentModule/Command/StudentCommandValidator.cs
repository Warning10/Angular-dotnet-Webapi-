﻿using FluentValidation;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class StudentCommandValidator : AbstractValidator<StudentCommand>
    {
        public StudentCommandValidator()
        {
            // Validate FirstName
            RuleFor(x => x.FirstName)
                .NotNull()
                .WithMessage("First Name cannot be null.")
                .NotEmpty()
                .WithMessage("First Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("First Name must be between 1 and 50 characters.")
                .Matches(@"^[a-zA-Z]+$")
                .WithMessage("First Name can only contain alphabets.");

            // Validate LastName
            RuleFor(x => x.LastName)
                .NotNull()
                .WithMessage("Last Name cannot be null.")
                .NotEmpty()
                .WithMessage("Last Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("Last Name must be between 1 and 50 characters.")
                .Matches(@"^[a-zA-Z]+$")
                .WithMessage("Last Name can only contain alphabets.");

            // Validate Email
            RuleFor(x => x.Email)
                .NotNull()
                .WithMessage("Email cannot be null.")
                .NotEmpty()
                .WithMessage("Email is required.")
                .EmailAddress()
                .WithMessage("Invalid email address format.")
                .Length(1, 100)
                .WithMessage("Email must not exceed 100 characters.");

            // Validate Gender
            RuleFor(x => x.Gender)
                .NotNull()
                .WithMessage("Gender cannot be null.")
                .NotEmpty()
                .WithMessage("Gender is required.")
                .Must(gender => gender == "Male" || gender == "male" || gender == "Female" || gender == "female")
                .WithMessage("Gender must be either 'Male', 'Female', or 'Other'.");

            // Validate DeptId
            RuleFor(x => x.DeptId)
                .NotEmpty()
                .WithMessage("Department ID cannot be empty.");

            // Validate DateOfBirth
            RuleFor(x => x.DateOfBirth)
                .NotNull()
                .WithMessage("Date of Birth cannot be null.")
                .NotEmpty()
                .WithMessage("Date of Birth is required.")
                .Must(date => date < DateTime.UtcNow)
                .WithMessage("Date of Birth must be in the past.")
                .Must(date => date <= DateTime.UtcNow.AddYears(-18))
                .WithMessage("User must be at least 18 years old.");

            // Validate EnrollmentDate
            RuleFor(x => x.EnrollmentDate)
                .NotNull()
                .WithMessage("Enrollment Date cannot be null.")
                .NotEmpty()
                .WithMessage("Enrollment Date is required.")
                .Must(date => date <= DateTime.UtcNow)
                .WithMessage("Enrollment Date must be in the past or today.");

            // Validate that EnrollmentDate is after DateOfBirth
            RuleFor(x => x)
                .Must(x => x.DateOfBirth < x.EnrollmentDate)
                .WithMessage("Date of Birth must be prior to the Enrollment Date.");

            // Validate Grade
            RuleFor(x => x.Grade)
                .NotNull()
                .WithMessage("Grade cannot be null.")
                .NotEmpty()
                .WithMessage("Grade is required.")
                .Length(1, 10)
                .WithMessage("Grade must be between 1 and 10 characters.");
        }
    }
}

