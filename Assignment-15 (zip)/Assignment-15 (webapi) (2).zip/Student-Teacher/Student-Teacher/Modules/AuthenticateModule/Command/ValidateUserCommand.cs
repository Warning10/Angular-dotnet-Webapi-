﻿using Department_Teacher.Modules.DepartmentModule.Command;
using MediatR;
using Student_Teacher.Interfaces;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.AuthenticateModule.Command
{
    public class ValidateUserCommand : LoginDataCommand
    {
    }

    public class ValidateUserCommandHandler : IRequestHandler<ValidateUserCommand, TokenModel>
    {
        private readonly IGenericRepository<UserModel> _genericRepository;
        private readonly IValidateUserRepository _validateUserRepository;
        private readonly IGenerateToken _generateToken;

        public ValidateUserCommandHandler(IGenericRepository<UserModel> genericRepository, IValidateUserRepository validateUserRepository, IGenerateToken generateToken)
        {
            _genericRepository = genericRepository;
            _validateUserRepository = validateUserRepository;
            _generateToken = generateToken;
        }

        public async Task<TokenModel> Handle(ValidateUserCommand request, CancellationToken cancellationToken)
        {
            var users = await _validateUserRepository.GetByUserName(request.UserName);
            if (users == null || users.Password != request.Password)
            {
                throw new Exception("Invalid Credentials");
            }

            var tokens = await _generateToken.GenerateTokens(users.Username);
            users.RefreshToken = tokens.RefreshToken;
            users.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(2);
            _genericRepository.SaveData();
            return tokens;



        }
    }
}
