﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.AuthenticateModule.Command
{
    public class TokensDataCommand : IRequest<TokenModel>
    {
        public string AccessToken { get; set; }

        public string RefreshToken { get; set; }
    }
}
