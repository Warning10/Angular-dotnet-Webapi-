﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.TeacherModule.Query
{
    public class GetTeacherByIdQuery : IRequest<TeacherModel>
    {
        public Guid Id { get; set; }
    }

    public class GetTeacherByIdQueryHandler : IRequestHandler<GetTeacherByIdQuery, TeacherModel>
    {
        private readonly IGenericRepository<TeacherModel> _genericRepository;

        public GetTeacherByIdQueryHandler(IGenericRepository<TeacherModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<TeacherModel> Handle(GetTeacherByIdQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetByIdAsync(request.Id);
        }
    }

}

