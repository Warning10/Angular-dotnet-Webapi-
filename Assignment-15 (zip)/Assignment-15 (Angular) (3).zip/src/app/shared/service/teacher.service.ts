import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DepartmentService } from './department.service';
import { Observable } from 'rxjs';
import { Teacher } from '../interface/teacher-interface';
import { Department } from '../interface/department-interface';
import { RouteConstants } from '../constants/route.constants';

@Injectable({
  providedIn: 'root',
})
export class TeacherService {
  constructor(
    private http: HttpClient,
    private departmentService: DepartmentService
  ) {}

  getAllteacher(): Observable<Teacher[]> {
    return this.http.get<Teacher[]>(`${RouteConstants.TeacherApiUrl}/all`, {
      headers: RouteConstants.getHeader(),
    });
  }

  addTeacher(teacher: Teacher): Observable<Teacher> {
    return this.http.post<Teacher>(
      `${RouteConstants.TeacherApiUrl}/create`,
      teacher,
      { headers: RouteConstants.getHeader() }
    );
  }

  getTeacher(id: string): Observable<Teacher> {
    return this.http.get<Teacher>(
      `${RouteConstants.TeacherApiUrl}/byid/${id}`,
      { headers: RouteConstants.getHeader() }
    );
  }

  updateTeacher(id: string, teacher: Partial<Teacher>): Observable<Teacher> {
    return this.http.put<Teacher>(
      `${RouteConstants.TeacherApiUrl}/update/${id}`,
      teacher,
      { headers: RouteConstants.getHeader() }
    );
  }

  deleteTeacher(id: string): Observable<void> {
    return this.http.delete<void>(
      `${RouteConstants.TeacherApiUrl}/delete/${id}`,
      { headers: RouteConstants.getHeader() }
    );
  }

  getDepartments(): Observable<Department[]> {
    return this.departmentService.getAllDepartments();
  }
}
