import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from '../interface/student-interface';
import { DepartmentService } from './department.service';
import { Department } from '../interface/department-interface';
import { RouteConstants } from '../constants/route.constants';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  constructor(
    private http: HttpClient,
    private departmentService: DepartmentService
  ) {}

  getAllStudents(): Observable<Student[]> {
    return this.http.get<Student[]>(`${RouteConstants.StudentApiUrl}/all`, {
      headers: RouteConstants.getHeader(),
    });
  }

  addStudent(student: Student): Observable<Student> {
    return this.http.post<Student>(
      `${RouteConstants.StudentApiUrl}/create`,
      student,
      { headers: RouteConstants.getHeader() }
    );
  }

  getStudent(id: string): Observable<Student> {
    return this.http.get<Student>(
      `${RouteConstants.StudentApiUrl}/byid/${id}`,
      { headers: RouteConstants.getHeader() }
    );
  }

  updateStudent(id: string, student: Partial<Student>): Observable<Student> {
    return this.http.put<Student>(
      `${RouteConstants.StudentApiUrl}/update/${id}`,
      student,
      { headers: RouteConstants.getHeader() }
    );
  }

  deleteStudent(id: string): Observable<void> {
    return this.http.delete<void>(
      `${RouteConstants.StudentApiUrl}/delete/${id}`,
      { headers: RouteConstants.getHeader() }
    );
  }

  getDepartments(): Observable<Department[]> {
    return this.departmentService.getAllDepartments();
  }
}
