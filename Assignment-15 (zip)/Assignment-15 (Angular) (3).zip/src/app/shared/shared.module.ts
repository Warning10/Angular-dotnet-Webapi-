import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavBarComponent } from './layout/nav-bar/nav-bar.component';
import { SideBarComponent } from './layout/side-bar/side-bar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { AppRoutingModule } from '../app-routing.module';
import { DeleteModalComponent } from './modal/delete-modal/delete-modal.component';
import { RouterModule, Routes } from '@angular/router';
import { StudentListComponent } from '../modules/student/student-list/student-list.component';
import { TeacherListComponent } from '../modules/teacher/teacher-list/teacher-list.component';
import { NotFoundComponent } from './layout/not-found/not-found.component';
import { HomeComponent } from './layout/home/home.component';
import { AuthGuard } from './guards/auth.guard';
import { ApiConstants } from './constants/api.constants';

const routes: Routes = [
  {
    path: ApiConstants.StudentListRoute,
    component: StudentListComponent,
    canActivate: [AuthGuard],
  },
  {
    path: ApiConstants.TeacherListRoute,
    component: TeacherListComponent,
    canActivate: [AuthGuard],
  },
];

@NgModule({
  declarations: [
    NavBarComponent,
    SideBarComponent,
    FooterComponent,
    DeleteModalComponent,
    NotFoundComponent,
    HomeComponent,
  ],
  imports: [CommonModule, AppRoutingModule, RouterModule.forChild(routes)],
  exports: [
    NavBarComponent,
    SideBarComponent,
    FooterComponent,
    DeleteModalComponent,
  ],
  providers: [],
})
export class SharedModule {}
