import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrl: './delete-modal.component.scss',
})
export class DeleteModalComponent {
  @Input() isVisible = false;
  @Input() itemName = '';
  @Input() itemId: string | null = null;
  @Output() confirm = new EventEmitter<string | null>();
  @Output() cancel = new EventEmitter<void>();

  public onConfirm() {
    this.confirm.emit(this.itemId);
    this.isVisible = false;
  }

  public onCancel() {
    this.cancel.emit();
    this.isVisible = false;
  }

  private closeModal() {
    this.isVisible = false;
  }
}
