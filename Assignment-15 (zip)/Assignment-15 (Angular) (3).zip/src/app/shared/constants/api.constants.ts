export class ApiConstants {
  public static readonly DefaultRoute = '';
  public static readonly WildCardRoute = '**';
  public static readonly HomeRoute = 'home';
  public static readonly TeacherListRoute = 'teacher-list';
  public static readonly TeacherFormRoute = 'add-teacher';
  public static readonly TeacherEditRoute = 'edit-teacher/:id';
  public static readonly StudentListRoute = 'student-list';
  public static readonly StudentFormRoute = 'add-student';
  public static readonly StudentEditRoute = 'edit-student/:id';
  public static readonly LoginRoute = 'login';
}
