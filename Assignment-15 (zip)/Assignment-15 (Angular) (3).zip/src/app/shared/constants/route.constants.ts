import { HttpHeaders } from '@angular/common/http';

export class RouteConstants {
  public static readonly TeacherApiUrl = 'https://localhost:7066/api/Teacher';
  public static readonly StudentApiUrl = 'https://localhost:7066/api/Student';
  public static readonly UserApiUrl = 'https://localhost:7066/api/Authenticate';
  public static readonly DepartmentApiUrl ='https://localhost:7066/api/Department/all';

  public static getHeader() {
    let headers = new HttpHeaders().set(
      'Authorization',
      `bearer ${localStorage.getItem('AccessToken')}`
    );
    return headers;
  }
}
