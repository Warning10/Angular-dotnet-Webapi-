import { Component } from '@angular/core';
import { UserService } from '../../shared/service/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Login } from '../../shared/interface/login-interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  public loginForm!: FormGroup;
  private username: string = '';
  private password: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    localStorage.clear();

    this.loginForm = this.formBuilder.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(10),
          Validators.pattern('^[a-zA-Z0-9]+$'),
        ],
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.pattern(
            '^[a-zA-Z0-9!@#$%^&*()_+={}\\[\\]|;:\'",.<>/?-]+$'
          ),
        ],
      ],
    });
  }

  public onLogin(): void {
    if (this.loginForm.invalid) {
      this.toastr.error(
        'Please fill out the form correctly.',
        'Validation Error'
      );
      return;
    }

    const loginData: Login = this.loginForm.value;

    this.userService.login(loginData).subscribe({
      next: (result) => {
        localStorage.setItem('Username', this.loginForm.value.username);
        localStorage.setItem('AccessToken', result.accessToken);
        localStorage.setItem('RefreshToken', result.refreshToken);

        this.router.navigate(['/home']).then(() => {
          this.toastr.success('Login successful!', 'Success');
        });
      },
      error: (err) => {
        this.handleError(err);
      },
    });
  }
  
  private handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
      if (typeof error.error === 'object') {
        errorMessage = error.error.message || errorMessage;
      } else {
        errorMessage = error.error;
      }
    } else if (error.message) {
      errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
  }
}
