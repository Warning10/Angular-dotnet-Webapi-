import { Component } from '@angular/core';
import { Teacher } from '../../../shared/interface/teacher-interface';
import { TeacherService } from '../../../shared/service/teacher.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrl: './teacher-list.component.scss',
})
export class TeacherListComponent {
  public isApiActive: boolean = false;
  public teachers: Teacher[] = [];
  public errorMessage: string | null = null;
  public isModalVisible = false;
  public itemToDelete: { id: string; name: string } | null = null;
  public departmentNames: { [key: string]: string } = {};

  constructor(
    private teacherService: TeacherService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadTeachers();
    this.loadDepartments();
  }

  public showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  public handleCancelDelete() {
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  public loadTeachers(): void {
    this.teacherService.getAllteacher().subscribe({
      next: (data: Teacher[]) => {
        setTimeout(() => {
          this.teachers = data;
          this.isApiActive = true;
          this.toastr.info('Teacher data loaded successfully');
        }, 1000);
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching teacher data.';
        this.toastr.error('Error fetching teacher');
      },
      complete: () => {
        console.log('Load teacher complete');
      },
    });
  }

  public editTeacher(id: string): void {
    this.router.navigate(['/edit-teacher', id]);
  }

  public handleConfirmDelete(id: string | null) {
    if (id) {
      this.teacherService.deleteTeacher(id).subscribe({
        next: () => {
          this.teachers = this.teachers.filter((student) => student.id !== id);
          this.toastr.success('Teacher deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the teacher.';
          this.toastr.error('Error deleting teacher');
        },
        complete: () => {
          console.log('Delete teacher complete');
        },
      });
    }
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  public loadDepartments() {
    this.teacherService.getDepartments().subscribe((departments) => {
      this.departmentNames = departments.reduce((map, dept) => {
        map[dept.deptId] = dept.deptName;
        return map;
      }, {} as { [key: string]: string });
    });
  }

  public getDepartmentName(deptId: string | null): string {
    return deptId
      ? this.departmentNames[deptId] || 'Unknown Department'
      : 'No Department ID';
  }
}
