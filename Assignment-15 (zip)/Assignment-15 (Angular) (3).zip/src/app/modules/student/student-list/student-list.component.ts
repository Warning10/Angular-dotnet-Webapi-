import { Component, Renderer2 } from '@angular/core';
import { Student } from '../../../shared/interface/student-interface';
import { StudentService } from '../../../shared/service/student.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.scss',
})
export class StudentListComponent {
  public isApiActive: boolean = false;
  public students: Student[] = [];
  public errorMessage: string | null = null;
  public isModalVisible = false;
  public itemToDelete: { id: string; name: string } | null = null;
  public departmentNames: { [key: string]: string } = {};

  constructor(
    private studentService: StudentService,
    private router: Router,
    private toastr: ToastrService,
    private renderer: Renderer2
  ) {}

  ngOnInit(): void {
    this.loadStudents();
    this.loadDepartments();
  }

  public showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  public handleCancelDelete() {
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  public loadStudents(): void {
    this.studentService.getAllStudents().subscribe({
      next: (data: Student[]) => {
        setTimeout(() => {
          this.students = data;
          this.isApiActive = true;
          this.toastr.info('Students data loaded successfully');
        }, 1000);
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching student data.';
        this.toastr.error('Error fetching students');
      },
      complete: () => {
        console.log('Load students complete');
      },
    });
  }

  public editStudent(id: string): void {
    this.router.navigate(['/edit-student', id]);
  }

  public handleConfirmDelete(id: string | null) {
    if (id) {
      this.studentService.deleteStudent(id).subscribe({
        next: () => {
          this.students = this.students.filter((student) => student.id !== id);
          this.toastr.success('Student deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the student.';
          this.toastr.error('Error deleting student');
        },
        complete: () => {
          console.log('Delete student complete');
        },
      });
    }
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  public loadDepartments() {
    this.studentService.getDepartments().subscribe((departments) => {
      this.departmentNames = departments.reduce((map, dept) => {
        map[dept.deptId] = dept.deptName;
        return map;
      }, {} as { [key: string]: string });
    });
  }

  public getDepartmentName(deptId: string | null): string {
    return deptId
      ? this.departmentNames[deptId] || 'Unknown Department'
      : 'No Department ID';
  }
}
