import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { ModulesModule } from './modules/modules.module';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './shared/layout/home/home.component';
import { NotFoundComponent } from './shared/layout/not-found/not-found.component';
import { LoginComponent } from './modules/login/login.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { JwtModule } from '@auth0/angular-jwt';
import { ApiConstants } from './shared/constants/api.constants';

export function tokenGetter() {
  return localStorage.getItem("AccessToken");
}
const routes: Routes = [
  { path: ApiConstants.DefaultRoute, component: LoginComponent }, 
  { path: ApiConstants.LoginRoute, component: LoginComponent }, 
  { path: ApiConstants.HomeRoute, component: HomeComponent, canActivate: [AuthGuard] },
  { path: ApiConstants.WildCardRoute, component: NotFoundComponent }
];


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ModulesModule,
    SharedModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains: ["http://localhost:4200"],
        disallowedRoutes: []
      }
    })
    
  ],
  providers: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
