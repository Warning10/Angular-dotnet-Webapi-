import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  logout(): void {
    // Clear user authentication data
    localStorage.clear(); // Example
    // More logic if needed
  }

  
}
