import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { RouteConstants } from '../constants/route.constants';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router) { }

  login(data: any): Observable<any> {
    return this.http.post<any>(`${RouteConstants.UserApiUrl}/login`, data);
  }
  
  public getRefreshToken(data: any): Observable<any>{
    return this.http.post<any>(`${RouteConstants.UserApiUrl}/refreshToken`,data)
  }
}
