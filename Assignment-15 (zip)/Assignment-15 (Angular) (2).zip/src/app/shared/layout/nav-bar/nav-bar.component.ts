import { Component } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss'
})
export class NavBarComponent {
  public name :string | null = '';
  constructor(private authService: AuthService, private router: Router) { }
  
  isLoginIn() : boolean{
    let username = localStorage.getItem('Username');
    const token = localStorage.getItem('AccessToken');
    if(token)
    { 
      this.name = username;
      return true;
    }
    else{
      this.name = null;
      return false;
    }
  }

  logout(): void {
    this.authService.logout(); // Assuming you have a logout method in your AuthService
    this.router.navigate(['/login']); // Redirect to login page
  }
}
