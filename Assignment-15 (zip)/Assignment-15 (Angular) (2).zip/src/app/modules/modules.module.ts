import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentListComponent } from './student/student-list/student-list.component';
import { StudentFormComponent } from './student/student-form/student-form.component';
import { TeacherListComponent } from './teacher/teacher-list/teacher-list.component';
import { TeacherFormComponent } from './teacher/teacher-form/teacher-form.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { SharedModule } from '../shared/shared.module';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from '../shared/guards/auth.guard';
import { ApiConstants } from '../shared/constants/api.constants';

const routes: Routes = [
  { path: ApiConstants.StudentListRoute, component: StudentListComponent, canActivate: [AuthGuard]  },
  { path: ApiConstants.TeacherListRoute, component: TeacherListComponent, canActivate: [AuthGuard] },
  { path: ApiConstants.StudentFormRoute, component: StudentFormComponent, canActivate: [AuthGuard] },
  { path: ApiConstants.TeacherFormRoute, component: TeacherFormComponent , canActivate: [AuthGuard]},
  { path: ApiConstants.StudentEditRoute, component: StudentFormComponent , canActivate: [AuthGuard]},
  { path: ApiConstants.TeacherEditRoute, component: TeacherFormComponent , canActivate: [AuthGuard]},

];


@NgModule({
  declarations: [
    StudentListComponent,
    StudentFormComponent,
    TeacherListComponent,
    TeacherFormComponent,
    LoginComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 10000,
      positionClass: 'toast-top-center',
      preventDuplicates: true,
    }),
    RouterModule.forChild(routes),
    AppRoutingModule,
    SharedModule
  ],
  exports: [
  ],
  providers: [
  ]
})
export class ModulesModule { }
