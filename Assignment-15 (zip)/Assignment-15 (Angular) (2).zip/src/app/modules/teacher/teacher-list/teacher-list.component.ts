import { Component } from '@angular/core';
import { Teacher } from '../../../shared/interface/teacher-interface';
import { TeacherService } from '../../../shared/service/teacher.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrl: './teacher-list.component.scss'
})
export class TeacherListComponent {

  isApiActive: boolean = false;
  teachers: Teacher[]=[];
  errorMessage: string | null = null;
  isModalVisible = false;
  itemToDelete: { id: string, name: string } | null = null;
  departmentNames: { [key: string]: string } = {};


  constructor(private teacherService: TeacherService, private router: Router, private toastr: ToastrService){}

  ngOnInit(): void {
    this.loadTeachers();
    this.loadDepartments();
  }

  showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  handleCancelDelete() {
    this.itemToDelete = null; // Clear the item to delete
    this.isModalVisible = false;
  }

  loadTeachers(): void {
    this.teacherService.getAllteacher().subscribe({
      next: (data: Teacher[]) => {
          setTimeout(() => {
            this.teachers = data;
          this.isApiActive = true;
          this.toastr.info('Teacher data loaded successfully');
          }, 1000);
                
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching teacher data.';
        this.toastr.error('Error fetching teacher');
        console.error('Error Fetching teacher:', error); // Optional debugging line
      },
      complete: () => {
        console.log('Load teacher complete'); // Optional debugging line
      }
    });
  }

  editTeacher(id: string): void {
    this.router.navigate(['/edit-teacher', id]);
  }

   handleConfirmDelete(id: string | null) {
    if (id) {
      this.teacherService.deleteTeacher(id).subscribe({
        next: () => {
          this.teachers = this.teachers.filter(student => student.id !== id);
          this.toastr.success('Teacher deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the teacher.';
          this.toastr.error('Error deleting teacher');
          console.error('Error deleting teacher:', error); // Optional debugging line
        },
        complete: () => {
          console.log('Delete teacher complete'); // Optional debugging line
        }
      });
    }
    this.itemToDelete = null; 
    this.isModalVisible = false;
  }
  loadDepartments() {
    this.teacherService.getDepartments().subscribe(departments => {
      this.departmentNames = departments.reduce((map, dept) => {
        map[dept.deptId] = dept.deptName;
        return map;
      }, {} as { [key: string]: string });
    });
  }

  getDepartmentName(deptId: string | null): string {
    return deptId ? this.departmentNames[deptId] || 'Unknown Department' : 'No Department ID';
  }
}