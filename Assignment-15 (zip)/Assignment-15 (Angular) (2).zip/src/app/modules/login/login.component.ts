import { Component } from '@angular/core';
import { UserService } from '../../shared/service/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Login } from '../../shared/interface/login-interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  loginForm!: FormGroup;
  username: string = '';
  password: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    // Clear local storage when component is initialized
    localStorage.clear();

    // Initialize form
    this.loginForm = this.formBuilder.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(10),
          Validators.pattern('^[a-zA-Z0-9]+$') // Only letters and numbers
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.pattern('^[a-zA-Z0-9!@#$%^&*()_+={}\\[\\]|;:\'",.<>/?-]+$') // Disallow spaces
        ]
      ]
    });
  }

  onLogin(): void {
    if (this.loginForm.invalid) {
      this.toastr.error('Please fill out the form correctly.', 'Validation Error');
      return;
    }

    // Use the Login interface to type the form value
    const loginData: Login = this.loginForm.value;

    this.userService.login(loginData).subscribe({
      next: (result) => {
        localStorage.setItem('Username', this.loginForm.value.username);
        localStorage.setItem('AccessToken', result.accessToken);
        localStorage.setItem('RefreshToken', result.refreshToken);
        
        this.router.navigate(['/home']).then(() => {
          this.toastr.success('Login successful!', 'Success');
        });
      },
      error: (err) => {
        this.handleError(err);
      }
    });
  }
  private handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';

    if (error.error) {
      // Check if error is an object and has a message
      if (typeof error.error === 'object') {
        errorMessage = error.error.message || errorMessage;
      } else {
        // If the error is a string, display it directly
        errorMessage = error.error;
      }
    } else if (error.message) {
      // Fallback to generic error message if nothing else is available
      errorMessage = error.message;
    }

    this.toastr.error(errorMessage, 'Error');
    console.error('Request failed', error);
  }
}
