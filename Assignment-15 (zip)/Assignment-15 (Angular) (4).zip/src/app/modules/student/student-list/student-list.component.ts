import { Component } from '@angular/core';
import { Student } from '../../../shared/interface/student-interface';
import { StudentService } from '../../../shared/service/student.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.scss',
})
export class StudentListComponent {
  public isApiActive: boolean = false;
  public students: Student[] = [];
  public errorMessage: string | null = null;
  public isModalVisible = false;
  public itemToDelete: { id: string; name: string } | null = null;
  public departmentNames: { [key: string]: string } = {};

  constructor(
    private studentService: StudentService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadStudents();
    this.loadDepartments();
  }

  // Sets up the item to be deleted and shows the confirmation modal.
  public showDeleteModal(id: string, name: string) {
    this.itemToDelete = { id, name };
    this.isModalVisible = true;
  }

  // Clears the item to be deleted and hides the confirmation modal.
  public handleCancelDelete() {
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  // Fetches and displays student data with a delay, handles errors, and logs completion.
  private loadStudents(): void {
    this.studentService.getAllStudents().subscribe({
      next: (data: Student[]) => {
        setTimeout(() => {
          this.students = data;
          this.isApiActive = true;
          this.toastr.info('Students data loaded successfully');
        }, 1000);
      },
      error: (error: any) => {
        this.errorMessage = 'An error occurred while fetching student data.';
        this.toastr.error('Error fetching students');
      },
      complete: () => {
        console.log('Load students complete');
      },
    });
  }

  // navigates to edit student
  public editStudent(id: string): void {
    this.router.navigate(['/edit-student', id]);
  }

  // Confirms and performs the deletion of a student, updates the student list, and handles errors and completion.
  public handleConfirmDelete(id: string | null) {
    if (id) {
      this.studentService.deleteStudent(id).subscribe({
        next: () => {
          this.students = this.students.filter((student) => student.id !== id);
          this.toastr.success('Student deleted successfully');
        },
        error: (error: any) => {
          this.errorMessage = 'An error occurred while deleting the student.';
          this.toastr.error('Error deleting student');
        },
        complete: () => {
          console.log('Delete student complete');
        },
      });
    }
    this.itemToDelete = null;
    this.isModalVisible = false;
  }

  // Retrieves departments and maps them to their names for easy access.
  private loadDepartments() {
    this.studentService.getDepartments().subscribe((departments) => {
      this.departmentNames = departments.reduce((map, dept) => {
        map[dept.deptId] = dept.deptName;
        return map;
      }, {} as { [key: string]: string });
    });
  }

  // Returns the department name for a given ID or a default message if not found.
  public getDepartmentName(deptId: string | null): string {
    return deptId
      ? this.departmentNames[deptId] || 'Unknown Department'
      : 'No Department ID';
  }
}
