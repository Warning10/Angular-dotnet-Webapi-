import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss',
})
export class NavBarComponent {
  public name: string | null = '';
  constructor(private router: Router, private toastr: ToastrService) {}

  public isLoginIn(): boolean {
    let username = localStorage.getItem('Username');
    const token = localStorage.getItem('AccessToken');
    if (token) {
      this.name = username;
      return true;
    } else {
      this.name = null;
      return false;
    }
  }

  public logout(): void {
    localStorage.clear();
    this.toastr.success('You have been logged out successfully.', 'Logout');
    this.router.navigate(['/login']);
  }
}
