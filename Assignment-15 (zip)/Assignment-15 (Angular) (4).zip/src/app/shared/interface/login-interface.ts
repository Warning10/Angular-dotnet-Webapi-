export interface Login {
  userName: string;
  password: string;
}
