import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department } from '../interface/department-interface';
import { HttpClient } from '@angular/common/http';
import { RouteConstants } from '../constants/route.constants';

@Injectable({
  providedIn: 'root',
})
export class DepartmentService {
  constructor(private http: HttpClient) {}

  public getAllDepartments(): Observable<Department[]> {
    return this.http.get<Department[]>(RouteConstants.DepartmentApiUrl, {
      headers: RouteConstants.getHeader(),
    });
  }
}
