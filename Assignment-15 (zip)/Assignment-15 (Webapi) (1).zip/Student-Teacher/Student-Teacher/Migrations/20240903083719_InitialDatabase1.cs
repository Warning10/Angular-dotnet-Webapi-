﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Student_Teacher.Migrations
{
    /// <inheritdoc />
    public partial class InitialDatabase1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("12a945c2-3edf-40cd-931b-6c304b322574"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("a899b11d-40b0-4e7b-a4b6-462325832a0e"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("bf167caf-8848-472f-b5fd-2f5c3bc94a5c"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("c0ffb62a-7230-4165-87e0-47a86aeef1f2"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("d0a50848-bbe3-484a-8014-a26269fcde11"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("22b9c2bd-1896-4e56-9a15-5bcbba952994"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("539b295e-fdeb-461c-82f0-0e1bcc665934"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("c44cec8d-0ea8-4d75-8573-79e01749646b"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("f0b33ae9-672a-44af-a66a-60fcecd65d68"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("fe09f52b-ab4f-44f9-9b1c-4b3659825eea"));

            migrationBuilder.AlterColumn<DateTime>(
                name: "RefreshTokenExpiryTime",
                table: "Users",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2206), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2206) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2210), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2210) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2208), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2208) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2211), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2211) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2213), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2213) });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("1499a4bc-059d-44a3-94c9-4511ee9fe6a2"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1827), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1827), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1828) },
                    { new Guid("288f8353-542e-4620-bcd3-23b70ff297db"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1830), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1830), "Diana", "Female", "8th", "Brown", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1831) },
                    { new Guid("5f9b4c80-17fa-4a34-a32b-a3e72a758416"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1819), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1818), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1820) },
                    { new Guid("685e00de-1b8b-47bc-b816-c5176509a2be"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1824), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1823), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1824) },
                    { new Guid("8f1047c7-707b-45a1-88af-06bd73e0dd5d"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1835), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1834), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(1835) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("2d0c8155-53fd-4935-b31a-be8ac0902ccb"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2094), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2095) },
                    { new Guid("8dc8dec2-e083-479f-a5a6-9dadb675e6be"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2107), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2107) },
                    { new Guid("a7facc2b-99c5-4a10-97ed-d1747f04e535"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2091), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2091) },
                    { new Guid("c513e863-0d16-4259-bb85-2ba0ea37c7fa"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2110), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2110) },
                    { new Guid("d62eccf7-0def-4a45-8234-f8559282d321"), new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2104), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 9, 3, 8, 37, 18, 753, DateTimeKind.Utc).AddTicks(2104) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("1499a4bc-059d-44a3-94c9-4511ee9fe6a2"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("288f8353-542e-4620-bcd3-23b70ff297db"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("5f9b4c80-17fa-4a34-a32b-a3e72a758416"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("685e00de-1b8b-47bc-b816-c5176509a2be"));

            migrationBuilder.DeleteData(
                table: "StudentModel",
                keyColumn: "Id",
                keyValue: new Guid("8f1047c7-707b-45a1-88af-06bd73e0dd5d"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("2d0c8155-53fd-4935-b31a-be8ac0902ccb"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("8dc8dec2-e083-479f-a5a6-9dadb675e6be"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("a7facc2b-99c5-4a10-97ed-d1747f04e535"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("c513e863-0d16-4259-bb85-2ba0ea37c7fa"));

            migrationBuilder.DeleteData(
                table: "TeacherModel",
                keyColumn: "Id",
                keyValue: new Guid("d62eccf7-0def-4a45-8234-f8559282d321"));

            migrationBuilder.AlterColumn<DateTime>(
                name: "RefreshTokenExpiryTime",
                table: "Users",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1061), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1061) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1066), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1067) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1064), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1064) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1068), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1069) });

            migrationBuilder.UpdateData(
                table: "Departments",
                keyColumn: "DeptId",
                keyValue: new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"),
                columns: new[] { "Created", "Updated" },
                values: new object[] { new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1070), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(1071) });

            migrationBuilder.InsertData(
                table: "StudentModel",
                columns: new[] { "Id", "Created", "DateOfBirth", "DeptId", "Email", "EnrollmentDate", "FirstName", "Gender", "Grade", "LastName", "Updated" },
                values: new object[,]
                {
                    { new Guid("12a945c2-3edf-40cd-931b-6c304b322574"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(682), new DateTime(2010, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "bob.johnson@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(681), "Bob", "Male", "1st", "Johnson", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(683) },
                    { new Guid("a899b11d-40b0-4e7b-a4b6-462325832a0e"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(707), new DateTime(2000, 11, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "ethan.davis@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(706), "Ethan", "Male", "10th", "Davis", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(707) },
                    { new Guid("bf167caf-8848-472f-b5fd-2f5c3bc94a5c"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(677), new DateTime(2015, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "alice.smith@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(675), "Alice", "Female", "Nursery", "Smith", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(677) },
                    { new Guid("c0ffb62a-7230-4165-87e0-47a86aeef1f2"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(690), new DateTime(2002, 3, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "diana.brown@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(690), "Diana", "Female", "8th", "Brown", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(691) },
                    { new Guid("d0a50848-bbe3-484a-8014-a26269fcde11"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(686), new DateTime(2005, 12, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "charlie.williams@example.com", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(686), "Charlie", "Non-Binary", "5th", "Williams", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(687) }
                });

            migrationBuilder.InsertData(
                table: "TeacherModel",
                columns: new[] { "Id", "Created", "DeptId", "Email", "FirstName", "Gender", "HireDate", "LastName", "Position", "Updated" },
                values: new object[,]
                {
                    { new Guid("22b9c2bd-1896-4e56-9a15-5bcbba952994"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(953), new Guid("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"), "pooja.jadhav@example.com", "Pooja", "Female", new DateTime(2020, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Jadhav", "English Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(953) },
                    { new Guid("539b295e-fdeb-461c-82f0-0e1bcc665934"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(956), new Guid("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"), "vikram.shinde@example.com", "Vikram", "Male", new DateTime(2022, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Shinde", "Physical Education Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(957) },
                    { new Guid("c44cec8d-0ea8-4d75-8573-79e01749646b"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(945), new Guid("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"), "snehal.patil@example.com", "Snehal", "Female", new DateTime(2015, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Patil", "Science Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(946) },
                    { new Guid("f0b33ae9-672a-44af-a66a-60fcecd65d68"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(941), new Guid("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"), "amit.deshmukh@example.com", "Amit", "Male", new DateTime(2010, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Deshmukh", "Math Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(941) },
                    { new Guid("fe09f52b-ab4f-44f9-9b1c-4b3659825eea"), new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(949), new Guid("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"), "rajesh.kulkarni@example.com", "Rajesh", "Male", new DateTime(2018, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Kulkarni", "History Teacher", new DateTime(2024, 9, 3, 8, 31, 18, 890, DateTimeKind.Utc).AddTicks(949) }
                });
        }
    }
}
