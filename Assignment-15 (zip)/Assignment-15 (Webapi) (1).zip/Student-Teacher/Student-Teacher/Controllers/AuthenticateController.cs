﻿using Department_Teacher.Modules.DepartmentModule.Query;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Modules.AuthenticateModule.Command;

namespace Student_Teacher.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly ISender _mediatR;

        public AuthenticateController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] ValidateUserCommand validateUserCommand)
        {
            try
            {
                var result = await _mediatR.Send(validateUserCommand) ;

                if (result == null)
                {
                    return NotFound(new { Message = "User Not Found" });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("refreshToken")]
        public async Task<IActionResult> GenerateRefreshToken([FromBody] ValidateRefreshTokenCommand validateRefreshTokenCommand)
        {
            try
            {
                var result = await _mediatR.Send(validateRefreshTokenCommand);

                if (result == null)
                {
                    return NotFound(new { Message = "User Not Found" });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
