﻿using Department_Teacher.Modules.DepartmentModule.Command;
using Department_Teacher.Modules.DepartmentModule.Query;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Student_Teacher.Modules.DepartmentModule.Command;

namespace Student_Teacher.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly ISender _mediatR;

        public DepartmentController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllDepartments()
        {
            try
            {

                var result = await _mediatR.Send(new GetDepartmentQuery());

                if (result == null)
                {
                    return NotFound("No Departments found.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("byid/{id}")]
        public async Task<IActionResult> GetDepartmentById([FromRoute] Guid id)
        {
            try
            {
                var result = await _mediatR.Send(new GetDepartmentByIdQuery { Id = id });

                if (result == null)
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("create")]
        public async Task<object> CreateDepartment([FromBody] CreateDepartmentCommand createDepartmentCommand)
        {
            try
            {
                var isSuccess = await _mediatR.Send(createDepartmentCommand);
                if (!isSuccess)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the Department.");
                }
                else
                {
                    return Ok(new { Message = "Department created successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("update/{id}")]
        public async Task<object> UpdateDepartment([FromBody] DepartmentCommand DepartmentCommand, [FromRoute] Guid id)
        {
            try
            {
                var updateDepartmentCommand = new UpdateDepartmentCommand
                {
                    Id = id,
                    DeptName = DepartmentCommand.DeptName
                };


                bool isUpdated = await _mediatR.Send(updateDepartmentCommand);
                if (!isUpdated)
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }
                else
                {
                    return Ok(new { Message = "Department updated successfully." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<object> DeleteDepartment([FromRoute] Guid id)
        {

            try
            {
                var result = await _mediatR.Send(new DeleteDepartmentCommand() { Id = id });
                if (result)
                {
                    return Ok(new { Message = $"Department with ID {id} deleted successfully" });
                }
                else
                {
                    return NotFound(new { Message = $"Department with ID {id} not found." });
                }
            }
            catch (ValidationException ex)
            {
                return BadRequest(ex.Errors.ToList()[0].ErrorMessage);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}