﻿using FluentValidation;

namespace Student_Teacher.Modules.TeacherModule.Command
{
    public class TeacherCommandValidator : AbstractValidator<TeacherCommand>
    {
        public TeacherCommandValidator()
        {
            // Validate FirstName
            RuleFor(x => x.FirstName)
                .NotNull()
                .WithMessage("First Name cannot be null.")
                .NotEmpty()
                .WithMessage("First Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("First Name must be between 1 and 50 characters.")
                .Matches(@"^[a-zA-Z]+$")
                .WithMessage("First Name can only contain alphabets.");

            // Validate LastName
            RuleFor(x => x.LastName)
                .NotNull()
                .WithMessage("Last Name cannot be null.")
                .NotEmpty()
                .WithMessage("Last Name cannot be empty.")
                .Length(1, 50)
                .WithMessage("Last Name must be between 1 and 50 characters.")
                .Matches(@"^[a-zA-Z]+$")
                .WithMessage("Last Name can only contain alphabets.");

            // Validate Email
            RuleFor(x => x.Email)
                .NotNull()
                .WithMessage("Email cannot be null.")
                .NotEmpty()
                .WithMessage("Email is required.")
                .EmailAddress()
                .WithMessage("Invalid email address format.")
                .Length(1, 100)
                .WithMessage("Email must not exceed 100 characters.");

            // Validate Gender
            RuleFor(x => x.Gender)
                .NotNull()
                .WithMessage("Gender cannot be null.")
                .NotEmpty()
                .WithMessage("Gender is required.")
                .Must(gender => gender == "Male" || gender == "Female" || gender == "Other")
                .WithMessage("Gender must be either 'Male', 'Female', or 'Other'.");

            // Validate DeptId
            RuleFor(x => x.DeptId)
                .NotEmpty()
                .WithMessage("Department ID cannot be empty.");

            // Validate HireDate
            RuleFor(x => x.HireDate)
                .NotNull()
                .WithMessage("Hire Date cannot be null.")
                .NotEmpty()
                .WithMessage("Hire Date is required.")
                .Must(date => date <= DateTime.UtcNow)
                .WithMessage("Hire Date must be in the past or today.");

            // Validate Position
            RuleFor(x => x.Position)
                .NotNull()
                .WithMessage("Position cannot be null.")
                .NotEmpty()
                .WithMessage("Position is required.")
                .Length(1, 100)
                .WithMessage("Position must be between 1 and 100 characters.");
        }
    }
}
