﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.TeacherModule.Command
{
    public class CreateTeacherCommand : TeacherCommand { }

    public class CreateTeacherCommandHandler : IRequestHandler<CreateTeacherCommand, bool>
    {
        private readonly IGenericRepository<TeacherModel> _genericRepository;

        public CreateTeacherCommandHandler(IGenericRepository<TeacherModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        public async Task<bool> Handle(CreateTeacherCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new TeacherCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }
            var teacher = new TeacherModel
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Gender = request.Gender,
                DeptId = request.DeptId,
                HireDate = request.HireDate,
                Position = request.Position,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            };
            return await _genericRepository.AddAsync(teacher);
        }
    }
}
