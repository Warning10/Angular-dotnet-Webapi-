﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.AuthenticateModule.Command
{
    public class LoginDataCommand : IRequest<TokenModel>
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
