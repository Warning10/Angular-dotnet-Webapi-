﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Student_Teacher.Models
{
    public class StudentModel
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public Guid DeptId { get; set; }
        //Navigation Property
        [ForeignKey("DeptId")]
        public DepartmentModel Department { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string Grade { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }
    }
}
