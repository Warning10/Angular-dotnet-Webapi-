﻿using Microsoft.EntityFrameworkCore;
using Student_Teacher.Utils;

namespace Student_Teacher
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ApplicationDbContext context)
        {
            _context = context;
            _dbSet = _context.Set<T>();
        }

        #region Retrieve All Entities
        /// <summary>
        /// Retrieves all entities of type <typeparamref name="T"/> from the database.
        /// </summary>
        public async Task<List<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }
        #endregion

        #region Retrieve Entity By ID
        /// <summary>
        /// Retrieves an entity of type <typeparamref name="T"/> by its unique identifier from the database.
        /// </summary>
        public async Task<T> GetByIdAsync(Guid id)
        {
            return await _dbSet.FindAsync(id);
        }
        #endregion

        #region Add Entity
        /// <summary>
        /// Adds a new entity of type <typeparamref name="T"/> to the database.
        /// </summary>
        public async Task<bool> AddAsync(T entity)
        {
            try
            {
                _dbSet.Add(entity);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Save Changes
        /// <summary>
        /// Saves all changes made in the context to the database.
        /// </summary>
        public void SaveData()
        {
            _context.SaveChanges();
        }
        #endregion

        #region Delete Entity
        /// <summary>
        /// Deletes an entity of type <typeparamref name="T"/> from the database by its unique identifier.
        /// </summary>
        public async Task<bool> DeleteAsync(Guid Id)
        {
            var entity = await _dbSet.FindAsync(Id);
            if (entity != null)
            {
                _dbSet.Remove(entity);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
        #endregion
    }
}
