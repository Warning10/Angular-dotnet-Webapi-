﻿using Microsoft.EntityFrameworkCore;
using Student_Teacher.Interfaces;
using Student_Teacher.Models;
using Student_Teacher.Utils;

namespace Student_Teacher.Repository
{
    public class ValidateUserDetails : IValidateUserRepository
    {
        private readonly ApplicationDbContext _context;

        public ValidateUserDetails(ApplicationDbContext context)
        {
            _context = context;
        }

        #region Retrieve User By Username
        /// <summary>
        /// Retrieves a user by their username from the database.
        /// </summary>
        public async Task<UserModel> GetByUserName(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                throw new ArgumentException("Username cannot be null or empty", nameof(username));
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);

            return user;
        }
        #endregion
    }
}
