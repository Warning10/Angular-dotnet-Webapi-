﻿using MediatR;
using Student_Teacher.Interfaces;
using Student_Teacher.Models;
using System.Security.Claims;

namespace Student_Teacher.Modules.AuthenticateModule.Command
{
    public class ValidateRefreshTokenCommand : TokensDataCommand { }

    public class ValidateRefreshTokenCommandHandler : IRequestHandler<ValidateRefreshTokenCommand, TokenModel>
    {
        private readonly IGenericRepository<UserModel> _genericRepository;
        private readonly IValidateUserRepository _validateUserRepository;
        private readonly IGenerateToken _generateToken;

        public ValidateRefreshTokenCommandHandler(IGenericRepository<UserModel> genericRepository, IValidateUserRepository validateUserRepository, IGenerateToken generateToken)
        {
            _genericRepository = genericRepository;
            _validateUserRepository = validateUserRepository;
            _generateToken = generateToken;
        }

        /// <summary>
        /// Handles the validation and generation of a new refresh token based on the provided access token and refresh token details.
        /// </summary>
        public async Task<TokenModel> Handle(ValidateRefreshTokenCommand request, CancellationToken cancellationToken)
        {
            var principal = _generateToken.GetPrincipalFromExpiredToken(request.AccessToken);
            var username = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            var users = await _validateUserRepository.GetByUserName(username);
            if (users == null || users.RefreshToken != request.RefreshToken || users.RefreshTokenExpiryTime < DateTime.Now)
            {
                throw new InvalidOperationException("Token Expired");
            }

            var tokens = await _generateToken.GenerateTokens(users.Username);
            if (tokens == null)
            {
                throw new InvalidOperationException("Invalid Operation");
            }
            users.RefreshToken = tokens.RefreshToken;
            users.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(10);
            _genericRepository.SaveData();
            return tokens;
        }

    }

}
