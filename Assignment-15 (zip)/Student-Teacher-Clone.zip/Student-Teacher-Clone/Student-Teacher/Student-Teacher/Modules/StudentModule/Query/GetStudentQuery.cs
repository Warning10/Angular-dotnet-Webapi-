﻿using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Query
{
    public class GetStudentQuery : IRequest<List<StudentModel>> { }

    public class GetStudentQuerytHandler : IRequestHandler<GetStudentQuery, List<StudentModel>>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;

        public GetStudentQuerytHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Retrieves a list of all students from the repository.
        /// </summary>
        public async Task<List<StudentModel>> Handle(GetStudentQuery request, CancellationToken cancellationToken)
        {
            return await _genericRepository.GetAllAsync();
        }
    }
}
