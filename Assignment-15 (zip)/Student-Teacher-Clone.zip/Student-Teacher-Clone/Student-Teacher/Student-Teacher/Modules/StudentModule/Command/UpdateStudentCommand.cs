﻿using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Student_Teacher.Models;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class UpdateStudentCommand : StudentCommand
    {
        public Guid Id { get; set; }
    }

    public class UpdateStudentCommandHandler : IRequestHandler<UpdateStudentCommand, bool>
    {
        private readonly IGenericRepository<StudentModel> _genericRepository;

        public UpdateStudentCommandHandler(IGenericRepository<StudentModel> genericRepository)
        {
            _genericRepository = genericRepository;
        }

        /// <summary>
        /// Handles the update of an existing student based on the provided command details.
        /// </summary>
        public async Task<bool> Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
        {
            ValidationResult validationResult = await new StudentCommandValidator().ValidateAsync(request, cancellationToken);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.Errors);
            }

            var result = await _genericRepository.GetByIdAsync(request.Id);
            if (result == null)
            {
                return false;
            }

            result.Id = request.Id;
            result.FirstName = request.FirstName;
            result.LastName = request.LastName;
            result.Email = request.Email;
            result.Gender = request.Gender;
            result.DeptId = request.DeptId;
            result.DateOfBirth = request.DateOfBirth;
            result.EnrollmentDate = request.EnrollmentDate;
            result.Grade = request.Grade;
            result.Updated = DateTime.Now;

            _genericRepository.SaveData();

            return true;
        }
    }
}

