﻿using MediatR;

namespace Student_Teacher.Modules.StudentModule.Command
{
    public class StudentCommand : IRequest<bool>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public Guid DeptId { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string Grade { get; set; }
    }
}
