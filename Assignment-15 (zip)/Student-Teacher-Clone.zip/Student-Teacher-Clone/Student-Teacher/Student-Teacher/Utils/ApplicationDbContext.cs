﻿using Microsoft.EntityFrameworkCore;
using Student_Teacher.Models;
using Student_Teacher.Utils.Configuration;

namespace Student_Teacher.Utils
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.ApplyConfiguration(new StudentConfiguration());
            modelBuilder.ApplyConfiguration(new TeacherConfiguration());
            modelBuilder.ApplyConfiguration(new DepartmentConfiguration());
        }

        public DbSet<StudentModel> Students { get; set; }

        public DbSet<TeacherModel> Teachers { get; set; }

        public DbSet<DepartmentModel> Departments { get; set; }

        public DbSet<UserModel> Users { get; set; }
    }
}
