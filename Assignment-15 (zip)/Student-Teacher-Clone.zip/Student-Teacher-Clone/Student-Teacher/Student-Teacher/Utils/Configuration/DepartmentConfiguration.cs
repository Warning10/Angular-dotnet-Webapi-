﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Student_Teacher.Models;

namespace Student_Teacher.Utils.Configuration
{
    public class DepartmentConfiguration : IEntityTypeConfiguration<DepartmentModel>
    {
        public void Configure(EntityTypeBuilder<DepartmentModel> builder)
        {

            builder.HasData(
                new DepartmentModel
                {
                    DeptId = Guid.Parse("27ffae5b-05c3-4170-b8b4-6fa60364a0a1"),
                    DeptName = "Computer",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = Guid.Parse("a8b8b9d7-92c7-4ef1-9e3d-4a55a3390b3b"),
                    DeptName = "Information Technology",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = Guid.Parse("4b94f646-3bfa-4b7c-9c5e-81aefda86d53"),
                    DeptName = "Mechanical",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = Guid.Parse("abec4d16-7a68-42e0-b4a8-7467e3d0e3f4"),
                    DeptName = "Civil",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                },
                new DepartmentModel
                {
                    DeptId = Guid.Parse("f5d8d7c4-3dbb-4e4e-9f5e-cab52e7e47b1"),
                    DeptName = "Production",
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                }
            );
        }
    }
}
