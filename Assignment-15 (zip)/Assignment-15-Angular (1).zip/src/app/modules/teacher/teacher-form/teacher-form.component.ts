import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Department } from '../../../shared/interface/department-interface';
import { TeacherService } from '../../../shared/service/teacher.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Teacher } from '../../../shared/interface/teacher-interface';

@Component({
  selector: 'app-teacher-form',
  templateUrl: './teacher-form.component.html',
  styleUrl: './teacher-form.component.scss'
})
export class TeacherFormComponent {

  teacherForm: FormGroup;
  isEditMode: boolean = false;
  teacherId: string | null = null;
  departments: Department[] = []; 
  position: string[] = ['A', 'B', 'C', 'D', 'F']; 
  
  
  
  constructor(
    private fb: FormBuilder,
    private teacherService : TeacherService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService
  
  ){
    this.teacherForm=this.fb.group({
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        gender: ['', Validators.required],
        deptId: ['', Validators.required],
        hireDate: ['', Validators.required],
        position: ['', Validators.required],
    });
  }
  
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.teacherId = params.get('id');
      if (this.teacherId) {
        this.isEditMode = true;
        this.loadTeacherData(this.teacherId);
      }
    });
    this.loadDepartments();
  }
  
  loadTeacherData(id: string): void {
    this.teacherService.getTeacher(id).subscribe({
      next: (teacher: Teacher) => {
        this.teacherForm.patchValue({
          ...teacher,
          hireDate: this.formatDate(teacher.hireDate),
        });
      },
      error: (error: any) => {
        this.toastr.error('Error fetching Teacher data');
        console.error('Error fetching Teacher data:', error); // Optional debugging line
      },
      complete: () => {
        console.log('Load Teacher data complete'); // Optional debugging line
      }
    });
  }
  
  loadDepartments(): void {
    this.teacherService.getDepartments().subscribe({
      next: (departments: Department[]) => {
        this.departments = departments;
      },
      error: (error: any) => {
        this.toastr.error('Error fetching departments');
        console.error('Error fetching departments:', error); // Optional debugging line
      },
      complete: () => {
        console.log('Load departments complete'); // Optional debugging line
      }
    });
  }
  
  formatDate(dateString: string): string {
    // Format date as yyyy-MM-dd
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  }
  
  
  onSubmit(): void {
    if (this.teacherForm.valid) {
      const teacherData = this.teacherForm.value;
      if (this.isEditMode && this.teacherId) {
        this.teacherService.updateTeacher(this.teacherId, teacherData).subscribe({
          next: () => {
            this.toastr.success('Teacher updated successfully');
            this.router.navigate(['/teacher-list']);
          },
          error: (error: any) => {
            this.handleError(error);
  
          },
          complete: () => {
            console.log('Update teacher complete'); 
          }
        });
      } else {
        this.teacherService.addTeacher(teacherData).subscribe({
          next: () => {
            this.toastr.success('Teacher added successfully');
            this.router.navigate(['/teacher-list']);
          },
          error: (error: any) => {
            this.handleError(error);
  
          },
          complete: () => {
            console.log('Add teacher complete'); // Optional debugging line
          }
        });
      }
    }
  }
  handleError(error: any): void {
    let errorMessage = 'An unexpected error occurred';
  
    if (error.error) {
        // Check if error is an object and has a message
        if (typeof error.error === 'object') {
            errorMessage = error.error.message || errorMessage;
        } else {
            // If the error is a string, display it directly
            errorMessage = error.error;
        }
    } else if (error.message) {
        // Fallback to generic error message if nothing else is available
        errorMessage = error.message;
    }
  
    this.toastr.error(errorMessage, 'Error');
    console.error('Request failed', error);
  }
  
  goBack(): void {
    // Navigate to the teacher list page
    this.router.navigate(['/teacher-list']);
  }
  }
