import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router) { }

  login(data:any){
    this.http.post("https://localhost:7066/api/Authenticate/login",data).subscribe((result:any)=> {
      localStorage.setItem("AccessToken", result.accessToken);
      localStorage.setItem("Refresh", result.refreshToken);
      this.router.navigate(['/home']);
    })
  }
}
