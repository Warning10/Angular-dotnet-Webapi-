import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

  title: string = 'Welcome to My Home Page';
  description: string = 'This is a basic example of a home component in Angular.';

  showAlert() {
    alert('Button clicked!');
  }
}
