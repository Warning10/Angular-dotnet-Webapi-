import { HttpHeaders } from "@angular/common/http";


export const headers = new HttpHeaders().set("Authorization",`bearer ${localStorage.getItem('AccessToken')}`);


