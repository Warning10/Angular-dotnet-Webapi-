export interface Teacher {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  gender: string;
  deptId: string;
  hireDate: string;
  position: string;
}
